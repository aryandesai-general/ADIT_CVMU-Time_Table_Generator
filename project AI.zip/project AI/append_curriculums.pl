use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

# Read curriculums from update_curriculum.pl
my $source = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/update_curriculum.pl";
open my $src_fh, '<:utf8', $source or die "Cannot open $source: $!";
my $src_content = do { local $/; <$src_fh> };
close $src_fh;

if ($src_content =~ /(curriculums:\s*\{[\s\S]*?\n\s*\},)/) {
    my $curr_block = $1;
    print $out "\n      $curr_block\n";
    print "Extracted and appended curriculums block successfully.\n";
} else {
    die "Could not extract curriculums block from $source";
}

close $out;
