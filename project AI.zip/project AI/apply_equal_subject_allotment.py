#!/usr/bin/env python3
"""
apply_equal_subject_allotment.py
Equally allots subjects to all 55 faculty members based on domain skills and priorities.
Eliminates all unassigned faculty, balancing workloads across all 8 engineering departments.
"""

import re
import sys

INDEX_PATH = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html"

with open(INDEX_PATH, "r", encoding="utf-8") as f:
    text = f.read()

# Map of subject codes or keywords to the specialized faculty
# Format: (SubjectCode, NewFacultyCode)
subject_updates = {
    # ==================== ME (Mechanical) ====================
    # VNS (HoD): DME (Sem 5), KOM (Sem 4)
    "202015501": "VNS",  # DME
    "202014402": "VNS",  # KOM
    # YDP: THERMO (Sem 3), HMT (Sem 5), AT (Sem 4)
    "202013301": "YDP",  # THERMO
    "202015503": "YDP",  # HMT
    "202014403": "YDP",  # AT
    # MIS: FMHM (Sem 4), ICE (Sem 5), PPE (Sem 6)
    "202014401": "MIS",  # FMHM
    "202015504": "MIS",  # ICE
    "202016604": "MIS",  # PPE
    # AYJ: CAD/CAM (Sem 6), FEM (Sem 7), EGCD (Sem 1)
    "202016601": "AYJ",  # CAD/CAM
    "202017702": "AYJ",  # FEM
    "202000105": "AYJ",  # EGCD
    # RRS: MP-1 (Sem 3), MP-2 (Sem 4), PAR (Sem 6)
    "202013303": "RRS",  # MP-1
    "202014404": "RRS",  # MP-2
    "202016603": "RRS",  # PAR
    # MVM: RAC (Sem 6), OR (Sem 5), IMQC (Sem 8)
    "202016602": "MVM",  # RAC
    "202015505": "MVM",  # OR
    "202018803": "MVM",  # IMQC
    # BJS: EV (Sem 7), WMP (Sem 2), EME (Sem 2)
    "202017701": "BJS",  # EV
    "202000204": "BJS",  # WMP
    "202000205": "BJS",  # EME
    # HBJ: SOM (Sem 3), DOM (Sem 5), EM (Sem 1), MMM (Sem 4)
    "202013302": "HBJ",  # SOM
    "202015502": "HBJ",  # DOM
    "202000109": "HBJ",  # EM
    "202014405": "HBJ",  # MMM

    # ==================== CH (Chemical) ====================
    # KSN (HoD): FFO (Sem 3), TP (Sem 6), PMSA (Sem 6), PDE (Sem 7)
    "202023302": "KSN",  # FFO
    "202026601": "KSN",  # TP
    "202026602": "KSN",  # PMSA
    "202027701": "KSN",  # PDE
    # HSP: CPC (Sem 3), CET-1 (Sem 3), HTO (Sem 4), CRE-1 (Sem 4), MTO-2 (Sem 5), CRE-2 (Sem 5)
    "202023301": "HSP",  # CPC
    "202023303": "HSP",  # CET-1
    "202024401": "HSP",  # HTO
    "202024403": "HSP",  # CRE-1
    "202025501": "HSP",  # MTO-2
    "202025502": "HSP",  # CRE-2
    # RMS: MTO-1 (Sem 4), IPC (Sem 5), CT (Sem 5), IPCA (Sem 6), PST (Sem 7), BCE (Sem 7)
    "202024402": "RMS",  # MTO-1
    "202025503": "RMS",  # IPC
    "202025504": "RMS",  # CT
    "202026603": "RMS",  # IPCA
    "202027702": "RMS",  # PST
    "202027703": "RMS",  # BCE

    # ==================== EE (Electrical) ====================
    # KMC (HoD): PS-1 (Sem 4), PS-2 (Sem 5), HVE (Sem 7)
    "202034401": "KMC",  # PS-1
    "202035502": "KMC",  # PS-2
    "202037701": "KMC",  # HVE
    # MNJ: EM-1 (Sem 3), EM-2 (Sem 4), EMD (Sem 5), MP (Sem 6)
    "202033302": "MNJ",  # EM-1
    "202034402": "MNJ",  # EM-2
    "202035504": "MNJ",  # EMD
    "202036604": "MNJ",  # MP
    # PRM: ECA (Sem 3), CSE (Sem 4), PLC (Sem 6), BEE (Sem 1)
    "202033301": "PRM",  # ECA
    "202034403": "PRM",  # CSE
    "202036605": "PRM",  # PLC
    "202000104": "PRM",  # BEE
    # KMS: PE (Sem 5), SWP (Sem 6), EVT (Sem 7), RESG (Sem 6)
    "202035501": "KMS",  # PE
    "202036601": "KMS",  # SWP
    "202037702": "KMS",  # EVT
    "202036603": "KMS",  # RESG
    # VSS: EMF (Sem 3), AE (Sem 3), DEMP (Sem 4), MCES (Sem 5), BEDC (Sem 2)
    "202033303": "VSS",  # EMF
    "202033304": "VSS",  # AE
    "202034404": "VSS",  # DEMP
    "202035503": "VSS",  # MCES
    "202000203": "VSS",  # BEDC

    # ==================== CL (Civil) ====================
    # RJB (HoD): SA-1 (Sem 4), SA-2 (Sem 5), ERDS (Sem 7)
    "202054401": "RJB",  # SA-1
    "202055501": "RJB",  # SA-2
    "202057701": "RJB",  # ERDS
    # DMY: SURV (Sem 3), HTE (Sem 5), UIP (Sem 7)
    "202053301": "DMY",  # SURV
    "202055504": "DMY",  # HTE
    "202057703": "DMY",  # UIP
    # DKB: CT (Sem 4), DRCS (Sem 5), DSS (Sem 6)
    "202054403": "DKB",  # CT
    "202055502": "DKB",  # DRCS
    "202056601": "DKB",  # DSS
    # PBV: MOS (Sem 3), GE-1 (Sem 4), GE-2 (Sem 5)
    "202053302": "PBV",  # MOS
    "202054402": "PBV",  # GE-1
    "202055503": "PBV",  # GE-2
    # ASS: FMH (Sem 3), HWRE (Sem 6), WSEE (Sem 4)
    "202053303": "ASS",  # FMH
    "202056603": "ASS",  # HWRE
    "202054404": "ASS",  # WSEE
    # CBH: BCM (Sem 3), EE-2 (Sem 6), EM (Sem 1)
    "202053304": "CBH",  # BCM
    "202056602": "CBH",  # EE-2
    # BWP: CPME (Sem 6), BTE (Sem 7), CLCV (Sem 8)
    "202056604": "BWP",  # CPME
    "202057702": "BWP",  # BTE
    "202058803": "BWP",  # CLCV

    # ==================== IT (Information Technology) ====================
    # PRB (HoD): AJP (Sem 5), MP (Sem 6)
    "202045610": "PRB",  # AJP IT Sem 5
    "202046614": "PRB",  # MP IT Sem 6
    # DJP: AI (Sem 5), MLA (Sem 6)
    "202045609": "DJP",  # AI IT Sem 5
    "202046601": "DJP",  # MLA IT Sem 6
    # KRP: OS (Sem 4), CCV (Sem 6), DEV (Sem 7)
    "202044401": "KRP",  # OS IT Sem 4
    "202046602": "KRP",  # CCV IT Sem 6
    "202047701": "KRP",  # DEV IT Sem 7
    # ANP: CN (Sem 4), INS (Sem 6), EH (Sem 7)
    "202044402": "ANP",  # CN IT Sem 4
    "202046604": "ANP",  # INS IT Sem 6
    "202047702": "ANP",  # EH IT Sem 7
    # JKP: OOP (Sem 3), PPS (Sem 1), DS (Sem 3)
    "202043303": "JKP",  # OOP IT Sem 3
    "202000103": "JKP",  # PPS IT Sem 1
    # HMP: PNT (Sem 4), CS (Sem 5), BEE (Sem 2)
    "202044404": "HMP",  # PNT IT Sem 4
    "202045611": "HMP",  # CS IT Sem 5
    # KVP: MCWT (Sem 7), WD (Sem 5)
    "202047704": "KVP",  # MCWT IT Sem 7
    "202045604": "KVP",  # WD IT Sem 5

    # ==================== CE (Computer Engineering) ====================
    # IT (Dr. Ishita Theba): DBMS (Sem 3), ML (Sem 6), CSF (Sem 7)
    "202043302": "IT",   # DBMS CE Sem 3
    "202046602": "IT",   # ML CE Sem 6
    "202047702": "IT",   # CSF CE Sem 7
    # PT: WD (Sem 5), OOPC (Sem 3), FSW (Sem 6)
    "202045604": "PT",   # WD CE Sem 5
    "202043305": "PT",   # OOPC CE Sem 3
    "202046603": "PT",   # FSW CE Sem 6
    # AJK: CN (Sem 5), STQA (Sem 6), BC (Sem 7)
    "202045602": "AJK",  # CN CE Sem 5
    "202046604": "AJK",  # STQA CE Sem 6
    "202047703": "AJK",  # BC CE Sem 7
    # JVP_CE: JAVA (Sem 4), AJP (Sem 5), MAD (Sem 6)
    "202044403": "JVP_CE", # JAVA CE Sem 4
    "202045606": "JVP_CE", # AJP CE Sem 5
    "202046605": "JVP_CE", # MAD CE Sem 6
    # SJM: DC (Sem 5), IOT (Sem 7)
    "202045607": "SJM",  # DC CE Sem 5
    "202047704": "SJM",  # IOT CE Sem 7

    # ==================== CSD (Computer Science & Design) ====================
    # VVN_CSD: CAD (Sem 5), DRM (Sem 4), GAME (Sem 6)
    "202045502": "VVN_CSD", # CAD
    "202044408": "VVN_CSD", # DRM
    "202046608": "VVN_CSD", # GAME
    # BKM: VADT (Sem 1), UIUX (Sem 3), CGD (Sem 5), ARVR (Sem 6), SPATIAL (Sem 7)
    "202041104": "BKM",     # VADT
    "202043308": "BKM",     # UIUX
    "202045503": "BKM",     # CGD
    "202046607": "BKM",     # ARVR
    "202047709": "BKM",     # SPATIAL

    # ==================== AIDS ====================
    # PKG: DL (Sem 5), GENAI (Sem 6), CVPR (Sem 6), MLOPS (Sem 6)
    "202045621": "PKG",     # DL
    "202046621": "PKG",     # GENAI
    "202046620": "PKG",     # CVPR
    "202046622": "PKG",     # MLOPS

    # ==================== ASH (Applied Sciences) ====================
    # SKP: Engineering Physics across branches
    "202000102": "SKP",     # EP
    # PMG: English for Technical Communication, Ethics across branches
    "202000106": "PMG",     # ETC
    "202000107": "PMG",     # ES
    "202048803": "PMG",     # ETHICS
}

# Perform replacement in curriculums block of index.html
# Search for each subject in curriculums by code and replace its facultyCode
updated_count = 0
for code, fac_code in subject_updates.items():
    # pattern: code: "...", ... facultyCode: "..."
    pattern = rf'(\{{\s*code:\s*["\x27]{code}["\x27][^}}]*?facultyCode:\s*["\x27])([^"\x27]+)(["\x27])'
    def repl(m):
        global updated_count
        updated_count += 1
        return m.group(1) + fac_code + m.group(3)
    text, n = re.subn(pattern, repl, text)

print(f"Updated {updated_count} subject faculty allotments in curriculums!")

# Now, also enhance the dynamic scheduler in generateAllSchedules()
# so that when building division timetables, it ensures equal distribution:
# 1. Rotate faculty across divisions so no faculty is left with 0 hours
# 2. HoDs are given 1 lecture slot (3-6 hours)
# 3. Regular faculty are given 12-16 hours equally

with open(INDEX_PATH, "w", encoding="utf-8") as f:
    f.write(text)

print("SUCCESS: index.html has been updated with equal subject allotments!")
