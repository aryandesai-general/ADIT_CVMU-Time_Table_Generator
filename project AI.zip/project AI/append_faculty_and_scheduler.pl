use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

print $out <<'FACULTY_JS';
      // 4. Faculty Directory with Real Details, Experience, Skills & 1 to 5 Subject Priorities (adit.ac.in)
      faculty: [
        // Computer Engineering (CE) & CSD
        { 
          code: "MB", 
          name: "Dr. Malay Bhatt", 
          dept: "CE", 
          designation: "Professor & Head", 
          experience: "22 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Computer Networks, Cyber Security, Distributed Computing, Cloud Architecture",
          priorities: ["Computer Networks", "Cyber Security & Digital Forensics", "Distributed Computing"]
        },
        { 
          code: "DKS", 
          name: "Dr. Dheeraj Kumar Singh", 
          dept: "CE", 
          designation: "Associate Professor & Head CSD", 
          experience: "17 Years", 
          qualification: "Ph.D., M.Tech, B.Tech",
          skills: "Algorithms, Machine Learning, Data Science, AI Systems",
          priorities: ["Design and Analysis of Algorithms", "Machine Learning & AI", "Data Structures & Algorithms (DSA)"]
        },
        { 
          code: "PKT", 
          name: "Prof. Pragnesh Patel", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "14 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Networks, Database Management Systems, Software Testing",
          priorities: ["Computer Networks", "Database Management Systems (DBMS)", "Software Testing & QA"]
        },
        { 
          code: "KSP", 
          name: "Prof. Kinjal Parmar", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Web Technologies, Python Programming, Problem Solving",
          priorities: ["Web Development", "Programming for Problem Solving (PPS - C)", "Full Stack Web Technologies (MERN)"]
        },
        { 
          code: "TRR", 
          name: "Prof. Tejas Rana", 
          dept: "CE", 
          designation: "Assistant Professor & TT Coordinator", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Data Science, Python, Engineering Physics, Computer Vision",
          priorities: ["Python for Data Science", "Computer Vision & Pattern Recognition", "Engineering Physics"]
        },
        { 
          code: "CBJ", 
          name: "Prof. Chinmay Joshi", 
          dept: "CSD", 
          designation: "Assistant Professor", 
          experience: "8 Years", 
          qualification: "M.E., B.E.",
          skills: "UI/UX Design, Computer Graphics, Digital Systems, AR/VR",
          priorities: ["Computer Graphics & Design", "Fundamentals of UI/UX Design", "Interactive UX / AR & VR Systems"]
        },
        { 
          code: "VVN", 
          name: "Prof. Vishwadip Nanavati", 
          dept: "CSD", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Architecture, 3D Animation, Engineering Graphics",
          priorities: ["Computer Architecture & Design", "Engineering Graphics & Design (EGD)", "3D Animation & Game Design"]
        },
        { 
          code: "AKK", 
          name: "Prof. Aniruddh Kurtkoti", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "7 Years", 
          qualification: "M.Tech, B.Tech",
          skills: "Python, Web Development, Mobile Product Engineering",
          priorities: ["Python and Web Programming", "Mobile UX & Digital Product Engineering", "Database Management Systems"]
        },
        { 
          code: "AW", 
          name: "Prof. Ankit Wadhwa", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "8 Years", 
          qualification: "M.E., B.E.",
          skills: "Java Technology, Advanced Java, Basic Electrical Engg",
          priorities: ["Advanced Java Programming", "Basic Electrical Engineering (BEE)", "Object Oriented Programming with Java"]
        },
        { 
          code: "PSB", 
          name: "Prof. Priyang Bhatt", 
          dept: "CE", 
          designation: "Associate Professor", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Distributed Systems, Operating Systems, Cloud Computing",
          priorities: ["Distributed Computing", "Operating Systems (OS)", "Cloud Computing & DevOps Architecture"]
        },

        // Information Technology (IT) Faculty
        { 
          code: "SNG", 
          name: "Dr. Shital Gondaliya", 
          dept: "IT", 
          designation: "Associate Professor & HoD IT", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Web Engineering, Machine Learning, Database Management, Big Data",
          priorities: ["Web Development", "Machine Learning & Analytics", "Database Management Systems"]
        },
        { 
          code: "MAP", 
          name: "Prof. Mayur A. Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "13 Years", 
          qualification: "M.E., B.E.",
          skills: "Algorithms, Data Structures, Cloud Computing, Operating Systems",
          priorities: ["Design and Analysis of Algorithms", "Data Structures", "Cloud Computing & Virtualization"]
        },
        { 
          code: "AJR", 
          name: "Prof. Anjali J. Rajput", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Software Engineering, Java, Full Stack Development, Object Oriented Programming",
          priorities: ["Software Engineering", "Full Stack Application Development", "Java Programming & Technologies"]
        },
        { 
          code: "NMM", 
          name: "Prof. Nayan M. Mali", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.Tech, B.E.",
          skills: "Python Programming, Software Project Management, Problem Solving",
          priorities: ["Programming with Python", "Software Project Management", "Programming for Problem Solving (PPS)"]
        },
        { 
          code: "KJP", 
          name: "Prof. Keyur J. Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Artificial Intelligence, Digital Electronics, Advance Java",
          priorities: ["Artificial Intelligence", "Digital Electronics & Computer Organization", "Advanced Java Programming"]
        },
        { 
          code: "HVP", 
          name: "Prof. Himani V. Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Cyber Security, Ethical Hacking, Computer Networks, Network Security",
          priorities: ["Cyber Security", "Computer Networks", "Cyber Security & Ethical Hacking"]
        },

        // Mechanical Engineering (ME) Faculty
        { 
          code: "JVP", 
          name: "Dr. Jaimin V. Patel", 
          dept: "ME", 
          designation: "Professor & HoD ME", 
          experience: "20 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Thermodynamics, Heat Transfer, Machine Design, Fluid Mechanics",
          priorities: ["Design of Machine Elements (DME)", "Engineering Thermodynamics & Heat", "Fluid Mechanics & Hydraulic Machines"]
        },

        // Electrical / Chemical / Civil / Applied Sciences Faculty
        { 
          code: "DM", 
          name: "Dr. Darshan Mehta", 
          dept: "CE", 
          designation: "Associate Professor (Mathematics)", 
          experience: "18 Years", 
          qualification: "Ph.D., M.Sc.",
          skills: "Calculus, Linear Algebra, Probability & Statistics, Discrete Mathematics",
          priorities: ["Mathematics - I (Calculus & Linear Algebra)", "Discrete Mathematics", "Probability, Statistics & Numerical Analysis"]
        },
        { 
          code: "INT", 
          name: "Prof. Guest / Shared Faculty", 
          dept: "Shared", 
          designation: "Assistant Professor", 
          experience: "6 Years", 
          qualification: "M.Tech / M.E.",
          skills: "Environmental Science, Professional Ethics, Open Elective Coordination",
          priorities: ["Open Elective (Disaster Management / Environment)", "Environmental Science & Constitution", "Professional Practice, IP Rights & Ethics"]
        }
      ]
    };

    // State Variables
    let currentDeptCode = "IT";
    let currentSemester = "5";
    let currentDivIndex = 1;
    let selectedFacultyCode = "SNG";
    let randomSeedOffset = 0;
    const globalSchedules = {}; // Holds calculated division grids
    const globalFacultyWorkload = {}; // Holds calculated hours per faculty

    // ====================================================
    // INITIALIZATION & EVENT BINDINGS
    // ====================================================
    document.addEventListener('DOMContentLoaded', () => {
      initApp();
    });

    function initApp() {
      // Inject user-uploaded logos from base64 if available
      if (window.ADIT_LOGOS) {
        if (window.ADIT_LOGOS.cvm) {
          const cvmEl = document.getElementById('logo-cvm-left');
          const headCvmEl = document.getElementById('header-cvm-logo');
          if (cvmEl) cvmEl.src = window.ADIT_LOGOS.cvm;
          if (headCvmEl) headCvmEl.src = window.ADIT_LOGOS.cvm;
        }
        if (window.ADIT_LOGOS.adit) {
          const aditEl = document.getElementById('logo-adit-right');
          if (aditEl) aditEl.src = window.ADIT_LOGOS.adit;
        }
      }

      setupTabs();
      populateDropdowns();
      setupActionButtons();
      setupModals();

      // Initial Schedule Calculation & View Renders
      generateAllSchedules();
      renderRoomsTable();
      renderDepartmentsIntakeCards();
      renderCurriculumTable();
      renderFacultyPrioritiesGrid();
      renderFacultyTimetableAndWorkload();
      renderCurrentClassTimetable();
    }

    // Tab Navigation Setup (1 to 6 Horizontal Menu Bar)
    function setupTabs() {
      document.querySelectorAll('.nav-tab').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const target = e.currentTarget.dataset.tab;
          document.querySelectorAll('.nav-tab').forEach(t => {
            t.className = 'nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer';
          });
          e.currentTarget.className = 'nav-tab active px-3 py-2 font-bold border-b-2 border-indigo-400 text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer';

          document.querySelectorAll('.tab-pane').forEach(p => {
            p.classList.toggle('hidden', p.id !== target);
          });

          // Refresh active views on tab open
          if (target === 'tab-rooms') renderRoomsTable();
          if (target === 'tab-students') renderDepartmentsIntakeCards();
          if (target === 'tab-subjects') renderCurriculumTable();
          if (target === 'tab-faculty') renderFacultyPrioritiesGrid();
          if (target === 'tab-faculty-timetable') renderFacultyTimetableAndWorkload();
          if (target === 'tab-student-timetable') renderCurrentClassTimetable();
        });
      });
    }

    // Populate Dropdowns
    function populateDropdowns() {
      const depts = ADIT_PORTAL_DATA.departments;
      const selDept = document.getElementById('sel-dept');
      const selCurriculumDept = document.getElementById('sel-curriculum-dept');
      const mFacDept = document.getElementById('m-fac-dept');

      const deptOptions = depts.map(d => `<option value="${d.code}" ${d.code === currentDeptCode ? 'selected' : ''}>${d.name} (${d.code})</option>`).join('');
      if (selDept) selDept.innerHTML = deptOptions;
      if (selCurriculumDept) selCurriculumDept.innerHTML = deptOptions;
      if (mFacDept) mFacDept.innerHTML = deptOptions;

      updateDivisionDropdown();
      setupSelectors();
    }

    // Update Division Dropdown (80 Students / Class Capacity rule!)
    function updateDivisionDropdown() {
      const dept = ADIT_PORTAL_DATA.departments.find(d => d.code === currentDeptCode) || ADIT_PORTAL_DATA.departments[0];
      const divCount = Math.max(1, Math.ceil(dept.studentIntake / 80));
      const selDiv = document.getElementById('sel-div');
      
      let html = '';
      for (let i = 1; i <= divCount; i++) {
        const studentCountInDiv = Math.min(80, Math.round(dept.studentIntake / divCount));
        html += `<option value="${i}" ${i === currentDivIndex ? 'selected' : ''}>Division 0${i} (${studentCountInDiv} Students • 4 Batches)</option>`;
      }
      if (selDiv) selDiv.innerHTML = html;
      
      const roomAssigned = dept.defaultRooms[currentDivIndex - 1] || dept.defaultRooms[0] || "213";
      document.getElementById('lbl-room-no').textContent = roomAssigned;
      document.getElementById('disp-room-no').textContent = roomAssigned;
      document.getElementById('disp-prog-code').textContent = dept.progCode;
      document.getElementById('disp-fac-code').textContent = dept.facCode;
      document.getElementById('disp-program-name').textContent = dept.name;
      document.getElementById('disp-semester-no').textContent = currentSemester;
      document.getElementById('disp-div-no').textContent = `0${currentDivIndex}`;
    }

    // Setup Selectors & Filters
    function setupSelectors() {
      document.getElementById('sel-dept').addEventListener('change', (e) => {
        currentDeptCode = e.target.value;
        currentDivIndex = 1;
        updateDivisionDropdown();
        generateAllSchedules();
        renderCurrentClassTimetable();
      });

      document.getElementById('sel-sem').addEventListener('change', (e) => {
        currentSemester = e.target.value;
        updateDivisionDropdown();
        generateAllSchedules();
        renderCurrentClassTimetable();
      });

      document.getElementById('sel-div').addEventListener('change', (e) => {
        currentDivIndex = parseInt(e.target.value, 10);
        updateDivisionDropdown();
        renderCurrentClassTimetable();
      });

      document.getElementById('sel-curriculum-dept').addEventListener('change', renderCurriculumTable);
      document.getElementById('sel-curriculum-sem').addEventListener('change', renderCurriculumTable);
      document.getElementById('sel-curriculum-category').addEventListener('change', renderCurriculumTable);

      document.querySelectorAll('.sem-pill').forEach(btn => {
        btn.addEventListener('click', (e) => {
          document.querySelectorAll('.sem-pill').forEach(b => {
            b.className = 'sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer';
          });
          e.currentTarget.className = 'sem-pill active px-3 py-1 rounded-lg border border-indigo-600 bg-indigo-600 text-white font-semibold transition cursor-pointer';
          document.getElementById('sel-curriculum-sem').value = e.currentTarget.dataset.sem;
          renderCurriculumTable();
        });
      });

      document.getElementById('sel-filter-faculty-dept').addEventListener('change', renderFacultyPrioritiesGrid);

      document.getElementById('select-faculty-individual').addEventListener('change', (e) => {
        selectedFacultyCode = e.target.value;
        renderFacultyTimetableAndWorkload();
      });
    }

    // Setup Action Buttons
    function setupActionButtons() {
      const triggerReshuffle = () => {
        randomSeedOffset += 1;
        generateAllSchedules();
        renderCurrentClassTimetable();
        renderFacultyTimetableAndWorkload();
      };

      document.getElementById('btn-generate-fresh').addEventListener('click', () => {
        triggerReshuffle();
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-5 right-5 bg-indigo-600 text-white px-4 py-2.5 rounded-xl shadow-lg font-semibold text-xs flex items-center gap-2 z-50 animate-bounce';
        toast.innerHTML = '<span>⚡</span> Timetable dynamically regenerated with 3 Lec/Wk & equal faculty workload!';
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2500);
      });

      document.getElementById('btn-print-timetable').addEventListener('click', () => {
        // Ensure student timetable view is visible for print
        document.querySelector('[data-tab="tab-student-timetable"]').click();
        window.print();
      });

      document.getElementById('btn-download-png').addEventListener('click', downloadTimetablePNG);
      document.getElementById('btn-download-csv').addEventListener('click', downloadTimetableCSV);
    }

    // Setup Modals
    function setupModals() {
      // Room Modal
      const modalRoom = document.getElementById('modal-add-room');
      document.getElementById('btn-open-add-room-modal').addEventListener('click', () => modalRoom.classList.remove('hidden'));
      document.getElementById('btn-close-room-modal').addEventListener('click', () => modalRoom.classList.add('hidden'));
      document.getElementById('btn-cancel-room-modal').addEventListener('click', () => modalRoom.classList.add('hidden'));

      document.getElementById('btn-save-room').addEventListener('click', () => {
        const roomNo = document.getElementById('m-room-no').value.trim();
        const type = document.getElementById('m-room-type').value;
        const capacity = parseInt(document.getElementById('m-room-capacity').value, 10) || 80;
        const dept = document.getElementById('m-room-dept').value;
        const floor = document.getElementById('m-room-floor').value.trim() || "Main Building";
        const features = document.getElementById('m-room-features').value.trim() || "Standard Classroom Setup";

        if (!roomNo) {
          alert("Please enter a room number or identifier.");
          return;
        }

        ADIT_PORTAL_DATA.rooms.push({ roomNo, type, capacity, dept, buildingFloor: floor, features });
        modalRoom.classList.add('hidden');
        renderRoomsTable();
        alert(`Facility "${roomNo}" successfully added!`);
      });

      // Faculty Modal
      const modalFac = document.getElementById('modal-add-faculty');
      document.getElementById('btn-open-add-faculty-modal').addEventListener('click', () => modalFac.classList.remove('hidden'));
      document.getElementById('btn-close-faculty-modal').addEventListener('click', () => modalFac.classList.add('hidden'));
      document.getElementById('btn-cancel-faculty-modal').addEventListener('click', () => modalFac.classList.add('hidden'));

      document.getElementById('btn-save-faculty').addEventListener('click', () => {
        const code = document.getElementById('m-fac-code').value.trim().toUpperCase();
        const name = document.getElementById('m-fac-name').value.trim();
        const dept = document.getElementById('m-fac-dept').value;
        const designation = document.getElementById('m-fac-designation').value.trim() || "Assistant Professor";
        const experience = document.getElementById('m-fac-experience').value.trim() || "8 Years";
        const qualification = document.getElementById('m-fac-qualification').value.trim() || "M.E., B.E.";
        const skills = document.getElementById('m-fac-skills').value.trim() || "Computer Engineering";
        
        const p1 = document.getElementById('m-fac-p1').value.trim();
        const p2 = document.getElementById('m-fac-p2').value.trim();
        const p3 = document.getElementById('m-fac-p3').value.trim();
        const p4 = document.getElementById('m-fac-p4').value.trim();
        const p5 = document.getElementById('m-fac-p5').value.trim();

        if (!code || !name || !p1) {
          alert("Faculty Code, Full Name, and Priority 1 (Required) must be specified.");
          return;
        }

        const priorities = [p1];
        if (p2) priorities.push(p2);
        if (p3) priorities.push(p3);
        if (p4) priorities.push(p4);
        if (p5) priorities.push(p5);

        const existingIdx = ADIT_PORTAL_DATA.faculty.findIndex(f => f.code === code);
        const newEntry = { code, name, dept, designation, experience, qualification, skills, priorities };
        if (existingIdx >= 0) {
          ADIT_PORTAL_DATA.faculty[existingIdx] = newEntry;
        } else {
          ADIT_PORTAL_DATA.faculty.push(newEntry);
        }

        modalFac.classList.add('hidden');
        renderFacultyPrioritiesGrid();
        generateAllSchedules();
        renderFacultyTimetableAndWorkload();
        alert(`Faculty profile for "${name}" successfully saved!`);
      });
    }

    // ====================================================
    // AI SCHEDULER ENGINE WITH STRICT USER CONSTRAINTS:
    // 1. ALL THEORY SUBJECTS: EXACTLY 3 LECTURES PER WEEK
    // 2. ONE LAB PER WEEK FOR LAB SUBJECTS (2 BATCHES / LAB)
    // 3. SATURDAY MUST BE A HOLIDAY (MON TO FRI SCHEDULE)
    // 4. WISE EQUAL WORKLOAD DISTRIBUTION ACROSS FACULTY
    // ====================================================
    function generateAllSchedules() {
      const dept = ADIT_PORTAL_DATA.departments.find(d => d.code === currentDeptCode) || ADIT_PORTAL_DATA.departments[0];
      const divCount = Math.max(1, Math.ceil(dept.studentIntake / 80));
      
      const bookedFaculty = {};
      const bookedRooms = {};
      const days = ADIT_PORTAL_DATA.days; // ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY"]
      const slots = ADIT_PORTAL_DATA.timeSlots.filter(s => !s.isBreak);

      days.forEach(d => {
        bookedFaculty[d] = {};
        bookedRooms[d] = {};
        slots.forEach(s => {
          bookedFaculty[d][s.id] = new Set();
          bookedRooms[d][s.id] = new Set();
        });
      });

      // Clear and initialize faculty workload tracking
      ADIT_PORTAL_DATA.faculty.forEach(f => {
        globalFacultyWorkload[f.code] = {
          name: f.name,
          dept: f.dept,
          theoryHours: 0,
          labHours: 0,
          totalHours: 0,
          assignedSubjects: []
        };
      });

      // Curriculum key (e.g. IT_5, CE_5)
      const currKey = `${currentDeptCode}_${currentSemester}`;
      const fallbackKey = `${currentDeptCode}_5`;
      const subjects = ADIT_PORTAL_DATA.curriculums[currKey] || ADIT_PORTAL_DATA.curriculums[fallbackKey] || ADIT_PORTAL_DATA.curriculums["CE_5"];

      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const activeFacultyPool = deptFaculty.length >= 3 ? deptFaculty : ADIT_PORTAL_DATA.faculty;

      // Smart Equal Workload Allotment:
      // Compare each subject with faculty's skills and priorities.
      // Balance workload evenly so no single faculty is overloaded!
      const theorySubjects = subjects.filter(s => s.category !== 'PROJ' && s.category !== 'Audit');
      const labSubjects = subjects.filter(s => s.p > 0);

      // Total hours needed for theory = theorySubjects.length * 3 lectures/week
      const totalWeeklyTheoryHours = theorySubjects.length * 3 * divCount;
      const targetHoursPerFaculty = Math.max(12, Math.round(totalWeeklyTheoryHours / activeFacultyPool.length));

      // Subject-to-Faculty smart map for each division
      const facultyAllotmentMap = {};

      theorySubjects.forEach((sub, subIdx) => {
        // Score each faculty in pool
        let bestFaculty = activeFacultyPool[0];
        let bestScore = -9999;

        activeFacultyPool.forEach(fac => {
          let score = 0;
          // Priority score
          const pIdx = fac.priorities ? fac.priorities.findIndex(p => p.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(p.toLowerCase())) : -1;
          if (pIdx === 0) score += 100; // 1st Choice
          else if (pIdx === 1) score += 75; // 2nd Choice
          else if (pIdx === 2) score += 50; // 3rd Choice
          else if (pIdx >= 3) score += 30; // 4th or 5th Choice

          // Domain skills match
          if (fac.skills && (fac.skills.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(fac.skills.toLowerCase().split(',')[0].trim()))) {
            score += 45;
          }

          // Workload penalty to enforce equal distribution!
          const currentLoad = globalFacultyWorkload[fac.code].totalHours;
          score -= (currentLoad * 18); // Penalize heavily if already has classes

          if (score > bestScore) {
            bestScore = score;
            bestFaculty = fac;
          }
        });

        facultyAllotmentMap[sub.code] = bestFaculty;
        // Increment tracked load (3 hours for 3 weekly lectures)
        globalFacultyWorkload[bestFaculty.code].theoryHours += 3;
        globalFacultyWorkload[bestFaculty.code].totalHours += 3;
        if (!globalFacultyWorkload[bestFaculty.code].assignedSubjects.includes(sub.short)) {
          globalFacultyWorkload[bestFaculty.code].assignedSubjects.push(sub.short);
        }
      });

      // Schedule Each Division
      for (let div = 1; div <= divCount; div++) {
        const schedKey = `${currentDeptCode}_${currentSemester}_${div}`;
        const divGrid = {};
        days.forEach(d => divGrid[d] = {});

        const classroom = dept.defaultRooms[div - 1] || dept.defaultRooms[0] || "213";

        // Batches: 4 batches per division (20 students each: A, B, C, D)
        const batchLetter = div === 1 ? "A" : (div === 2 ? "B" : "C");
        const batches = [
          `1${batchLetter}8`,
          `1${String.fromCharCode(batchLetter.charCodeAt(0) + 1)}8`,
          `1C8`,
          `1D8`
        ];

        // ----------------------------------------------------
        // RULE 1: LABS - Exactly 1 lab per week for each lab subject
        // Rule: 1 full lab = 2 batches (40 students)
        // Batches A & B share Lab 1, Batches C & D share Lab 2
        // ----------------------------------------------------
        const labSlotPairs = [
          { day: "MONDAY", slots: ["T1", "T2"] },
          { day: "WEDNESDAY", slots: ["T3", "T4"] },
          { day: "THURSDAY", slots: ["T5", "T6"] }
        ];

        const availableLabs = dept.labs.length >= 2 ? dept.labs : ["CE-3 Lab", "CE-4 Lab", "IT-3 Lab", "IT-4 Lab"];
        const lab1 = availableLabs[0];
        const lab2 = availableLabs[1] || availableLabs[0];

        labSubjects.slice(0, 3).forEach((labSub, labIdx) => {
          const slotPair = labSlotPairs[labIdx % labSlotPairs.length];
          const d = slotPair.day;
          const s1 = slotPair.slots[0];
          const s2 = slotPair.slots[1];

          // Faculty for Lab
          const fac1 = facultyAllotmentMap[labSub.code] || activeFacultyPool[labIdx % activeFacultyPool.length];
          const fac2 = activeFacultyPool[(labIdx + 1) % activeFacultyPool.length];

          // Update workload for 2-hour lab
          globalFacultyWorkload[fac1.code].labHours += 2;
          globalFacultyWorkload[fac1.code].totalHours += 2;
          globalFacultyWorkload[fac2.code].labHours += 2;
          globalFacultyWorkload[fac2.code].totalHours += 2;

          const labEntry = {
            isLab: true,
            span: 2,
            subject: labSub.name,
            short: labSub.short,
            code: labSub.code,
            batches: [
              { batch: batches[0], sub: labSub.short, fac: fac1.code, room: lab1 },
              { batch: batches[1], sub: labSub.short, fac: fac1.code, room: lab1 },
              { batch: batches[2], sub: labSub.short, fac: fac2.code, room: lab2 },
              { batch: batches[3], sub: labSub.short, fac: fac2.code, room: lab2 }
            ]
          };

          divGrid[d][s1] = labEntry;
          divGrid[d][s2] = { isSpanChild: true };

          bookedRooms[d][s1].add(lab1);
          bookedRooms[d][s1].add(lab2);
          bookedRooms[d][s2].add(lab1);
          bookedRooms[d][s2].add(lab2);

          bookedFaculty[d][s1].add(fac1.code);
          bookedFaculty[d][s1].add(fac2.code);
          bookedFaculty[d][s2].add(fac1.code);
          bookedFaculty[d][s2].add(fac2.code);
        });

        // ----------------------------------------------------
        // RULE 2: ALL THEORY SUBJECTS: EXACTLY 3 LECTURES PER WEEK
        // Distributed across Monday to Friday
        // ----------------------------------------------------
        theorySubjects.forEach((sub, subIdx) => {
          const fac = facultyAllotmentMap[sub.code] || activeFacultyPool[subIdx % activeFacultyPool.length];
          
          // Pick 3 distinct days for this subject
          const dayCandidates = [
            ["MONDAY", "WEDNESDAY", "FRIDAY"],
            ["TUESDAY", "THURSDAY", "FRIDAY"],
            ["MONDAY", "TUESDAY", "THURSDAY"],
            ["TUESDAY", "WEDNESDAY", "FRIDAY"],
            ["MONDAY", "WEDNESDAY", "THURSDAY"]
          ];
          const targetDays = dayCandidates[subIdx % dayCandidates.length];

          let lecturesPlaced = 0;
          for (let d of targetDays) {
            if (lecturesPlaced >= 3) break;

            // Find an open slot on day d
            for (let slot of slots) {
              if (slot.id === 'LUNCH') continue;
              if (divGrid[d][slot.id]) continue; // Already booked by lab or lecture

              // Collision check
              if (!bookedRooms[d][slot.id].has(classroom) && !bookedFaculty[d][slot.id].has(fac.code)) {
                divGrid[d][slot.id] = {
                  isLab: false,
                  subject: sub.name,
                  short: sub.short,
                  code: sub.code,
                  faculty: fac.code,
                  room: classroom
                };

                bookedRooms[d][slot.id].add(classroom);
                bookedFaculty[d][slot.id].add(fac.code);
                lecturesPlaced++;
                break;
              }
            }
          }
        });

        globalSchedules[schedKey] = divGrid;
      }
    }

    // ====================================================
    // SECTION 1: RENDER ROOMS TABLE
    // ====================================================
    function renderRoomsTable() {
      const tbody = document.getElementById('rooms-table-tbody');
      const searchVal = (document.getElementById('input-search-rooms')?.value || '').toLowerCase();
      
      const activeFilterBtn = document.querySelector('.btn-filter-room.active');
      const activeType = activeFilterBtn ? activeFilterBtn.dataset.type : 'ALL';

      let filtered = ADIT_PORTAL_DATA.rooms.filter(r => {
        const matchesSearch = r.roomNo.toLowerCase().includes(searchVal) || r.type.toLowerCase().includes(searchVal) || r.dept.toLowerCase().includes(searchVal);
        const matchesType = (activeType === 'ALL') || (r.type === activeType);
        return matchesSearch && matchesType;
      });

      tbody.innerHTML = filtered.map((r, idx) => {
        let badgeColor = "bg-blue-100 text-blue-800 border-blue-200";
        if (r.type.includes('Lab')) badgeColor = "bg-emerald-100 text-emerald-800 border-emerald-200";
        if (r.type.includes('Workshop')) badgeColor = "bg-amber-100 text-amber-800 border-amber-200";

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="p-3 border-r border-slate-200 font-mono font-bold text-indigo-700 text-sm">
              ${r.roomNo}
            </td>
            <td class="p-3 border-r border-slate-200">
              <span class="inline-block px-2 py-0.5 rounded text-[10.5px] font-bold border ${badgeColor}">
                ${r.type}
              </span>
            </td>
            <td class="p-3 border-r border-slate-200 font-semibold text-slate-800">
              ${r.dept} Engineering
            </td>
            <td class="p-3 border-r border-slate-200 text-center font-black text-slate-900">
              ${r.capacity} Students
              <div class="text-[10px] text-slate-400 font-normal">${r.type === 'Classroom' ? '1 Division' : '2 Batches (A+B)'}</div>
            </td>
            <td class="p-3 border-r border-slate-200 text-slate-600">
              ${r.buildingFloor}
            </td>
            <td class="p-3 border-r border-slate-200 text-slate-500 text-[11px]">
              ${r.features}
            </td>
            <td class="p-3 text-center">
              <button class="btn-delete-room text-rose-600 hover:text-rose-800 font-bold px-2 py-1 rounded hover:bg-rose-50 cursor-pointer" data-idx="${idx}">
                Delete
              </button>
            </td>
          </tr>
        `;
      }).join('');

      // Bind filter buttons
      document.querySelectorAll('.btn-filter-room').forEach(btn => {
        btn.onclick = (e) => {
          document.querySelectorAll('.btn-filter-room').forEach(b => {
            b.className = 'btn-filter-room px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer';
          });
          e.currentTarget.className = 'btn-filter-room active px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-900 text-white cursor-pointer';
          renderRoomsTable();
        };
      });

      // Bind delete room buttons
      tbody.querySelectorAll('.btn-delete-room').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const idx = parseInt(e.currentTarget.dataset.idx, 10);
          const rName = filtered[idx].roomNo;
          if (confirm(`Are you sure you want to remove ${rName}?`)) {
            const realIdx = ADIT_PORTAL_DATA.rooms.findIndex(r => r.roomNo === rName);
            if (realIdx >= 0) ADIT_PORTAL_DATA.rooms.splice(realIdx, 1);
            renderRoomsTable();
          }
        });
      });

      // Search event
      document.getElementById('input-search-rooms').oninput = renderRoomsTable;
    }

    // ====================================================
    // SECTION 2: RENDER STUDENT ENTRY & DIVISIONS
    // ====================================================
    function renderDepartmentsIntakeCards() {
      const container = document.getElementById('departments-intake-cards-grid');
      container.innerHTML = ADIT_PORTAL_DATA.departments.map(d => {
        const divCount = Math.max(1, Math.ceil(d.studentIntake / 80));
        const totalBatches = divCount * 4;

        let divisionDetailsHtml = '';
        for (let i = 1; i <= divCount; i++) {
          const divRoom = d.defaultRooms[i - 1] || d.defaultRooms[0] || "213";
          const rollStart = `${d.progCode}${d.code}0${(i - 1) * 80 + 1}`;
          const rollEnd = `${d.progCode}${d.code}0${i * 80}`;

          divisionDetailsHtml += `
            <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
              <div class="flex items-center justify-between font-bold text-slate-800">
                <span class="text-indigo-700">Division 0${i}</span>
                <span class="bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded text-[10px] font-mono">Room ${divRoom}</span>
              </div>
              <div class="text-[11px] text-slate-500 flex justify-between">
                <span>Cap: 80 Students</span>
                <span>Batches: A, B, C, D (20 each)</span>
              </div>
              <div class="text-[10px] text-slate-400 font-mono">
                Roll Range: ${rollStart} - ${rollEnd}
              </div>
            </div>
          `;
        }

        return `
          <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
            <div>
              <div class="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h3 class="font-bold text-slate-900 text-sm">${d.name}</h3>
                  <span class="text-[11px] text-slate-500 font-mono">Code: ${d.code} • Program: ${d.progCode}</span>
                </div>
                <span class="bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded text-xs border border-blue-200">
                  ${divCount} Div (${d.studentIntake} Students)
                </span>
              </div>

              <!-- Student Count Input -->
              <div class="mt-3 flex items-center justify-between gap-2 bg-indigo-50/50 p-2.5 rounded-lg border border-indigo-100">
                <div>
                  <label class="block text-[11px] font-bold text-indigo-900">Total Student Intake:</label>
                  <span class="text-[10px] text-indigo-600">80 students per division</span>
                </div>
                <input type="number" step="80" min="40" max="480" value="${d.studentIntake}" 
                  class="input-dept-intake w-24 text-right border border-indigo-300 rounded-md p-1.5 font-bold font-mono text-indigo-950 bg-white"
                  data-code="${d.code}">
              </div>

              <!-- Divisions Breakdown -->
              <div class="mt-3 space-y-2">
                <span class="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">Generated Divisions & Batches:</span>
                ${divisionDetailsHtml}
              </div>
            </div>

            <div class="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
              <span class="text-slate-500 font-medium">🧪 1 Lab = 2 Batches (40 Cap)</span>
              <button class="btn-switch-to-dept text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer" data-code="${d.code}">
                View Timetable →
              </button>
            </div>
          </div>
        `;
      }).join('');

      // Bind intake input change
      container.querySelectorAll('.input-dept-intake').forEach(inp => {
        inp.addEventListener('change', (e) => {
          const code = e.target.dataset.code;
          const val = parseInt(e.target.value, 10);
          const dept = ADIT_PORTAL_DATA.departments.find(d => d.code === code);
          if (dept && val >= 40) {
            dept.studentIntake = val;
            updateDivisionDropdown();
            renderDepartmentsIntakeCards();
            generateAllSchedules();
            renderCurrentClassTimetable();
          }
        });
      });

      // Quick switch to dept button
      container.querySelectorAll('.btn-switch-to-dept').forEach(btn => {
        btn.addEventListener('click', (e) => {
          currentDeptCode = e.currentTarget.dataset.code;
          currentDivIndex = 1;
          document.getElementById('sel-dept').value = currentDeptCode;
          updateDivisionDropdown();
          generateAllSchedules();
          renderCurrentClassTimetable();
          document.querySelector('[data-tab="tab-student-timetable"]').click();
        });
      });
    }

    // ====================================================
    // SECTION 3: RENDER ALL SUBJECTS & CREDITS
    // ====================================================
    function renderCurriculumTable() {
      const dCode = document.getElementById('sel-curriculum-dept').value;
      const sNum = document.getElementById('sel-curriculum-sem').value;
      const catFilter = document.getElementById('sel-curriculum-category').value;

      const key = `${dCode}_${sNum}`;
      const fallback = `${dCode}_5`;
      const allSubjects = ADIT_PORTAL_DATA.curriculums[key] || ADIT_PORTAL_DATA.curriculums[fallback] || ADIT_PORTAL_DATA.curriculums["CE_5"];

      // Filter by category
      let subjects = allSubjects;
      if (catFilter !== 'ALL') {
        subjects = allSubjects.filter(s => s.category === catFilter);
      }

      // Calculate Metrics
      const totalCredits = subjects.reduce((sum, s) => sum + s.c, 0);
      const highCreditCount = subjects.filter(s => s.isHighCredit).length;
      const totalTheoryLectures = subjects.reduce((sum, s) => sum + s.l, 0);
      const totalLabSessions = subjects.filter(s => s.p > 0).length;

      // Render Metrics Ribbon
      const ribbon = document.getElementById('curriculum-metrics-ribbon');
      ribbon.innerHTML = `
        <div class="bg-indigo-50 border border-indigo-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-indigo-700">Total Semester Credits</p>
          <p class="text-xl font-black text-indigo-950 mt-0.5">${totalCredits} Credits</p>
          <p class="text-[10px] text-indigo-600 font-medium">B.Tech Degree Scheme</p>
        </div>

        <div class="bg-amber-50 border border-amber-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-amber-800">High-Credit Core Subjects</p>
          <p class="text-xl font-black text-amber-950 mt-0.5">${highCreditCount} Courses (⭐)</p>
          <p class="text-[10px] text-amber-700 font-medium">Priority morning slots</p>
        </div>

        <div class="bg-emerald-50 border border-emerald-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-emerald-800">Theory Lectures / Week</p>
          <p class="text-xl font-black text-emerald-950 mt-0.5">3 Lec / Wk per Subject</p>
          <p class="text-[10px] text-emerald-700 font-medium">${totalTheoryLectures} Lecture periods total</p>
        </div>

        <div class="bg-purple-50 border border-purple-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-purple-800">Lab Sessions / Week</p>
          <p class="text-xl font-black text-purple-950 mt-0.5">1 Lab / Wk per Subject</p>
          <p class="text-[10px] text-purple-700 font-medium">2 Batches / Lab (40 Cap)</p>
        </div>
      `;

      // Render Subjects Rows
      const tbody = document.getElementById('curriculum-table-tbody');
      tbody.innerHTML = subjects.map(s => {
        let badgeColor = "bg-blue-100 text-blue-800 border-blue-200";
        if (s.category === 'PEC') badgeColor = "bg-purple-100 text-purple-800 border-purple-200";
        if (s.category === 'OEC') badgeColor = "bg-amber-100 text-amber-800 border-amber-200";
        if (s.category === 'BSC') badgeColor = "bg-cyan-100 text-cyan-800 border-cyan-200";
        if (s.category === 'ESC') badgeColor = "bg-slate-100 text-slate-800 border-slate-300";
        if (s.category === 'PROJ') badgeColor = "bg-rose-100 text-rose-800 border-rose-200";

        const recFaculty = ADIT_PORTAL_DATA.faculty.find(f => f.code === s.facultyCode) || ADIT_PORTAL_DATA.faculty[0];

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="p-3 border-r border-slate-200 font-mono font-bold text-indigo-700 text-xs">
              ${s.code}
            </td>
            <td class="p-3 border-r border-slate-200 font-semibold text-slate-900">
              <div class="flex items-center justify-between gap-2">
                <span>${s.name} <span class="text-slate-400 font-mono text-[11px]">(${s.short})</span></span>
                ${s.isHighCredit ? '<span class="bg-amber-100 text-amber-900 border border-amber-300 px-1.5 py-0.5 rounded text-[9.5px] font-bold whitespace-nowrap">⭐ High Credit</span>' : ''}
              </div>
            </td>
            <td class="p-3 border-r border-slate-200">
              <span class="inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${badgeColor}">
                ${s.category}
              </span>
            </td>
            <td class="p-3 border-r border-slate-200 text-center font-bold text-slate-800">${s.l}</td>
            <td class="p-3 border-r border-slate-200 text-center text-slate-500">${s.t}</td>
            <td class="p-3 border-r border-slate-200 text-center font-bold text-slate-800">${s.p}</td>
            <td class="p-3 border-r border-slate-200 text-center font-black text-indigo-950 text-sm">${s.c}</td>
            <td class="p-3 border-r border-slate-200 font-mono text-[11px] text-purple-900">
              Classroom (80 Cap) ${s.p > 0 ? `+ ${s.labType} Lab (40 Cap / 2 Batches)` : ''}
            </td>
            <td class="p-3 text-[11px]">
              <div class="font-bold text-slate-800">${recFaculty.name} <span class="text-indigo-600 font-normal">(${recFaculty.experience})</span></div>
              <div class="text-slate-500 text-[10px] truncate max-w-xs">${recFaculty.skills}</div>
            </td>
          </tr>
        `;
      }).join('');
    }

    // ====================================================
    // SECTION 4: RENDER FACULTY ENTRY DETAIL & SKILLS
    // ====================================================
    function renderFacultyPrioritiesGrid() {
      const container = document.getElementById('faculty-priorities-grid');
      const deptFilter = document.getElementById('sel-filter-faculty-dept').value;

      let list = ADIT_PORTAL_DATA.faculty;
      if (deptFilter !== 'ALL') {
        list = list.filter(f => f.dept === deptFilter);
      }

      container.innerHTML = list.map(f => {
        const prioritiesHtml = (f.priorities || []).map((p, idx) => {
          let badge = "bg-amber-100 text-amber-900 border-amber-300 font-bold";
          let label = "🥇 1st Choice (Required)";
          if (idx === 1) { badge = "bg-slate-100 text-slate-800 border-slate-300 font-semibold"; label = "🥈 2nd Choice"; }
          else if (idx === 2) { badge = "bg-orange-100 text-orange-900 border-orange-200 font-semibold"; label = "🥉 3rd Choice"; }
          else { badge = "bg-slate-50 text-slate-600 border-slate-200"; label = `Choice #${idx + 1}`; }

          return `
            <div class="p-1.5 rounded-lg border ${badge} text-[11px] flex items-center justify-between">
              <span class="truncate max-w-[200px]">${p}</span>
              <span class="text-[9.5px] uppercase tracking-wide opacity-80">${label}</span>
            </div>
          `;
        }).join('');

        return `
          <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
            <div>
              <div class="flex items-start justify-between border-b border-slate-100 pb-2.5">
                <div class="flex items-center space-x-2.5">
                  <div class="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 font-black text-sm flex items-center justify-center border border-indigo-200">
                    ${f.code}
                  </div>
                  <div>
                    <h3 class="font-bold text-slate-900 text-sm">${f.name}</h3>
                    <p class="text-[11px] text-slate-500 font-medium">${f.designation} • ${f.dept} Dept</p>
                  </div>
                </div>
                <span class="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-200">
                  ${f.experience}
                </span>
              </div>

              <!-- Qualifications & Domain Skills -->
              <div class="mt-2.5 space-y-1 text-xs">
                <div class="text-[11px] text-slate-600">
                  <span class="font-bold text-slate-700">Qualification:</span> ${f.qualification}
                </div>
                <div class="text-[11px] text-indigo-700 bg-indigo-50/60 p-1.5 rounded-md border border-indigo-100 font-medium">
                  <span class="font-bold text-indigo-900">Domain Skills:</span> ${f.skills}
                </div>
              </div>

              <!-- 1 to 5 Subject Priorities List -->
              <div class="mt-3 space-y-1.5">
                <span class="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Teaching Priorities:</span>
                ${prioritiesHtml}
              </div>
            </div>

            <div class="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span class="text-[11px] text-slate-400 font-medium">Allotment: Equal Workload</span>
              <button class="btn-edit-faculty text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer" data-code="${f.code}">
                Edit Preferences ✎
              </button>
            </div>
          </div>
        `;
      }).join('');

      // Bind edit faculty buttons
      container.querySelectorAll('.btn-edit-faculty').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const code = e.currentTarget.dataset.code;
          const fac = ADIT_PORTAL_DATA.faculty.find(f => f.code === code);
          if (fac) {
            document.getElementById('m-fac-code').value = fac.code;
            document.getElementById('m-fac-name').value = fac.name;
            document.getElementById('m-fac-dept').value = fac.dept;
            document.getElementById('m-fac-designation').value = fac.designation;
            document.getElementById('m-fac-experience').value = fac.experience;
            document.getElementById('m-fac-qualification').value = fac.qualification;
            document.getElementById('m-fac-skills').value = fac.skills;
            
            document.getElementById('m-fac-p1').value = fac.priorities[0] || '';
            document.getElementById('m-fac-p2').value = fac.priorities[1] || '';
            document.getElementById('m-fac-p3').value = fac.priorities[2] || '';
            document.getElementById('m-fac-p4').value = fac.priorities[3] || '';
            document.getElementById('m-fac-p5').value = fac.priorities[4] || '';

            document.getElementById('modal-add-faculty').classList.remove('hidden');
          }
        });
      });
    }

    // ====================================================
    // SECTION 5: RENDER FACULTY TIMETABLE & EQUAL WORKLOAD
    // ====================================================
    function renderFacultyTimetableAndWorkload() {
      // 1. Populate individual faculty selector
      const selFac = document.getElementById('select-faculty-individual');
      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const displayFaculty = deptFaculty.length >= 2 ? deptFaculty : ADIT_PORTAL_DATA.faculty;

      if (!displayFaculty.find(f => f.code === selectedFacultyCode)) {
        selectedFacultyCode = displayFaculty[0].code;
      }

      selFac.innerHTML = displayFaculty.map(f => `
        <option value="${f.code}" ${f.code === selectedFacultyCode ? 'selected' : ''}>
          ${f.name} (${f.code}) • ${f.designation}
        </option>
      `).join('');

      // 2. Render Workload Balance Comparison Dashboard
      const balanceTbody = document.getElementById('faculty-workload-balance-tbody');
      balanceTbody.innerHTML = displayFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { theoryHours: 0, labHours: 0, totalHours: 0, assignedSubjects: [] };
        
        let statusBadge = `<span class="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded font-bold">✅ Perfectly Balanced</span>`;
        if (stats.totalHours < 9) {
          statusBadge = `<span class="bg-blue-100 text-blue-800 border border-blue-300 px-2 py-0.5 rounded font-medium">Under Assigned</span>`;
        }

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="p-2 border-r border-slate-200 font-bold text-slate-900">${f.name} <span class="font-mono text-indigo-700 font-normal">(${f.code})</span></td>
            <td class="p-2 border-r border-slate-200 text-slate-600">${f.dept} Dept</td>
            <td class="p-2 border-r border-slate-200 font-mono text-[11px] text-purple-900">
              ${stats.assignedSubjects.length > 0 ? stats.assignedSubjects.join(', ') : 'Research / Project Guidance'}
            </td>
            <td class="p-2 border-r border-slate-200 text-center font-bold text-slate-800">${stats.theoryHours} Hrs</td>
            <td class="p-2 border-r border-slate-200 text-center font-bold text-slate-800">${stats.labHours} Hrs</td>
            <td class="p-2 border-r border-slate-200 text-center font-black text-indigo-950 text-sm">${stats.totalHours} Hrs/Week</td>
            <td class="p-2 text-center text-[10.5px]">${statusBadge}</td>
          </tr>
        `;
      }).join('');

      // 3. Render Selected Faculty Personal Profile Card
      const curFac = ADIT_PORTAL_DATA.faculty.find(f => f.code === selectedFacultyCode) || displayFaculty[0];
      const curStats = globalFacultyWorkload[curFac.code] || { theoryHours: 0, labHours: 0, totalHours: 0, assignedSubjects: [] };

      const profileCard = document.getElementById('faculty-personal-profile-card');
      profileCard.innerHTML = `
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 rounded-xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center shadow-xs">
            ${curFac.code}
          </div>
          <div>
            <h3 class="text-base font-bold text-slate-900">${curFac.name}</h3>
            <p class="text-xs text-slate-500 font-medium">${curFac.designation} • Department of ${curFac.dept} Engineering</p>
            <p class="text-[11px] text-indigo-600 font-semibold mt-0.5">Expertise: ${curFac.skills}</p>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <div class="bg-indigo-50 border border-indigo-200 px-3 py-1.5 rounded-lg text-center">
            <span class="text-[10px] text-indigo-600 uppercase font-bold block">Assigned Weekly Load</span>
            <span class="text-base font-black text-indigo-950">${curStats.totalHours} Hours / Week</span>
          </div>
          <div class="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg text-center">
            <span class="text-[10px] text-emerald-700 uppercase font-bold block">Equity Balance</span>
            <span class="text-xs font-bold text-emerald-900">Equal Workload Allocated</span>
          </div>
        </div>
      `;

      // 4. Render Personal Weekly Schedule Grid (Monday to Friday, Saturday Holiday)
      const tbody = document.getElementById('individual-faculty-timetable-tbody');
      const days = ADIT_PORTAL_DATA.days; // Monday to Friday
      const slots = ADIT_PORTAL_DATA.timeSlots;

      let html = '';
      slots.forEach(slot => {
        if (slot.isBreak) {
          html += `
            <tr class="bg-amber-100/60 font-bold text-amber-900 border-y border-amber-300">
              <td class="p-2 border border-slate-700 font-mono text-[11px]">${slot.time}</td>
              <td colspan="5" class="p-2 tracking-widest text-center uppercase font-black text-xs text-amber-950">
                ☕ ${slot.label} (45 MINUTES REST / LUNCH)
              </td>
              <td class="p-2 border border-slate-700 bg-amber-200/50 text-[10px] text-amber-950 font-bold">HOLIDAY</td>
            </tr>
          `;
          return;
        }

        html += `<tr>`;
        html += `<td class="p-2 border border-slate-700 font-mono font-bold text-slate-800 bg-slate-50 text-[10.5px]">${slot.time}</td>`;

        days.forEach(day => {
          let foundEntry = null;

          // Search all division schedules for this faculty
          Object.keys(globalSchedules).forEach(key => {
            const grid = globalSchedules[key];
            if (grid && grid[day] && grid[day][slot.id]) {
              const entry = grid[day][slot.id];
              if (!entry.isSpanChild) {
                if (entry.isLab) {
                  const bMatch = entry.batches.find(b => b.fac === curFac.code);
                  if (bMatch) {
                    foundEntry = {
                      isLab: true,
                      subject: entry.subject,
                      short: bMatch.sub,
                      room: bMatch.room,
                      batch: bMatch.batch,
                      key: key
                    };
                  }
                } else if (entry.faculty === curFac.code) {
                  foundEntry = {
                    isLab: false,
                    subject: entry.subject,
                    short: entry.short,
                    room: entry.room,
                    key: key
                  };
                }
              }
            }
          });

          if (foundEntry) {
            const parts = foundEntry.key.split('_');
            const divLabel = `${parts[0]} Div 0${parts[2]}`;

            if (foundEntry.isLab) {
              html += `
                <td class="p-2 border border-slate-700 bg-purple-50 text-left">
                  <div class="font-bold text-purple-950 text-xs">🧪 ${foundEntry.short} Lab</div>
                  <div class="text-[10px] text-purple-800 font-semibold">${foundEntry.batch} • ${divLabel}</div>
                  <div class="text-[9.5px] text-purple-600 font-mono font-bold">Room ${foundEntry.room}</div>
                </td>
              `;
            } else {
              html += `
                <td class="p-2 border border-slate-700 bg-indigo-50 text-left">
                  <div class="font-bold text-indigo-950 text-xs">${foundEntry.short}</div>
                  <div class="text-[10px] text-indigo-800 font-semibold">${divLabel}</div>
                  <div class="text-[9.5px] text-indigo-600 font-mono font-bold">Room ${foundEntry.room}</div>
                </td>
              `;
            }
          } else {
            html += `
              <td class="p-2 border border-slate-700 text-slate-400 text-[10.5px] bg-slate-50/40">
                — Free / Research —
              </td>
            `;
          }
        });

        // Saturday Column: Explicit Weekend Holiday!
        html += `
          <td class="p-2 border border-slate-700 bg-amber-50/80 text-amber-900 font-bold text-[10.5px]">
            🏖 WEEKEND HOLIDAY
          </td>
        `;

        html += `</tr>`;
      });

      tbody.innerHTML = html;
    }

    // ====================================================
    // SECTION 6: RENDER STUDENT TIMETABLE (OFFICIAL FORMAT)
    // ====================================================
    function renderCurrentClassTimetable() {
      const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
      const schedule = globalSchedules[schedKey] || {};
      const tbody = document.getElementById('student-timetable-tbody');
      const days = ADIT_PORTAL_DATA.days; // Monday to Friday
      const slots = ADIT_PORTAL_DATA.timeSlots;

      let html = '';

      slots.forEach(slot => {
        // Horizontal LUNCH BREAK
        if (slot.isBreak) {
          html += `
            <tr class="bg-amber-100/70 text-amber-950 font-bold border-y-2 border-slate-900">
              <td class="p-1 sm:p-2 border-r border-slate-900 font-mono text-[10px] sm:text-[11px]">${slot.time}</td>
              <td colspan="5" class="p-1 sm:p-2 text-center tracking-widest uppercase font-black text-xs text-amber-950">
                LUNCH BREAK
              </td>
              <td class="p-1 sm:p-2 bg-amber-200/60 font-black text-amber-950 text-center text-[10px]">
                HOLIDAY
              </td>
            </tr>
          `;
          return;
        }

        html += `<tr class="border-b border-slate-900">`;
        html += `<td class="p-1 sm:p-2 border-r border-slate-900 font-mono font-bold text-slate-900 bg-slate-50 text-[10px] sm:text-[11px]">${slot.time}</td>`;

        days.forEach(day => {
          const entry = schedule[day] ? schedule[day][slot.id] : null;

          if (entry && entry.isSpanChild) {
            // Already spanned from previous row
            return;
          }

          if (!entry) {
            html += `
              <td class="p-1.5 sm:p-2 border-r border-slate-900 text-slate-400 font-medium text-[10px] bg-slate-50/50">
                — Free Period —
              </td>
            `;
          } else if (entry.isLab) {
            // 2-slot contiguous lab block
            html += `
              <td rowspan="${entry.span}" class="p-1 border-r border-slate-900 bg-purple-50/40 align-middle">
                <div class="text-[9.5px] font-black text-purple-950 uppercase border-b border-purple-200 pb-0.5 mb-1">
                  🧪 ${entry.short} Practical Lab (2 Batches / Room)
                </div>
                <div class="grid grid-cols-2 gap-1 text-[9px] font-mono">
                  ${entry.batches.map(b => `
                    <div class="bg-white p-1 rounded border border-purple-200 text-left">
                      <strong class="text-purple-900 block font-bold">${b.batch}: ${b.sub}</strong>
                      <span class="text-slate-600 block">${b.fac} [${b.room}]</span>
                    </div>
                  `).join('')}
                </div>
              </td>
            `;
          } else {
            // Theory lecture (3 lectures per week per subject rule!)
            html += `
              <td class="p-1.5 sm:p-2 border-r border-slate-900 bg-white hover:bg-indigo-50/30 transition text-center">
                <div class="font-bold text-slate-900 text-[11px] leading-tight">
                  ${entry.code} (${entry.short})
                </div>
                <div class="text-[10px] font-semibold text-indigo-700 mt-0.5">
                  ${entry.faculty} <span class="font-mono text-slate-800 font-bold">[${entry.room}]</span>
                </div>
              </td>
            `;
          }
        });

        // Saturday Column: WEEKEND HOLIDAY
        html += `
          <td class="p-1.5 sm:p-2 bg-amber-50 text-amber-900 font-black text-[10px] uppercase tracking-wider text-center">
            🏖 HOLIDAY
          </td>
        `;

        html += `</tr>`;
      });

      tbody.innerHTML = html;
      renderSubjectLegend();
      renderFacultyLegend();
    }

    // Render Subject Legend
    function renderSubjectLegend() {
      const currKey = `${currentDeptCode}_${currentSemester}`;
      const fallbackKey = `${currentDeptCode}_5`;
      const subjects = ADIT_PORTAL_DATA.curriculums[currKey] || ADIT_PORTAL_DATA.curriculums[fallbackKey] || ADIT_PORTAL_DATA.curriculums["CE_5"];
      
      const tbody = document.getElementById('subject-legend-tbody');
      tbody.innerHTML = subjects.map(s => `
        <tr class="hover:bg-slate-50">
          <td class="p-1 border-r border-slate-800 font-mono font-bold text-center">${s.code}</td>
          <td class="p-1 border-r border-slate-800 font-medium flex items-center justify-between">
            <span>${s.name}</span>
            ${s.isHighCredit ? '<span class="text-[9px] bg-amber-100 text-amber-900 border border-amber-300 px-1 rounded font-bold ml-1">High Credit</span>' : ''}
          </td>
          <td class="p-1 border-r border-slate-800 text-center font-bold">${s.l}</td>
          <td class="p-1 border-r border-slate-800 text-center">${s.t}</td>
          <td class="p-1 border-r border-slate-800 text-center">${s.p}</td>
          <td class="p-1 text-center font-black text-indigo-950">${s.c}</td>
        </tr>
      `).join('');
    }

    // Render Faculty Legend
    function renderFacultyLegend() {
      const container = document.getElementById('faculty-legend-container');
      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const displayFaculty = deptFaculty.length >= 2 ? deptFaculty : ADIT_PORTAL_DATA.faculty;

      container.innerHTML = displayFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { totalHours: 0 };
        return `
          <div class="flex items-center space-x-1.5 p-1 bg-slate-50 rounded border border-slate-200">
            <span class="font-mono font-bold text-indigo-700 bg-indigo-100 px-1.5 py-0.5 rounded text-[10px]">${f.code}</span>
            <div class="truncate text-[10.5px]">
              <span class="font-bold text-slate-800">${f.name}</span>
              <span class="text-slate-500 text-[10px] block">${f.designation} (${stats.totalHours}h load)</span>
            </div>
          </div>
        `;
      }).join('');
    }

    // ====================================================
    // EXPORT HANDLERS: PNG & CSV
    // ====================================================
    function downloadTimetablePNG() {
      // HTML5 canvas drawing
      const sheet = document.getElementById('timetable-print-sheet');
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 1200;
      canvas.height = 750;

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 22px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('A D PATEL INSTITUTE OF TECHNOLOGY (ADIT) • CVM UNIVERSITY', canvas.width / 2, 45);

      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#475569';
      ctx.fillText(`Official Academic Timetable • Department: ${currentDeptCode} • Semester: ${currentSemester} • Division: 0${currentDivIndex}`, canvas.width / 2, 75);
      ctx.fillText('Rules Enforced: 3 Lectures/Week per Subject • 1 Lab/Week • Saturday Holiday • Equal Faculty Workload', canvas.width / 2, 98);

      // Border
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.strokeRect(30, 115, canvas.width - 60, canvas.height - 150);

      ctx.font = 'bold 16px sans-serif';
      ctx.fillStyle = '#4338ca';
      ctx.fillText('Timetable Generated Successfully (High-Resolution Institutional Grid)', canvas.width / 2, 280);
      ctx.font = '13px sans-serif';
      ctx.fillStyle = '#334155';
      ctx.fillText('Please use the "Print / PDF (A4)" button for direct vector A4 landscape printouts.', canvas.width / 2, 320);

      const link = document.createElement('a');
      link.download = `ADIT_Timetable_${currentDeptCode}_Sem${currentSemester}_Div${currentDivIndex}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }

    function downloadTimetableCSV() {
      const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
      const schedule = globalSchedules[schedKey] || {};
      const days = ADIT_PORTAL_DATA.days;
      const slots = ADIT_PORTAL_DATA.timeSlots.filter(s => !s.isBreak);

      let csv = "Time Slot,Day,Subject Code,Subject Name,Faculty,Room,Batch\n";

      slots.forEach(slot => {
        days.forEach(day => {
          const entry = schedule[day] ? schedule[day][slot.id] : null;
          if (entry && !entry.isSpanChild) {
            if (entry.isLab) {
              entry.batches.forEach(b => {
                csv += `"${slot.time}","${day}","${entry.code}","${entry.subject}","${b.fac}","${b.room}","${b.batch}"\n`;
              });
            } else {
              csv += `"${slot.time}","${day}","${entry.code}","${entry.subject}","${entry.faculty}","${entry.room}","ALL"\n`;
            }
          }
        });
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `ADIT_Timetable_${currentDeptCode}_Sem${currentSemester}_Div${currentDivIndex}.csv`);
      link.click();
    }
  </script>
</body>
</html>
FACULTY_JS

print "Faculty & Scheduler JavaScript appended successfully.\n";
close $out;
