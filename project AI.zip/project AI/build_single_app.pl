use strict;
use warnings;

my $out_file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/app.py";
open my $out, ">", $out_file or die "Cannot open $out_file: $!";

print $out <<'HEADER';
#!/usr/bin/env python3
"""
ADIT AI Timetable Generator & Multi-Department Scheduling System
Single Self-Contained Application File

Author: Desai Aryan M.
Enrollment: EN. No. 12402080601009
College: A D Patel Institute of Technology (ADIT) | The CVM University

Usage:
    python3 app.py               # Starts web server at http://localhost:8000
    python3 app.py --serve       # Starts web server at http://localhost:8000
    python3 app.py --test        # Runs verification test suite
    python3 app.py --generate    # Generates timetable in terminal
"""

import sys
import os
import json
import random
import argparse
import mimetypes
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any, Tuple

# ====================================================
# 1. CONFIGURATION & CONSTANTS
# ====================================================
HEADER

# Append config.py
open my $fc, "<", "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/config.py" or die $!;
my $in_doc = 0;
while (<$fc>) {
    if (/^"""/) { $in_doc = 1 - $in_doc; next; }
    next if $in_doc;
    print $out $_;
}
close $fc;

print $out "\n# ====================================================\n";
print $out "# 2. DATA MODELS\n";
print $out "# ====================================================\n";

# Append models.py
open my $fm, "<", "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/models.py" or die $!;
$in_doc = 0;
while (<$fm>) {
    if (/^"""/) { $in_doc = 1 - $in_doc; next; }
    next if $in_doc;
    next if /^from dataclasses/ || /^from typing/;
    print $out $_;
}
close $fm;

print $out "\n# ====================================================\n";
print $out "# 3. ADIT ACADEMIC DATABASE\n";
print $out "# ====================================================\n";

# Append database.py
open my $fd, "<", "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/database.py" or die $!;
$in_doc = 0;
while (<$fd>) {
    if (/^"""/) { $in_doc = 1 - $in_doc; next; }
    next if $in_doc;
    print $out $_;
}
close $fd;

print $out "\n# ====================================================\n";
print $out "# 4. CSP CONSTRAINT SATISFACTION SOLVER\n";
print $out "# ====================================================\n";

# Append csp_solver.py
open my $fs, "<", "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/csp_solver.py" or die $!;
$in_doc = 0;
my $in_import = 0;
while (<$fs>) {
    if (/^"""/) { $in_doc = 1 - $in_doc; next; }
    next if $in_doc;
    if ($in_import) {
        $in_import = 0 if /\)/;
        next;
    }
    if (/^from \.(config|database|models) import \(/) {
        $in_import = 1;
        next;
    }
    next if /^import random/ || /^from typing/ || /^from \.config/ || /^from \.database/ || /^from \.models/;
    print $out $_;
}
close $fs;

print $out "\n# ====================================================\n";
print $out "# 5. WEB SERVER & REST API HANDLER\n";
print $out "# ====================================================\n";

# Append server.py
open my $fe, "<", "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/server.py" or die $!;
$in_doc = 0;
$in_import = 0;
while (<$fe>) {
    if (/^"""/) { $in_doc = 1 - $in_doc; next; }
    next if $in_doc;
    if ($in_import) {
        $in_import = 0 if /\)/;
        next;
    }
    if (/^from \.(csp_solver|database) import \(/) {
        $in_import = 1;
        next;
    }
    next if /^import json/ || /^import os/ || /^import mimetypes/ || /^from urllib\.parse/ || /^from http\.server/ || /^from \.csp_solver/ || /^from \.database/;
    if (/STATIC_DIR = os\.path\.join/) {
        print $out "STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), \"adit_timetable_ai\", \"static\")\n";
        print $out "if not os.path.exists(STATIC_DIR):\n";
        print $out "    STATIC_DIR = os.path.dirname(os.path.abspath(__file__))\n";
        next;
    }
    print $out $_;
}
close $fe;

print $out "\n# ====================================================\n";
print $out "# 6. CLI ENTRY POINT & VERIFICATION TESTS\n";
print $out "# ====================================================\n";

# Append main.py
open my $fn, "<", "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/main.py" or die $!;
$in_doc = 0;
while (<$fn>) {
    if (/^"""/) { $in_doc = 1 - $in_doc; next; }
    next if $in_doc;
    next if /^import sys/ || /^import argparse/ || /^from adit_timetable_ai\./;
    print $out $_;
}
close $fn;

close $out;
print "Built single-file app.py successfully!\n";
