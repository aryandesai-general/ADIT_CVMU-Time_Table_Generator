use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>:utf8', $target or die "Cannot write to $target: $!";

# Print HTML Header & CSS
print $out <<'HTML_HEAD';
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ADIT Academic Timetable & Faculty Allotment Portal | CVM University</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <script src="assets/logos.js"></script>
  <style>
    /* University Print Stylesheet - Exact A4 Landscape */
    @page {
      size: A4 landscape;
      margin: 5mm 6mm;
    }
    @media print {
      body {
        background: #ffffff !important;
        color: #000000 !important;
        padding: 0 !important;
        margin: 0 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .no-print { display: none !important; }
      .print-only { display: block !important; }
      .print-sheet {
        box-shadow: none !important;
        border: 2px solid #000 !important;
        margin: 0 auto !important;
        padding: 2px !important;
        width: 100% !important;
        max-width: 100% !important;
        page-break-after: avoid !important;
        page-break-inside: avoid !important;
      }
      table {
        border-collapse: collapse !important;
        width: 100% !important;
      }
      th, td {
        border: 1px solid #000000 !important;
      }
    }

    /* Crisp Institutional Table Borders */
    .adit-table {
      border-collapse: collapse;
      width: 100%;
      border: 1.5px solid #0f172a;
    }
    .adit-table th, .adit-table td {
      border: 1px solid #1e293b;
    }
    .scrollbar-thin::-webkit-scrollbar { height: 6px; width: 6px; }
    .scrollbar-thin::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
  </style>
</head>
<body class="bg-slate-100 text-slate-800 min-h-screen flex flex-col font-sans antialiased text-sm">

  <!-- ==================================================== -->
  <!-- SINGLE UNIFIED HORIZONTAL HEADER & MENU BAR          -->
  <!-- ==================================================== -->
  <header class="bg-slate-900 text-white shadow-md sticky top-0 z-40 no-print border-b border-slate-800">
    <!-- Top Utility & Brand Strip -->
    <div class="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80">
      <div class="flex items-center space-x-3">
        <div class="w-9 h-9 rounded-lg bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center p-1">
          <img id="header-cvm-logo" src="assets/cvm_logo.jpg" alt="CVM" class="max-h-7 object-contain">
        </div>
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-sm sm:text-base font-bold tracking-tight text-white">A D PATEL INSTITUTE OF TECHNOLOGY (ADIT)</h1>
            <span class="bg-blue-500/20 text-blue-300 text-[10px] font-semibold px-2 py-0.5 rounded border border-blue-400/30">CVM University</span>
          </div>
          <p class="text-[11px] text-slate-400">Official Academic Scheduling System • Capacity: 80/Class • 20/Batch • 2 Batches/Lab • 3 Lec/Week • Sat Holiday</p>
        </div>
      </div>

      <!-- Quick Action Controls -->
      <div class="flex items-center flex-wrap gap-2 text-xs">
        <button id="btn-generate-fresh" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-3 py-1.5 rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
          <span>⚡ Generate Fresh Timetable</span>
        </button>

        <button id="btn-print-timetable" class="bg-slate-700 hover:bg-slate-600 text-white font-semibold px-2.5 py-1.5 rounded-lg shadow-xs transition flex items-center gap-1">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
          <span>Print / PDF (A4)</span>
        </button>

        <button id="btn-download-png" class="bg-slate-700 hover:bg-slate-600 text-white font-semibold px-2.5 py-1.5 rounded-lg shadow-xs transition flex items-center gap-1">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
          <span>PNG</span>
        </button>

        <button id="btn-download-csv" class="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-2.5 py-1.5 rounded-lg shadow-xs transition flex items-center gap-1">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
          <span>CSV</span>
        </button>
      </div>
    </div>

    <!-- ONE SINGLE UNIFIED HORIZONTAL MENU BAR (IN EXACT REQUESTED ORDER 1 TO 6) -->
    <div class="max-w-7xl mx-auto px-4 flex items-center space-x-1 text-xs overflow-x-auto scrollbar-thin py-1">
      <button class="nav-tab active px-3 py-2 font-bold border-b-2 border-indigo-400 text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer" data-tab="tab-rooms">
        <span>🏛</span> 1. Room Entry Section
      </button>
      <button class="nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer" data-tab="tab-students">
        <span>👥</span> 2. Student Entry & Divisions
      </button>
      <button class="nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer" data-tab="tab-subjects">
        <span>📚</span> 3. All Subjects & Credits
      </button>
      <button class="nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer" data-tab="tab-faculty">
        <span>👨‍🏫</span> 4. Faculty Entry Detail
      </button>
      <button class="nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer" data-tab="tab-faculty-timetable">
        <span>⚖️</span> 5. Faculty Timetable & Workload
      </button>
      <button class="nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer" data-tab="tab-student-timetable">
        <span>📅</span> 6. Student Timetable
      </button>
    </div>
  </header>

  <!-- ==================================================== -->
  <!-- MAIN DISPLAY WRAPPER                                -->
  <!-- ==================================================== -->
  <main class="max-w-7xl mx-auto px-2 sm:px-4 py-3 flex-1 w-full space-y-4">
HTML_HEAD

print "HTML Head written.\n";
close $out;
