#!/usr/bin/env perl
use strict;
use warnings;
use IO::Socket::INET;

my $port = $ARGV[0] || 8080;
my $root = '.';

my %mime = (
    'html' => 'text/html; charset=UTF-8',
    'htm'  => 'text/html; charset=UTF-8',
    'js'   => 'application/javascript; charset=UTF-8',
    'css'  => 'text/css; charset=UTF-8',
    'json' => 'application/json',
    'png'  => 'image/png',
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'webp' => 'image/webp',
    'svg'  => 'image/svg+xml',
    'ico'  => 'image/x-icon',
    'txt'  => 'text/plain; charset=UTF-8',
);

my $server = IO::Socket::INET->new(
    LocalAddr => '127.0.0.1',
    LocalPort => $port,
    Proto     => 'tcp',
    Listen    => 10,
    Reuse     => 1,
) or die "Could not create socket on port $port: $!\n";

$server->autoflush(1);
print "HTTP server running at http://localhost:$port/\n";

while (my $client = $server->accept()) {
    $client->autoflush(1);
    my $req_line = <$client>;
    next unless $req_line;

    # Drain remaining request headers
    while (my $line = <$client>) {
        last if $line =~ /^\r?\n$/;
    }

    if ($req_line =~ /^GET\s+([^\s?]+)(?:\?\S*)?\s+HTTP/) {
        my $path = $1;
        $path = '/index.html' if $path eq '/';
        $path =~ s/\.\.//g; # basic directory traversal prevention
        my $file_path = $root . $path;

        if (-f $file_path) {
            my ($ext) = $file_path =~ /\.([a-zA-Z0-9]+)$/;
            $ext = lc($ext || '');
            my $content_type = $mime{$ext} || 'application/octet-stream';
            my $size = -s $file_path;

            if (open(my $fh, '<:raw', $file_path)) {
                print $client "HTTP/1.1 200 OK\r\n";
                print $client "Content-Type: $content_type\r\n";
                print $client "Content-Length: $size\r\n";
                print $client "Connection: close\r\n\r\n";
                my $buf;
                while (read($fh, $buf, 65536)) {
                    print $client $buf;
                }
                close($fh);
            } else {
                print $client "HTTP/1.1 500 Internal Server Error\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
            }
        } else {
            my $msg = "404 Not Found";
            my $len = length($msg);
            print $client "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: $len\r\nConnection: close\r\n\r\n$msg";
        }
    } else {
        print $client "HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n";
    }
    close($client);
}
