use strict;
use warnings;

my $html_file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
my $target_dir = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai";

open my $in, "<", $html_file or die "Cannot open $html_file: $!";
my $js_code = "";
while (<$in>) {
    if (/const ADIT_PORTAL_DATA =/ .. /^    \};/) {
        $js_code .= $_;
    }
}
close $in;

# Strip "const ADIT_PORTAL_DATA = " and trailing semicolon
$js_code =~ s/^\s*const ADIT_PORTAL_DATA =\s*//;
$js_code =~ s/;\s*$//;

# Convert JS booleans & null to Python
$js_code =~ s/\btrue\b/True/g;
$js_code =~ s/\bfalse\b/False/g;
$js_code =~ s/\bnull\b/None/g;

my $db_file = "$target_dir/database.py";
open my $out, ">", $db_file or die "Cannot open $db_file: $!";

print $out qq{"""\nADIT Academic Database Module\nContains normalized faculty, curriculum, room, and department data from adit.ac.in.\n"""\n\n};
print $out "ADIT_PORTAL_DATA = " . $js_code . "\n\n";

print $out <<'FUNCS';
def get_all_departments():
    """Return list of all 8 engineering departments."""
    return ADIT_PORTAL_DATA["departments"]


def get_rooms():
    """Return all classrooms (common) and discipline-dedicated laboratories."""
    return ADIT_PORTAL_DATA["rooms"]


def get_all_faculty():
    """Return list of all faculty members."""
    return ADIT_PORTAL_DATA["faculty"]


def get_department_faculty(dept_code: str):
    """
    Return faculty for a department, applying inter-departmental sharing:
    - Information Technology (IT) shares faculty pool with AI & DS (AIDS)
    - Computer Engineering (CE) shares faculty pool with CS & Design (CSD)
    """
    if dept_code in ("IT", "AIDS"):
        return [f for f in ADIT_PORTAL_DATA["faculty"] if f["dept"] in ("IT", "AIDS")]
    elif dept_code in ("CE", "CSD"):
        return [f for f in ADIT_PORTAL_DATA["faculty"] if f["dept"] in ("CE", "CSD")]
    else:
        dept_faculty = [f for f in ADIT_PORTAL_DATA["faculty"] if f["dept"] == dept_code]
        return dept_faculty if len(dept_faculty) >= 2 else ADIT_PORTAL_DATA["faculty"]


def get_curriculum(dept_code: str, sem: int = 5):
    """Return curriculum course list for a given department and semester."""
    key = f"{dept_code}_{sem}"
    fallback = f"{dept_code}_5"
    return (
        ADIT_PORTAL_DATA["curriculums"].get(key)
        or ADIT_PORTAL_DATA["curriculums"].get(fallback)
        or ADIT_PORTAL_DATA["curriculums"]["CE_5"]
    )
FUNCS

close $out;
print "Generated $db_file successfully\n";
