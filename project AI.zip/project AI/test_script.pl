use strict;
use warnings;

print "Perl script execution verified.\n";
