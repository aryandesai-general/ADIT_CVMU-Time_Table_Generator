"""
Test script to refine curriculums and scheduling for 100% equal subject & workload distribution.
"""
from adit_timetable_ai.database import ADIT_PORTAL_DATA

faculty_map = {f['code']: f for f in ADIT_PORTAL_DATA['faculty']}
print(f"Total faculty loaded: {len(faculty_map)}")

# List all faculty by dept
for code, f in faculty_map.items():
    is_hod = 'head' in f.get('designation', '').lower() or 'hod' in f.get('designation', '').lower() or 'principal' in f.get('designation', '').lower()
    f['is_hod'] = is_hod

print("Faculty categorized successfully.")
