import re

with open("index.html", "r", encoding="utf-8") as f:
    lines = f.readlines()

fac_lines = []
in_fac = False
for l in lines:
    if "faculty: [" in l:
        in_fac = True
        continue
    if in_fac:
        if l.strip().startswith("],") or l.strip() == "};":
            break
        fac_lines.append(l)

faculties = []
cur_fac = {}
for l in fac_lines:
    m = re.search(r"code:\s*['\"]([^'\"]+)['\"]", l)
    if m:
        if cur_fac:
            faculties.append(cur_fac)
        cur_fac = {"code": m.group(1)}
    m_name = re.search(r"name:\s*['\"]([^'\"]+)['\"]", l)
    if m_name:
        cur_fac["name"] = m_name.group(1)
    m_dept = re.search(r"dept:\s*['\"]([^'\"]+)['\"]", l)
    if m_dept:
        cur_fac["dept"] = m_dept.group(1)
    m_desig = re.search(r"designation:\s*['\"]([^'\"]+)['\"]", l)
    if m_desig:
        cur_fac["designation"] = m_desig.group(1)
if cur_fac:
    faculties.append(cur_fac)

assigned = {}
for l in lines[:1607]:
    m = re.search(r"facultyCode:\s*['\"]([^'\"]+)['\"]", l)
    if m:
        c = m.group(1)
        assigned[c] = assigned.get(c, 0) + 1

print(f"Total faculty parsed: {len(faculties)}")
zero_count = 0
for f in faculties:
    c = f["code"]
    cnt = assigned.get(c, 0)
    if cnt == 0:
        zero_count += 1
    d = f["dept"]
    n = f["name"]
    desig = f.get("designation", "")
    print(f"[{d:5s}] {c:6s} {n:30s} {desig:25s}: {cnt} subjects")

print(f"\nTotal faculty with 0 subjects assigned in curriculum: {zero_count} out of {len(faculties)}")
