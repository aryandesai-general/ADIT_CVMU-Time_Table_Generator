use strict;
use warnings;

print "Perl script running successfully\n";
