use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

print $out <<'FACULTY_AND_CODE';
      // 4. All Faculty Members Department-Wise (adit.ac.in)
      faculty: [
        // ==========================================
        // COMPUTER ENGINEERING (CE) - 13 FACULTY
        // ==========================================
        { 
          code: "MB", 
          name: "Dr. Malay Bhatt", 
          dept: "CE", 
          designation: "Associate Professor and Head", 
          experience: "22 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Computer Networks, Cyber Security, Distributed Computing, Cloud Architecture",
          priorities: ["Computer Networks", "Cyber Security & Digital Forensics", "Distributed Computing"]
        },
        { 
          code: "DKS", 
          name: "Dr. Dheeraj Kumar Singh", 
          dept: "CE", 
          designation: "Associate Professor & Head CSD", 
          experience: "17 Years", 
          qualification: "Ph.D., M.Tech, B.Tech",
          skills: "Algorithms, Machine Learning, Data Science, AI Systems",
          priorities: ["Design and Analysis of Algorithms", "Machine Learning & AI", "Data Structures & Algorithms (DSA)"]
        },
        { 
          code: "IT", 
          name: "Dr. Ishita Theba", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Cloud Computing, Computer Graphics, Operating Systems",
          priorities: ["Cloud Computing & DevOps Architecture", "Operating Systems (OS)", "Computer Graphics - PE1"]
        },
        { 
          code: "AKK", 
          name: "Prof. Aniruddha Kurtkoti", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "8 Years", 
          qualification: "M.Tech, B.Tech",
          skills: "Python, Web Programming, Mobile Product Engineering, Database Management",
          priorities: ["Python and Web Programming", "Database Management Systems (DBMS)", "Mobile Application Development"]
        },
        { 
          code: "CBJ", 
          name: "Prof. Chinmay Joshi", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "UI/UX Design, Computer Graphics & Design, Digital Logic",
          priorities: ["Computer Graphics & Design", "Fundamentals of UI/UX Design", "Digital Logic & Computer Design (DLD)"]
        },
        { 
          code: "PT", 
          name: "Prof. Prerak Thakkar", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Algorithms, Advanced Java, Object Oriented Programming",
          priorities: ["Design and Analysis of Algorithms", "Advanced Java Programming - PE1", "Object Oriented Programming with Java"]
        },
        { 
          code: "AJK", 
          name: "Prof. Axit Jaykumar Kachhia", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "8 Years", 
          qualification: "M.E., B.E.",
          skills: "Full Stack Development, Cyber Security, Web Development",
          priorities: ["Full Stack Web Technologies (MERN)", "Cyber Security - PE1", "Web Development"]
        },
        { 
          code: "KSP", 
          name: "Prof. Kinjal Parmar", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Programming for Problem Solving, Web Development, Algorithms",
          priorities: ["Web Development", "Programming for Problem Solving (PPS - C)", "Full Stack Web Technologies (MERN)"]
        },
        { 
          code: "JVP_CE", 
          name: "Prof. Jignasha Vishal Parmar", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Software Testing, Database Management, Python",
          priorities: ["Database Management Systems (DBMS)", "Software Testing & QA", "Python for Data Science"]
        },
        { 
          code: "SJM", 
          name: "Prof. Sheetal J. Macwan", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Data Structures, Computer Organization, Programming",
          priorities: ["Data Structures & Algorithms (DSA)", "Computer Organization & Architecture (COA)", "Object Oriented Programming with C++"]
        },
        { 
          code: "TRR", 
          name: "Prof. Tejas Rajeshbhai Rana", 
          dept: "CE", 
          designation: "Assistant Professor & TT Coordinator", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Python for Data Science, Computer Vision, Machine Learning",
          priorities: ["Python for Data Science", "Computer Vision & Pattern Recognition", "Machine Learning & AI"]
        },
        { 
          code: "PKT", 
          name: "Prof. Pragnesh Patel", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "14 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Networks, Database Management Systems, Software Quality",
          priorities: ["Computer Networks", "Database Management Systems (DBMS)", "Software Testing & QA"]
        },
        { 
          code: "AW", 
          name: "Prof. Ankit Wadhwa", 
          dept: "CE", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Advanced Java Programming, Basic Electrical, Cloud Computing",
          priorities: ["Advanced Java Programming - PE1", "Object Oriented Programming with Java", "Basic Electrical Engineering (BEE)"]
        },

        // ==========================================
        // INFORMATION TECHNOLOGY (IT) - 13 FACULTY
        // ==========================================
        { 
          code: "PRB", 
          name: "Dr. Priyang Bhatt", 
          dept: "IT", 
          designation: "Associate Professor & Head IT", 
          experience: "18 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Cloud Computing, Distributed Computing, High Performance Computing",
          priorities: ["Cloud Computing & Virtualization", "DevOps & Cloud Native Architecture", "Design and Analysis of Algorithms"]
        },
        { 
          code: "DJP", 
          name: "Dr. Dinesh Prajapati", 
          dept: "IT", 
          designation: "Associate Professor & AI Coordinator", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Artificial Intelligence, Machine Learning, Deep Learning",
          priorities: ["Artificial Intelligence (PE1)", "Machine Learning & Analytics", "Deep Learning Foundations"]
        },
        { 
          code: "KRP", 
          name: "Dr. Krunal Patel", 
          dept: "IT", 
          designation: "Associate Professor", 
          experience: "15 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Data Structures, Database Management, Big Data",
          priorities: ["Data Structures", "Database Management Systems", "Big Data Technologies & Analytics"]
        },
        { 
          code: "SNG", 
          name: "Dr. Shital Gondaliya", 
          dept: "IT", 
          designation: "Associate Professor", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Web Development, Machine Learning, Data Analytics",
          priorities: ["Web Development", "Machine Learning & Analytics", "Database Management Systems"]
        },
        { 
          code: "ANP", 
          name: "Dr. Anand Pandya", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Cyber Security, Ethical Hacking, Network Security",
          priorities: ["Cyber Security (PE1)", "Information & Network Security", "Computer Networks"]
        },
        { 
          code: "JKP", 
          name: "Prof. Jitiksha Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Software Engineering, Java Programming, Agile Development",
          priorities: ["Software Engineering", "Java Programming & Technologies", "Software Project Management"]
        },
        { 
          code: "HMP", 
          name: "Prof. Hemanshu Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Operating Systems, Shell Scripting, Linux System Architecture",
          priorities: ["Operating Systems", "Programming for Problem Solving (PPS)", "DevOps & Cloud Native Architecture"]
        },
        { 
          code: "NMM", 
          name: "Prof. Nayan Mali", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.Tech, B.E.",
          skills: "Programming with Python, Data Science, Software Project Management",
          priorities: ["Programming with Python", "Software Project Management (PE2)", "Python for Scientific Computing"]
        },
        { 
          code: "KJP", 
          name: "Prof. Keyur Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Artificial Intelligence, Digital Electronics, Advance Java",
          priorities: ["Artificial Intelligence (PE1)", "Digital Electronics & Computer Organization", "Advanced Java Programming (PE1)"]
        },
        { 
          code: "MAP", 
          name: "Prof. Mayur Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "13 Years", 
          qualification: "M.E., B.E.",
          skills: "Design and Analysis of Algorithms, Data Structures, Cloud Computing",
          priorities: ["Design and Analysis of Algorithms", "Data Structures", "Cloud Computing & Virtualization"]
        },
        { 
          code: "AJR", 
          name: "Prof. Anjali Rajput", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Software Engineering, Full Stack Web Development, Java",
          priorities: ["Software Engineering", "Full Stack Application Development", "Java Programming & Technologies"]
        },
        { 
          code: "HVP", 
          name: "Prof. Himani Patel", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Networks, Cyber Security, Ethical Hacking",
          priorities: ["Cyber Security (PE1)", "Computer Networks", "Cyber Security & Ethical Hacking"]
        },
        { 
          code: "KVP", 
          name: "Prof. Kavya Prajapati", 
          dept: "IT", 
          designation: "Assistant Professor", 
          experience: "8 Years", 
          qualification: "M.E., B.E.",
          skills: "Object Oriented Programming, C++, Mobile Computing",
          priorities: ["Object Oriented Programming with C++", "Mobile Computing & Wireless Tech", "Web Development"]
        },

        // ==========================================
        // COMPUTER SCIENCE & DESIGN (CSD) - 5 FACULTY
        // ==========================================
        { 
          code: "DKS_CSD", 
          name: "Dr. Dheeraj Kumar Singh", 
          dept: "CSD", 
          designation: "Head CSD & Associate Professor", 
          experience: "17 Years", 
          qualification: "Ph.D., M.Tech",
          skills: "Design Algorithms, Data Structures, Human-AI Systems",
          priorities: ["Design and Analysis of Algorithms", "Data Structures & Design Algorithms", "Human-AI Interaction Systems"]
        },
        { 
          code: "CBJ_CSD", 
          name: "Prof. Chinmay Joshi", 
          dept: "CSD", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Graphics & Design, UI/UX Design, AR/VR Systems",
          priorities: ["Computer Graphics & Design", "Fundamentals of UI/UX Design", "Interactive UX / AR & VR Systems"]
        },
        { 
          code: "VVN_CSD", 
          name: "Prof. Vishwadip Nanavati", 
          dept: "CSD", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Architecture & Design, 3D Animation, Game Design",
          priorities: ["Computer Architecture & Design", "3D Animation & Game Design", "Design Research Methods & Usability Testing"]
        },
        { 
          code: "BKM", 
          name: "Prof. Barkha Mehta", 
          dept: "CSD", 
          designation: "Assistant Professor", 
          experience: "7 Years", 
          qualification: "M.Tech, B.Tech",
          skills: "Visual Arts, Design Thinking, Prototyping, Spatial Design",
          priorities: ["Visual Arts & Design Thinking", "Design Workshop & Prototyping", "Spatial Computing & Generative Design"]
        },
        { 
          code: "AJK_CSD", 
          name: "Prof. Axit Kachhia", 
          dept: "CSD", 
          designation: "Assistant Professor", 
          experience: "8 Years", 
          qualification: "M.E., B.E.",
          skills: "Interactive Design, Python & Web Programming, Mobile UX",
          priorities: ["Python and Web Programming", "Mobile UX & Digital Product Engineering", "Design Systems & Web Frameworks"]
        },

        // ==========================================
        // ARTIFICIAL INTELLIGENCE & DATA SCIENCE (AIDS) - 5 FACULTY
        // ==========================================
        { 
          code: "DJP_AI", 
          name: "Dr. Dinesh Prajapati", 
          dept: "AIDS", 
          designation: "Program Coordinator & Associate Professor", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E.",
          skills: "Machine Learning, Deep Learning, Natural Language Processing",
          priorities: ["Machine Learning Concepts & Algorithms", "Deep Learning Foundations (PyTorch/TF)", "Design and Analysis of Algorithms"]
        },
        { 
          code: "PKG", 
          name: "Prof. Priyanka Gondaliya", 
          dept: "AIDS", 
          designation: "Assistant Professor", 
          experience: "9 Years", 
          qualification: "M.E., B.E.",
          skills: "Generative AI, Large Language Models, AI Ethics, Computer Vision",
          priorities: ["Generative AI & LLM Systems", "Computer Vision & Pattern Recognition", "MLOps, Pipeline Engineering & Ethics"]
        },
        { 
          code: "SNG_AI", 
          name: "Dr. Shital Gondaliya", 
          dept: "AIDS", 
          designation: "Associate Professor (Data Science)", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E.",
          skills: "Big Data Engineering, Data Wrangling, Statistical Inference",
          priorities: ["Big Data Engineering & Spark", "Data Wrangling & Exploratory Analysis", "Time Series Analysis & Forecasting"]
        },
        { 
          code: "TRR_AI", 
          name: "Prof. Tejas Rana", 
          dept: "AIDS", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Computer Vision, Autonomous Systems, Reinforcement Learning",
          priorities: ["Computer Vision & Pattern Recognition", "Autonomous Systems & Edge AI", "Reinforcement Learning & Game AI"]
        },
        { 
          code: "NMM_AI", 
          name: "Prof. Nayan Mali", 
          dept: "AIDS", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.Tech, B.E.",
          skills: "Python for Scientific Computing, Applied NLP, Data Systems",
          priorities: ["Natural Language Processing (PE1)", "Python for Scientific Computing", "Data Structures for AI & Analytics"]
        },

        // ==========================================
        // MECHANICAL ENGINEERING (ME) - 8 FACULTY
        // ==========================================
        { 
          code: "VNS", 
          name: "Dr. Vishal N. Singh", 
          dept: "ME", 
          designation: "Professor & Head", 
          experience: "22 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Design of Machine Elements, Kinematics, Dynamics of Machinery",
          priorities: ["Design of Machine Elements (DME)", "Kinematics of Machinery (KOM)", "Dynamics of Machinery (DOM)"]
        },
        { 
          code: "YDP", 
          name: "Dr. Yashavant D. Patel", 
          dept: "ME", 
          designation: "Associate Professor", 
          experience: "18 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Thermodynamics, Heat and Mass Transfer, Thermal Power",
          priorities: ["Engineering Thermodynamics & Heat", "Heat and Mass Transfer (HMT)", "Applied Thermodynamics & Steam Power"]
        },
        { 
          code: "MIS", 
          name: "Dr. Mitesh I. Shah", 
          dept: "ME", 
          designation: "Associate Professor", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Fluid Mechanics, Hydraulic Machines, Power Plant Engineering",
          priorities: ["Fluid Mechanics & Hydraulic Machines", "Power Plant Engineering", "Internal Combustion Engines (ICE)"]
        },
        { 
          code: "AYJ", 
          name: "Dr. Ayanesh Y. Joshi", 
          dept: "ME", 
          designation: "Associate Professor", 
          experience: "15 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "CAD/CAM, Finite Element Analysis, Solid Modeling",
          priorities: ["Computer Aided Design & Manufacturing (CAD/CAM)", "Finite Element Method (FEM) Analysis", "Engineering Graphics & Computer Drafting"]
        },
        { 
          code: "RRS", 
          name: "Dr. Ronakkumar Rajnikant Shah", 
          dept: "ME", 
          designation: "Associate Professor", 
          experience: "14 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Manufacturing Processes, Production Automation, CNC Technology",
          priorities: ["Manufacturing Processes - I (Casting/Welding)", "Manufacturing Processes - II (Machining)", "Production Automation & Robotics"]
        },
        { 
          code: "MVM", 
          name: "Dr. Manisha V. Makwana", 
          dept: "ME", 
          designation: "Associate Professor", 
          experience: "15 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Refrigeration and Air Conditioning, Heat Transfer, HVAC",
          priorities: ["Refrigeration and Air Conditioning (RAC)", "Heat and Mass Transfer (HMT)", "Operations Research (OR)"]
        },
        { 
          code: "BJS", 
          name: "Prof. Bhaumik J. Sheth", 
          dept: "ME", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Automobile Engineering, Electric Vehicle Tech, IC Engines",
          priorities: ["Automobile Engineering & EV Tech", "Internal Combustion Engines (ICE)", "Workshop & Manufacturing Practice"]
        },
        { 
          code: "HBJ", 
          name: "Prof. Harsh B. Joshi", 
          dept: "ME", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Strength of Materials, Engineering Mechanics, Metrology",
          priorities: ["Strength of Materials", "Engineering Mechanics (Statics & Dynamics)", "Mechanical Measurement & Metrology"]
        },

        // ==========================================
        // CIVIL ENGINEERING (CL) - 7 FACULTY
        // ==========================================
        { 
          code: "RJB", 
          name: "Dr. Rajiv Bhatt", 
          dept: "CL", 
          designation: "Professor & Head", 
          experience: "23 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Structural Analysis, Earthquake Resistant Design, Steel Structures",
          priorities: ["Structural Analysis - I (SA-1)", "Structural Analysis - II (SA-2)", "Earthquake Resistant Design of Structures"]
        },
        { 
          code: "DMY", 
          name: "Prof. Darshan M. Yagnik", 
          dept: "CL", 
          designation: "Assistant Professor", 
          experience: "14 Years", 
          qualification: "M.E., B.E.",
          skills: "Surveying, Geomatics, Highway & Transportation Engineering",
          priorities: ["Surveying & Geomatics", "Highway & Transportation Engineering", "Urban Infrastructure Planning & Smart Cities"]
        },
        { 
          code: "DKB", 
          name: "Dr. Drashti K. Bhatt", 
          dept: "CL", 
          designation: "Associate Professor", 
          experience: "15 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Reinforced Concrete Design, Concrete Technology, Structural Modeling",
          priorities: ["Design of Reinforced Concrete Structures (DRCS)", "Concrete Technology", "Design of Steel Structures (DSS)"]
        },
        { 
          code: "PBV", 
          name: "Prof. Patel Bhavin Vishnubhai", 
          dept: "CL", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Geotechnical Engineering, Soil Mechanics, Foundation Design",
          priorities: ["Geotechnical Engineering - I (Soil Mechanics)", "Geotechnical Engineering - II (Foundations)", "Mechanics of Solids (MOS)"]
        },
        { 
          code: "ASS", 
          name: "Prof. Axay Sanat Shah", 
          dept: "CL", 
          designation: "Assistant Professor", 
          experience: "11 Years", 
          qualification: "M.E., B.E.",
          skills: "Fluid Mechanics, Hydraulics, Water Resources Engineering",
          priorities: ["Fluid Mechanics & Hydraulics", "Hydrology & Water Resources Engineering", "Water Supply & Environmental Engineering"]
        },
        { 
          code: "CBH", 
          name: "Prof. Chhaya Bhrambhatt", 
          dept: "CL", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Environmental Engineering, Wastewater Treatment, Pollution Control",
          priorities: ["Environmental Engineering - II (Wastewater)", "Water Supply & Environmental Engineering", "Building Construction & Materials"]
        },
        { 
          code: "BWP", 
          name: "Dr. Biswadeep Pal", 
          dept: "CL", 
          designation: "Associate Professor", 
          experience: "17 Years", 
          qualification: "Ph.D., M.Tech, B.Tech",
          skills: "Environmental Systems, Waste Management, Chemical Process Engineering",
          priorities: ["Environmental Engineering - II (Wastewater)", "Bridge & Tunnel Engineering", "Construction Project Management & Estimation"]
        },

        // ==========================================
        // ELECTRICAL ENGINEERING (EE) - 5 FACULTY
        // ==========================================
        { 
          code: "KMC", 
          name: "Dr. Kalpesh Chudasama", 
          dept: "EE", 
          designation: "Professor & Head", 
          experience: "20 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Power Systems, High Voltage Engineering, Smart Grid",
          priorities: ["Power Systems - I (Generation & Transmission)", "Power Systems - II (Analysis & Faults)", "High Voltage Engineering & Testing"]
        },
        { 
          code: "MNJ", 
          name: "Prof. Minesh Joshi", 
          dept: "EE", 
          designation: "Associate Professor", 
          experience: "18 Years", 
          qualification: "M.E., B.E.",
          skills: "Electrical Machines, Converter Drives, Machine Design",
          priorities: ["Electrical Machines - I (Transformers & DC)", "Electrical Machines - II (Induction & Sync)", "Electrical Machine Design"]
        },
        { 
          code: "PRM", 
          name: "Prof. Paresh R. Modha", 
          dept: "EE", 
          designation: "Assistant Professor", 
          experience: "15 Years", 
          qualification: "M.E., B.E.",
          skills: "Control Systems, Industrial Automation, PLC & SCADA",
          priorities: ["Control Systems Engineering", "Industrial Automation & PLC / SCADA", "Electrical Circuit Analysis (ECA)"]
        },
        { 
          code: "KMS", 
          name: "Dr. Kalpeshkumar M. Shah", 
          dept: "EE", 
          designation: "Associate Professor", 
          experience: "16 Years", 
          qualification: "Ph.D., M.E., B.E.",
          skills: "Power Electronics, Converter Drives, Electric Vehicles",
          priorities: ["Power Electronics & Converter Drives", "Electric Vehicle Powertrain & Battery Tech", "Switchgear, Protection & Relays"]
        },
        { 
          code: "VSS", 
          name: "Prof. Vishal S. Sheth", 
          dept: "EE", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.E., B.E.",
          skills: "Digital Electronics, Microcontrollers, Embedded Systems",
          priorities: ["Digital Electronics & Microprocessors", "Microcontrollers & Embedded Systems", "Electrical Measurements & Sensors"]
        },

        // ==========================================
        // CHEMICAL ENGINEERING (CH) - 4 FACULTY
        // ==========================================
        { 
          code: "BWP_CH", 
          name: "Dr. Biswadeep Pal", 
          dept: "CH", 
          designation: "Professor & In-Charge", 
          experience: "18 Years", 
          qualification: "Ph.D., M.Tech, B.Tech",
          skills: "Chemical Reaction Engineering, Plant Design, Mass Transfer",
          priorities: ["Chemical Reaction Engineering - I (CRE-1)", "Plant Design & Economics", "Mass Transfer Operations - II (MTO-2)"]
        },
        { 
          code: "KSN", 
          name: "Dr. Kaushik Nath", 
          dept: "CH", 
          designation: "Senior Professor & Consultant", 
          experience: "24 Years", 
          qualification: "Ph.D., M.Tech",
          skills: "Transport Phenomena, Fluid Flow, Process Modeling",
          priorities: ["Transport Phenomena", "Fluid Flow Operations (FFO)", "Process Modeling, Simulation & Aspen"]
        },
        { 
          code: "HSP", 
          name: "Prof. Hitesh Patel", 
          dept: "CH", 
          designation: "Assistant Professor", 
          experience: "12 Years", 
          qualification: "M.Tech, B.E.",
          skills: "Chemical Process Calculations, Heat Transfer, Thermodynamics",
          priorities: ["Chemical Process Calculations (CPC)", "Heat Transfer Operations (HTO)", "Chemical Engineering Thermodynamics - I"]
        },
        { 
          code: "RMS", 
          name: "Prof. Rima Shah", 
          dept: "CH", 
          designation: "Assistant Professor", 
          experience: "10 Years", 
          qualification: "M.E., B.E.",
          skills: "Chemical Technology, Pollution Control, Instrumentation",
          priorities: ["Chemical Technology (Inorganic & Organic)", "Instrumentation & Process Control", "Industrial Pollution Control & Abatement"]
        },

        // ==========================================
        // APPLIED SCIENCES & HUMANITIES (ASH) - 3 FACULTY
        // ==========================================
        { 
          code: "DM", 
          name: "Dr. Darshan Mehta", 
          dept: "ASH", 
          designation: "Associate Professor (Mathematics)", 
          experience: "18 Years", 
          qualification: "Ph.D., M.Sc.",
          skills: "Calculus, Linear Algebra, Probability, Statistics, Numerical Methods",
          priorities: ["Mathematics - I (Calculus & Linear Algebra)", "Mathematics - II (Advanced Calculus & ODE)", "Probability, Statistics & Numerical Analysis"]
        },
        { 
          code: "SKP", 
          name: "Dr. S. K. Pathak", 
          dept: "ASH", 
          designation: "Associate Professor (Physics)", 
          experience: "16 Years", 
          qualification: "Ph.D., M.Sc.",
          skills: "Engineering Physics, Optics, Lasers, Quantum Mechanics",
          priorities: ["Engineering Physics", "Optics & Laser Technology", "Applied Sciences"]
        },
        { 
          code: "PMG", 
          name: "Dr. P. M. George", 
          dept: "ASH", 
          designation: "Professor (English & Ethics)", 
          experience: "25 Years", 
          qualification: "Ph.D., M.A.",
          skills: "Technical Communication, Professional Ethics, Environmental Sciences",
          priorities: ["English for Technical Communication", "Technical Communication Skills", "Professional Practice, IP Rights & Ethics"]
        }
      ]
    };

    // State Variables
    let currentDeptCode = "IT";
    let currentSemester = "5";
    let currentDivIndex = 1;
    let selectedFacultyCode = "PRB";
    let randomSeedOffset = 1;
    let variationCounter = 1;
    const globalSchedules = {}; // Master schedules dictionary
    const globalFacultyWorkload = {}; // Real-time faculty teaching hours

    // ====================================================
    // INITIALIZATION & EVENT BINDINGS
    // ====================================================
    document.addEventListener('DOMContentLoaded', () => {
      initApp();
    });

    function initApp() {
      // Inject user-uploaded logos from base64 if available
      if (window.ADIT_LOGOS) {
        if (window.ADIT_LOGOS.cvm) {
          const cvmEl = document.getElementById('logo-cvm-left');
          const headCvmEl = document.getElementById('header-cvm-logo');
          if (cvmEl) cvmEl.src = window.ADIT_LOGOS.cvm;
          if (headCvmEl) headCvmEl.src = window.ADIT_LOGOS.cvm;
        }
        if (window.ADIT_LOGOS.adit) {
          const aditEl = document.getElementById('logo-adit-right');
          if (aditEl) aditEl.src = window.ADIT_LOGOS.adit;
        }
      }

      setupTabs();
      populateDropdowns();
      setupActionButtons();
      setupModals();

      // Initial Schedule Calculation & View Renders
      generateAllSchedules();
      renderRoomsTable();
      renderDepartmentsIntakeCards();
      renderCurriculumTable();
      renderFacultyPrioritiesGrid();
      renderFacultyTimetableAndWorkload();
      renderCurrentClassTimetable();
    }

    // Tab Navigation Setup (1 to 6 Horizontal Menu Bar)
    function setupTabs() {
      document.querySelectorAll('.nav-tab').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const target = e.currentTarget.dataset.tab;
          document.querySelectorAll('.nav-tab').forEach(t => {
            t.className = 'nav-tab px-3 py-2 font-medium border-b-2 border-transparent text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer';
          });
          e.currentTarget.className = 'nav-tab active px-3 py-2 font-bold border-b-2 border-indigo-400 text-white flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer';

          document.querySelectorAll('.tab-pane').forEach(p => {
            p.classList.toggle('hidden', p.id !== target);
          });

          // Refresh active views on tab open
          if (target === 'tab-rooms') renderRoomsTable();
          if (target === 'tab-students') renderDepartmentsIntakeCards();
          if (target === 'tab-subjects') renderCurriculumTable();
          if (target === 'tab-faculty') renderFacultyPrioritiesGrid();
          if (target === 'tab-faculty-timetable') renderFacultyTimetableAndWorkload();
          if (target === 'tab-student-timetable') renderCurrentClassTimetable();
        });
      });
    }

    // Populate Dropdowns
    function populateDropdowns() {
      const depts = ADIT_PORTAL_DATA.departments;
      const selDept = document.getElementById('sel-dept');
      const selCurriculumDept = document.getElementById('sel-curriculum-dept');
      const mFacDept = document.getElementById('m-fac-dept');

      const deptOptions = depts.map(d => `<option value="${d.code}" ${d.code === currentDeptCode ? 'selected' : ''}>${d.name} (${d.code})</option>`).join('');
      if (selDept) selDept.innerHTML = deptOptions;
      if (selCurriculumDept) selCurriculumDept.innerHTML = deptOptions;
      if (mFacDept) mFacDept.innerHTML = deptOptions;

      updateDivisionDropdown();
      setupSelectors();
    }

    // Update Division Dropdown (80 Students / Class Capacity rule!)
    function updateDivisionDropdown() {
      const dept = ADIT_PORTAL_DATA.departments.find(d => d.code === currentDeptCode) || ADIT_PORTAL_DATA.departments[0];
      const divCount = Math.max(1, Math.ceil(dept.studentIntake / 80));
      const selDiv = document.getElementById('sel-div');
      
      let html = '';
      for (let i = 1; i <= divCount; i++) {
        const studentCountInDiv = Math.min(80, Math.round(dept.studentIntake / divCount));
        html += `<option value="${i}" ${i === currentDivIndex ? 'selected' : ''}>Division 0${i} (${studentCountInDiv} Students • 4 Batches)</option>`;
      }
      if (selDiv) selDiv.innerHTML = html;
      
      const roomAssigned = dept.defaultRooms[currentDivIndex - 1] || dept.defaultRooms[0] || "213";
      document.getElementById('lbl-room-no').textContent = roomAssigned;
      document.getElementById('disp-room-no').textContent = roomAssigned;
      document.getElementById('disp-prog-code').textContent = dept.progCode;
      document.getElementById('disp-fac-code').textContent = dept.facCode;
      document.getElementById('disp-program-name').textContent = dept.name;
      document.getElementById('disp-semester-no').textContent = currentSemester;
      document.getElementById('disp-div-no').textContent = `0${currentDivIndex}`;
    }

    // Setup Selectors & Filters
    function setupSelectors() {
      document.getElementById('sel-dept').addEventListener('change', (e) => {
        currentDeptCode = e.target.value;
        currentDivIndex = 1;
        updateDivisionDropdown();
        generateAllSchedules();
        renderCurrentClassTimetable();
      });

      document.getElementById('sel-sem').addEventListener('change', (e) => {
        currentSemester = e.target.value;
        updateDivisionDropdown();
        generateAllSchedules();
        renderCurrentClassTimetable();
      });

      document.getElementById('sel-div').addEventListener('change', (e) => {
        currentDivIndex = parseInt(e.target.value, 10);
        updateDivisionDropdown();
        renderCurrentClassTimetable();
      });

      document.getElementById('sel-curriculum-dept').addEventListener('change', renderCurriculumTable);
      document.getElementById('sel-curriculum-sem').addEventListener('change', renderCurriculumTable);
      document.getElementById('sel-curriculum-category').addEventListener('change', renderCurriculumTable);

      document.querySelectorAll('.sem-pill').forEach(btn => {
        btn.addEventListener('click', (e) => {
          document.querySelectorAll('.sem-pill').forEach(b => {
            b.className = 'sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer';
          });
          e.currentTarget.className = 'sem-pill active px-3 py-1 rounded-lg border border-indigo-600 bg-indigo-600 text-white font-semibold transition cursor-pointer';
          document.getElementById('sel-curriculum-sem').value = e.currentTarget.dataset.sem;
          renderCurriculumTable();
        });
      });

      document.getElementById('sel-filter-faculty-dept').addEventListener('change', renderFacultyPrioritiesGrid);

      document.getElementById('select-faculty-individual').addEventListener('change', (e) => {
        selectedFacultyCode = e.target.value;
        renderFacultyTimetableAndWorkload();
      });
    }

    // Setup Action Buttons & Regenerate Options
    function setupActionButtons() {
      const triggerReshuffle = (randomize = false, balance = true) => {
        randomSeedOffset += (randomize ? 7 : 1);
        variationCounter += 1;
        generateAllSchedules();
        renderCurrentClassTimetable();
        renderFacultyTimetableAndWorkload();

        const badge = document.getElementById('badge-variation-info');
        if (badge) {
          badge.textContent = `Variation #${variationCounter} • 0 Collisions ✅`;
        }

        const toast = document.createElement('div');
        toast.className = 'fixed bottom-5 right-5 bg-indigo-600 text-white px-4 py-2.5 rounded-xl shadow-lg font-semibold text-xs flex items-center gap-2 z-50 animate-bounce';
        toast.innerHTML = `<span>⚡</span> Timetable variation #${variationCounter} generated (3 Lec/Wk, 1 Lab/Wk, Saturday Holiday)!`;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2500);
      };

      // Top Header Regenerate Button
      document.getElementById('btn-quick-regenerate').addEventListener('click', () => triggerReshuffle(false, true));

      // Panel Regenerate Buttons in Student Timetable view
      document.getElementById('btn-panel-regenerate').addEventListener('click', () => triggerReshuffle(false, true));
      document.getElementById('btn-panel-randomize').addEventListener('click', () => triggerReshuffle(true, false));
      document.getElementById('btn-panel-balance').addEventListener('click', () => triggerReshuffle(false, true));

      document.getElementById('btn-print-timetable').addEventListener('click', () => {
        document.querySelector('[data-tab="tab-student-timetable"]').click();
        window.print();
      });

      document.getElementById('btn-download-png').addEventListener('click', downloadTimetablePNG);
      document.getElementById('btn-download-csv').addEventListener('click', downloadTimetableCSV);
    }

    // Setup Modals (Add/Edit Room, Add/Edit Faculty, Edit Timetable Slot)
    function setupModals() {
      // 1. Room Modal (Handles both Add and Edit!)
      const modalRoom = document.getElementById('modal-add-room');
      const modalRoomTitle = document.getElementById('modal-room-title');
      const editRoomIdxInput = document.getElementById('m-room-edit-index');

      document.getElementById('btn-open-add-room-modal').addEventListener('click', () => {
        modalRoomTitle.innerHTML = '<span>🏛</span> Add Campus Facility';
        editRoomIdxInput.value = '-1';
        document.getElementById('m-room-no').value = '';
        document.getElementById('m-room-capacity').value = '80';
        document.getElementById('m-room-floor').value = 'Main Building';
        document.getElementById('m-room-features').value = 'Projector, LAN, AC';
        modalRoom.classList.remove('hidden');
      });

      document.getElementById('btn-close-room-modal').addEventListener('click', () => modalRoom.classList.add('hidden'));
      document.getElementById('btn-cancel-room-modal').addEventListener('click', () => modalRoom.classList.add('hidden'));

      document.getElementById('btn-save-room').addEventListener('click', () => {
        const roomNo = document.getElementById('m-room-no').value.trim();
        const type = document.getElementById('m-room-type').value;
        const capacity = parseInt(document.getElementById('m-room-capacity').value, 10) || 80;
        const dept = document.getElementById('m-room-dept').value;
        const floor = document.getElementById('m-room-floor').value.trim() || "Main Building";
        const features = document.getElementById('m-room-features').value.trim() || "Standard Classroom Setup";
        const editIdx = parseInt(editRoomIdxInput.value, 10);

        if (!roomNo) {
          alert("Please enter a room number or identifier.");
          return;
        }

        const roomObj = { roomNo, type, capacity, dept, buildingFloor: floor, features };
        if (editIdx >= 0 && editIdx < ADIT_PORTAL_DATA.rooms.length) {
          ADIT_PORTAL_DATA.rooms[editIdx] = roomObj;
          alert(`Facility "${roomNo}" successfully updated!`);
        } else {
          ADIT_PORTAL_DATA.rooms.push(roomObj);
          alert(`Facility "${roomNo}" successfully added!`);
        }

        modalRoom.classList.add('hidden');
        renderRoomsTable();
      });

      // 2. Faculty Modal (Handles Add and Edit)
      const modalFac = document.getElementById('modal-add-faculty');
      document.getElementById('btn-open-add-faculty-modal').addEventListener('click', () => {
        document.getElementById('modal-faculty-title').innerHTML = '<span>👨‍🏫</span> Add New Faculty Profile';
        document.getElementById('m-fac-code').value = '';
        document.getElementById('m-fac-name').value = '';
        document.getElementById('m-fac-designation').value = 'Assistant Professor';
        document.getElementById('m-fac-experience').value = '8 Years';
        document.getElementById('m-fac-qualification').value = 'M.E., B.E.';
        document.getElementById('m-fac-skills').value = '';
        document.getElementById('m-fac-p1').value = '';
        document.getElementById('m-fac-p2').value = '';
        document.getElementById('m-fac-p3').value = '';
        document.getElementById('m-fac-p4').value = '';
        document.getElementById('m-fac-p5').value = '';
        modalFac.classList.remove('hidden');
      });

      document.getElementById('btn-close-faculty-modal').addEventListener('click', () => modalFac.classList.add('hidden'));
      document.getElementById('btn-cancel-faculty-modal').addEventListener('click', () => modalFac.classList.add('hidden'));

      document.getElementById('btn-save-faculty').addEventListener('click', () => {
        const code = document.getElementById('m-fac-code').value.trim().toUpperCase();
        const name = document.getElementById('m-fac-name').value.trim();
        const dept = document.getElementById('m-fac-dept').value;
        const designation = document.getElementById('m-fac-designation').value.trim() || "Assistant Professor";
        const experience = document.getElementById('m-fac-experience').value.trim() || "8 Years";
        const qualification = document.getElementById('m-fac-qualification').value.trim() || "M.E., B.E.";
        const skills = document.getElementById('m-fac-skills').value.trim() || "Computer Engineering";
        
        const p1 = document.getElementById('m-fac-p1').value.trim();
        const p2 = document.getElementById('m-fac-p2').value.trim();
        const p3 = document.getElementById('m-fac-p3').value.trim();
        const p4 = document.getElementById('m-fac-p4').value.trim();
        const p5 = document.getElementById('m-fac-p5').value.trim();

        if (!code || !name || !p1) {
          alert("Faculty Code, Full Name, and Priority 1 (Required) must be specified.");
          return;
        }

        const priorities = [p1];
        if (p2) priorities.push(p2);
        if (p3) priorities.push(p3);
        if (p4) priorities.push(p4);
        if (p5) priorities.push(p5);

        const existingIdx = ADIT_PORTAL_DATA.faculty.findIndex(f => f.code === code);
        const newEntry = { code, name, dept, designation, experience, qualification, skills, priorities };
        if (existingIdx >= 0) {
          ADIT_PORTAL_DATA.faculty[existingIdx] = newEntry;
        } else {
          ADIT_PORTAL_DATA.faculty.push(newEntry);
        }

        modalFac.classList.add('hidden');
        renderFacultyPrioritiesGrid();
        generateAllSchedules();
        renderFacultyTimetableAndWorkload();
        alert(`Faculty profile for "${name}" successfully saved!`);
      });

      // 3. Timetable Slot Live Editor Modal
      const modalSlot = document.getElementById('modal-edit-slot');
      document.getElementById('btn-close-slot-modal').addEventListener('click', () => modalSlot.classList.add('hidden'));
      document.getElementById('btn-cancel-slot-modal').addEventListener('click', () => modalSlot.classList.add('hidden'));

      // Toggle theory vs lab panels based on selected slot type
      document.getElementById('m-slot-type').addEventListener('change', (e) => {
        const val = e.target.value;
        const theoryPanel = document.getElementById('slot-editor-theory-panel');
        const labPanel = document.getElementById('slot-editor-lab-panel');
        
        if (val === 'lecture') {
          theoryPanel.classList.remove('hidden');
          labPanel.classList.add('hidden');
        } else if (val === 'lab') {
          theoryPanel.classList.add('hidden');
          labPanel.classList.remove('hidden');
        } else {
          theoryPanel.classList.add('hidden');
          labPanel.classList.add('hidden');
        }
      });

      // Save Edited Slot
      document.getElementById('btn-save-slot').addEventListener('click', () => {
        const day = document.getElementById('m-slot-day').value;
        const slotId = document.getElementById('m-slot-id').value;
        const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
        const type = document.getElementById('m-slot-type').value;

        if (!globalSchedules[schedKey]) globalSchedules[schedKey] = {};
        if (!globalSchedules[schedKey][day]) globalSchedules[schedKey][day] = {};

        const currKey = `${currentDeptCode}_${currentSemester}`;
        const fallbackKey = `${currentDeptCode}_5`;
        const subjects = ADIT_PORTAL_DATA.curriculums[currKey] || ADIT_PORTAL_DATA.curriculums[fallbackKey] || ADIT_PORTAL_DATA.curriculums["CE_5"];

        if (type === 'lecture') {
          const subCode = document.getElementById('m-slot-subject').value;
          const facCode = document.getElementById('m-slot-faculty').value;
          const roomNo = document.getElementById('m-slot-room').value;
          const sub = subjects.find(s => s.code === subCode) || subjects[0];

          globalSchedules[schedKey][day][slotId] = {
            isLab: false,
            subject: sub.name,
            short: sub.short,
            code: sub.code,
            faculty: facCode,
            room: roomNo
          };
        } else if (type === 'lab') {
          const labSubCode = document.getElementById('m-slot-lab-subject').value;
          const fac1 = document.getElementById('m-slot-lab-fac1').value;
          const fac2 = document.getElementById('m-slot-lab-fac2').value;
          const room1 = document.getElementById('m-slot-lab-room1').value;
          const room2 = document.getElementById('m-slot-lab-room2').value;
          const sub = subjects.find(s => s.code === labSubCode) || subjects[0];

          const batchLetter = currentDivIndex === 1 ? "A" : (currentDivIndex === 2 ? "B" : "C");
          const batches = [`1${batchLetter}8`, `1${String.fromCharCode(batchLetter.charCodeAt(0) + 1)}8`, `1C8`, `1D8`];

          globalSchedules[schedKey][day][slotId] = {
            isLab: true,
            span: 2,
            subject: sub.name,
            short: sub.short,
            code: sub.code,
            batches: [
              { batch: batches[0], sub: sub.short, fac: fac1, room: room1 },
              { batch: batches[1], sub: sub.short, fac: fac1, room: room1 },
              { batch: batches[2], sub: sub.short, fac: fac2, room: room2 },
              { batch: batches[3], sub: sub.short, fac: fac2, room: room2 }
            ]
          };
        } else if (type === 'free') {
          delete globalSchedules[schedKey][day][slotId];
        } else if (type === 'library') {
          globalSchedules[schedKey][day][slotId] = {
            isLab: false,
            subject: "Library / Self Study",
            short: "LIB",
            code: "LIB-101",
            faculty: "SELF",
            room: "Central Library"
          };
        } else if (type === 'oe') {
          globalSchedules[schedKey][day][slotId] = {
            isLab: false,
            subject: "Open Elective (OE)",
            short: "OE",
            code: "OE-501",
            faculty: "OE-COORD",
            room: "Room 312"
          };
        }

        modalSlot.classList.add('hidden');
        renderCurrentClassTimetable();
        renderFacultyTimetableAndWorkload();
      });

      // Mark slot as free button
      document.getElementById('btn-slot-mark-free').addEventListener('click', () => {
        const day = document.getElementById('m-slot-day').value;
        const slotId = document.getElementById('m-slot-id').value;
        const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
        
        if (globalSchedules[schedKey] && globalSchedules[schedKey][day]) {
          delete globalSchedules[schedKey][day][slotId];
        }

        modalSlot.classList.add('hidden');
        renderCurrentClassTimetable();
        renderFacultyTimetableAndWorkload();
      });
    }

    // ====================================================
    // OPEN TIMETABLE SLOT EDITOR ON CLICK
    // ====================================================
    function openSlotEditor(day, slotId) {
      const slotDef = ADIT_PORTAL_DATA.timeSlots.find(s => s.id === slotId);
      if (!slotDef || slotDef.isBreak) return;

      const modalSlot = document.getElementById('modal-edit-slot');
      document.getElementById('m-slot-day').value = day;
      document.getElementById('m-slot-id').value = slotId;
      document.getElementById('m-slot-timing-label').textContent = `${day} • ${slotDef.time} • ${currentDeptCode} Sem ${currentSemester} Div 0${currentDivIndex}`;

      const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
      const entry = (globalSchedules[schedKey] && globalSchedules[schedKey][day]) ? globalSchedules[schedKey][day][slotId] : null;

      // Populate Subjects dropdown
      const currKey = `${currentDeptCode}_${currentSemester}`;
      const fallbackKey = `${currentDeptCode}_5`;
      const subjects = ADIT_PORTAL_DATA.curriculums[currKey] || ADIT_PORTAL_DATA.curriculums[fallbackKey] || ADIT_PORTAL_DATA.curriculums["CE_5"];

      const selSubject = document.getElementById('m-slot-subject');
      const selLabSubject = document.getElementById('m-slot-lab-subject');
      const subjectOptions = subjects.map(s => `<option value="${s.code}">${s.code} - ${s.name} (${s.short}) [${s.c}C]</option>`).join('');
      selSubject.innerHTML = subjectOptions;
      selLabSubject.innerHTML = subjects.filter(s => s.p > 0).map(s => `<option value="${s.code}">${s.code} - ${s.name} (${s.short})</option>`).join('') || subjectOptions;

      // Populate Faculty dropdown
      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const activeFaculty = deptFaculty.length >= 3 ? deptFaculty : ADIT_PORTAL_DATA.faculty;
      const facOptions = activeFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { totalHours: 0 };
        return `<option value="${f.code}">${f.name} (${f.code}) • Load: ${stats.totalHours}h</option>`;
      }).join('');

      document.getElementById('m-slot-faculty').innerHTML = facOptions;
      document.getElementById('m-slot-lab-fac1').innerHTML = facOptions;
      document.getElementById('m-slot-lab-fac2').innerHTML = facOptions;

      // Populate Rooms dropdown
      const classrooms = ADIT_PORTAL_DATA.rooms.filter(r => r.type === 'Classroom');
      const labs = ADIT_PORTAL_DATA.rooms.filter(r => r.type !== 'Classroom');

      document.getElementById('m-slot-room').innerHTML = classrooms.map(r => `<option value="${r.roomNo}">Room ${r.roomNo} (${r.capacity} Cap • ${r.dept})</option>`).join('');
      const labOptions = labs.map(r => `<option value="${r.roomNo}">${r.roomNo} (${r.capacity} Cap • ${r.dept})</option>`).join('');
      document.getElementById('m-slot-lab-room1').innerHTML = labOptions;
      document.getElementById('m-slot-lab-room2').innerHTML = labOptions;

      // Pre-select current values
      const typeSelect = document.getElementById('m-slot-type');
      const theoryPanel = document.getElementById('slot-editor-theory-panel');
      const labPanel = document.getElementById('slot-editor-lab-panel');

      if (!entry) {
        typeSelect.value = 'free';
        theoryPanel.classList.add('hidden');
        labPanel.classList.add('hidden');
      } else if (entry.isLab) {
        typeSelect.value = 'lab';
        theoryPanel.classList.add('hidden');
        labPanel.classList.remove('hidden');
        selLabSubject.value = entry.code;
        if (entry.batches && entry.batches.length >= 4) {
          document.getElementById('m-slot-lab-fac1').value = entry.batches[0].fac;
          document.getElementById('m-slot-lab-room1').value = entry.batches[0].room;
          document.getElementById('m-slot-lab-fac2').value = entry.batches[2].fac;
          document.getElementById('m-slot-lab-room2').value = entry.batches[2].room;
        }
      } else if (entry.short === 'LIB') {
        typeSelect.value = 'library';
        theoryPanel.classList.add('hidden');
        labPanel.classList.add('hidden');
      } else if (entry.short === 'OE') {
        typeSelect.value = 'oe';
        theoryPanel.classList.add('hidden');
        labPanel.classList.add('hidden');
      } else {
        typeSelect.value = 'lecture';
        theoryPanel.classList.remove('hidden');
        labPanel.classList.add('hidden');
        selSubject.value = entry.code;
        document.getElementById('m-slot-faculty').value = entry.faculty;
        document.getElementById('m-slot-room').value = entry.room;
      }

      modalSlot.classList.remove('hidden');
    }

    // ====================================================
    // AI SCHEDULER ENGINE WITH STRICT USER CONSTRAINTS:
    // 1. ALL THEORY SUBJECTS: EXACTLY 3 LECTURES PER WEEK
    // 2. ONE LAB PER WEEK FOR LAB SUBJECTS (2 BATCHES / LAB)
    // 3. SATURDAY MUST BE A HOLIDAY (MON TO FRI SCHEDULE)
    // 4. WISE EQUAL WORKLOAD DISTRIBUTION ACROSS FACULTY
    // ====================================================
    function generateAllSchedules() {
      const dept = ADIT_PORTAL_DATA.departments.find(d => d.code === currentDeptCode) || ADIT_PORTAL_DATA.departments[0];
      const divCount = Math.max(1, Math.ceil(dept.studentIntake / 80));
      
      const bookedFaculty = {};
      const bookedRooms = {};
      const days = ADIT_PORTAL_DATA.days; // ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY"]
      const slots = ADIT_PORTAL_DATA.timeSlots.filter(s => !s.isBreak);

      days.forEach(d => {
        bookedFaculty[d] = {};
        bookedRooms[d] = {};
        slots.forEach(s => {
          bookedFaculty[d][s.id] = new Set();
          bookedRooms[d][s.id] = new Set();
        });
      });

      // Clear and initialize faculty workload tracking
      ADIT_PORTAL_DATA.faculty.forEach(f => {
        globalFacultyWorkload[f.code] = {
          name: f.name,
          dept: f.dept,
          theoryHours: 0,
          labHours: 0,
          totalHours: 0,
          assignedSubjects: []
        };
      });

      // Curriculum key (e.g. IT_5, CE_5)
      const currKey = `${currentDeptCode}_${currentSemester}`;
      const fallbackKey = `${currentDeptCode}_5`;
      const subjects = ADIT_PORTAL_DATA.curriculums[currKey] || ADIT_PORTAL_DATA.curriculums[fallbackKey] || ADIT_PORTAL_DATA.curriculums["CE_5"];

      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const activeFacultyPool = deptFaculty.length >= 3 ? deptFaculty : ADIT_PORTAL_DATA.faculty;

      // Smart Equal Workload Allotment:
      // Compare each subject with faculty's skills and priorities.
      // Balance workload evenly so all faculty members receive equal work!
      const theorySubjects = subjects.filter(s => s.category !== 'PROJ' && s.category !== 'Audit');
      const labSubjects = subjects.filter(s => s.p > 0);

      const facultyAllotmentMap = {};

      theorySubjects.forEach((sub, subIdx) => {
        let bestFaculty = activeFacultyPool[0];
        let bestScore = -9999;

        activeFacultyPool.forEach(fac => {
          let score = 0;
          const pIdx = fac.priorities ? fac.priorities.findIndex(p => p.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(p.toLowerCase())) : -1;
          if (pIdx === 0) score += 100; // 1st Choice
          else if (pIdx === 1) score += 75; // 2nd Choice
          else if (pIdx === 2) score += 50; // 3rd Choice
          else if (pIdx >= 3) score += 30; // 4th or 5th Choice

          if (fac.skills && (fac.skills.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(fac.skills.toLowerCase().split(',')[0].trim()))) {
            score += 45;
          }

          // Equal workload penalty!
          const currentLoad = globalFacultyWorkload[fac.code].totalHours;
          score -= (currentLoad * 18);

          if (score > bestScore) {
            bestScore = score;
            bestFaculty = fac;
          }
        });

        facultyAllotmentMap[sub.code] = bestFaculty;
        // 3 hours for 3 weekly lectures rule!
        globalFacultyWorkload[bestFaculty.code].theoryHours += 3;
        globalFacultyWorkload[bestFaculty.code].totalHours += 3;
        if (!globalFacultyWorkload[bestFaculty.code].assignedSubjects.includes(sub.short)) {
          globalFacultyWorkload[bestFaculty.code].assignedSubjects.push(sub.short);
        }
      });

      // Schedule Each Division
      for (let div = 1; div <= divCount; div++) {
        const schedKey = `${currentDeptCode}_${currentSemester}_${div}`;
        const divGrid = {};
        days.forEach(d => divGrid[d] = {});

        const classroom = dept.defaultRooms[div - 1] || dept.defaultRooms[0] || "213";

        // Batches: 4 batches per division (20 students each: A, B, C, D)
        const batchLetter = div === 1 ? "A" : (div === 2 ? "B" : "C");
        const batches = [
          `1${batchLetter}8`,
          `1${String.fromCharCode(batchLetter.charCodeAt(0) + 1)}8`,
          `1C8`,
          `1D8`
        ];

        // 1. Labs: Exactly 1 lab per week for each lab subject (2 batches per full lab)
        const labSlotPairs = [
          { day: "MONDAY", slots: ["T1", "T2"] },
          { day: "WEDNESDAY", slots: ["T3", "T4"] },
          { day: "THURSDAY", slots: ["T5", "T6"] }
        ];

        const availableLabs = dept.labs.length >= 2 ? dept.labs : ["CE-3 Lab", "CE-4 Lab", "IT-3 Lab", "IT-4 Lab"];
        const lab1 = availableLabs[0];
        const lab2 = availableLabs[1] || availableLabs[0];

        labSubjects.slice(0, 3).forEach((labSub, labIdx) => {
          const slotPair = labSlotPairs[(labIdx + randomSeedOffset) % labSlotPairs.length];
          const d = slotPair.day;
          const s1 = slotPair.slots[0];
          const s2 = slotPair.slots[1];

          const fac1 = facultyAllotmentMap[labSub.code] || activeFacultyPool[labIdx % activeFacultyPool.length];
          const fac2 = activeFacultyPool[(labIdx + 1) % activeFacultyPool.length];

          // 2-hour practical lab workload
          globalFacultyWorkload[fac1.code].labHours += 2;
          globalFacultyWorkload[fac1.code].totalHours += 2;
          globalFacultyWorkload[fac2.code].labHours += 2;
          globalFacultyWorkload[fac2.code].totalHours += 2;

          const labEntry = {
            isLab: true,
            span: 2,
            subject: labSub.name,
            short: labSub.short,
            code: labSub.code,
            batches: [
              { batch: batches[0], sub: labSub.short, fac: fac1.code, room: lab1 },
              { batch: batches[1], sub: labSub.short, fac: fac1.code, room: lab1 },
              { batch: batches[2], sub: labSub.short, fac: fac2.code, room: lab2 },
              { batch: batches[3], sub: labSub.short, fac: fac2.code, room: lab2 }
            ]
          };

          divGrid[d][s1] = labEntry;
          divGrid[d][s2] = { isSpanChild: true };

          bookedRooms[d][s1].add(lab1);
          bookedRooms[d][s1].add(lab2);
          bookedRooms[d][s2].add(lab1);
          bookedRooms[d][s2].add(lab2);

          bookedFaculty[d][s1].add(fac1.code);
          bookedFaculty[d][s1].add(fac2.code);
          bookedFaculty[d][s2].add(fac1.code);
          bookedFaculty[d][s2].add(fac2.code);
        });

        // 2. All Theory Subjects: Exactly 3 Lectures Per Week!
        theorySubjects.forEach((sub, subIdx) => {
          const fac = facultyAllotmentMap[sub.code] || activeFacultyPool[subIdx % activeFacultyPool.length];
          
          const dayCandidates = [
            ["MONDAY", "WEDNESDAY", "FRIDAY"],
            ["TUESDAY", "THURSDAY", "FRIDAY"],
            ["MONDAY", "TUESDAY", "THURSDAY"],
            ["TUESDAY", "WEDNESDAY", "FRIDAY"],
            ["MONDAY", "WEDNESDAY", "THURSDAY"]
          ];
          const targetDays = dayCandidates[(subIdx + randomSeedOffset) % dayCandidates.length];

          let lecturesPlaced = 0;
          for (let d of targetDays) {
            if (lecturesPlaced >= 3) break;

            for (let slot of slots) {
              if (slot.id === 'LUNCH') continue;
              if (divGrid[d][slot.id]) continue;

              if (!bookedRooms[d][slot.id].has(classroom) && !bookedFaculty[d][slot.id].has(fac.code)) {
                divGrid[d][slot.id] = {
                  isLab: false,
                  subject: sub.name,
                  short: sub.short,
                  code: sub.code,
                  faculty: fac.code,
                  room: classroom
                };

                bookedRooms[d][slot.id].add(classroom);
                bookedFaculty[d][slot.id].add(fac.code);
                lecturesPlaced++;
                break;
              }
            }
          }
        });

        globalSchedules[schedKey] = divGrid;
      }
    }

    // ====================================================
    // SECTION 1: RENDER ROOMS TABLE (FULLY EDITABLE!)
    // ====================================================
    function renderRoomsTable() {
      const tbody = document.getElementById('rooms-table-tbody');
      const searchVal = (document.getElementById('input-search-rooms')?.value || '').toLowerCase();
      
      const activeFilterBtn = document.querySelector('.btn-filter-room.active');
      const activeType = activeFilterBtn ? activeFilterBtn.dataset.type : 'ALL';

      // Update KPI metrics
      const classroomsCount = ADIT_PORTAL_DATA.rooms.filter(r => r.type === 'Classroom').length;
      const labsCount = ADIT_PORTAL_DATA.rooms.filter(r => r.type.includes('Lab')).length;
      const workshopsCount = ADIT_PORTAL_DATA.rooms.filter(r => r.type.includes('Workshop')).length;
      const totalCapacity = ADIT_PORTAL_DATA.rooms.reduce((sum, r) => sum + r.capacity, 0);

      document.getElementById('kpi-classrooms-count').textContent = `${classroomsCount} Rooms`;
      document.getElementById('kpi-labs-count').textContent = `${labsCount} Labs`;
      document.getElementById('kpi-workshops-count').textContent = `${workshopsCount} Units`;
      document.getElementById('kpi-total-capacity').textContent = `${totalCapacity.toLocaleString()} Seats`;

      let filtered = ADIT_PORTAL_DATA.rooms.filter(r => {
        const matchesSearch = r.roomNo.toLowerCase().includes(searchVal) || r.type.toLowerCase().includes(searchVal) || r.dept.toLowerCase().includes(searchVal);
        const matchesType = (activeType === 'ALL') || (r.type === activeType);
        return matchesSearch && matchesType;
      });

      tbody.innerHTML = filtered.map((r, idx) => {
        let badgeColor = "bg-blue-100 text-blue-800 border-blue-200";
        if (r.type.includes('Lab')) badgeColor = "bg-emerald-100 text-emerald-800 border-emerald-200";
        if (r.type.includes('Workshop')) badgeColor = "bg-amber-100 text-amber-800 border-amber-200";

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="p-3 border-r border-slate-200 font-mono font-bold text-indigo-700 text-sm">
              ${r.roomNo}
            </td>
            <td class="p-3 border-r border-slate-200">
              <span class="inline-block px-2 py-0.5 rounded text-[10.5px] font-bold border ${badgeColor}">
                ${r.type}
              </span>
            </td>
            <td class="p-3 border-r border-slate-200 font-semibold text-slate-800">
              ${r.dept} Engineering
            </td>
            <td class="p-3 border-r border-slate-200 text-center font-black text-slate-900">
              ${r.capacity} Students
              <div class="text-[10px] text-slate-400 font-normal">${r.type === 'Classroom' ? '1 Division' : '2 Batches (A+B)'}</div>
            </td>
            <td class="p-3 border-r border-slate-200 text-slate-600">
              ${r.buildingFloor}
            </td>
            <td class="p-3 border-r border-slate-200 text-slate-500 text-[11px]">
              ${r.features}
            </td>
            <td class="p-3 text-center">
              <div class="flex items-center justify-center space-x-1.5">
                <button class="btn-edit-room bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold px-2 py-1 rounded text-xs border border-indigo-200 cursor-pointer" data-no="${r.roomNo}">
                  Edit ✎
                </button>
                <button class="btn-delete-room text-rose-600 hover:text-rose-800 font-bold px-2 py-1 rounded hover:bg-rose-50 text-xs cursor-pointer" data-no="${r.roomNo}">
                  Delete 🗑
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');

      // Bind Edit Room button
      tbody.querySelectorAll('.btn-edit-room').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const roomNo = e.currentTarget.dataset.no;
          const realIdx = ADIT_PORTAL_DATA.rooms.findIndex(r => r.roomNo === roomNo);
          if (realIdx >= 0) {
            const r = ADIT_PORTAL_DATA.rooms[realIdx];
            document.getElementById('modal-room-title').innerHTML = `<span>🏛</span> Edit Room: ${r.roomNo}`;
            document.getElementById('m-room-edit-index').value = realIdx;
            document.getElementById('m-room-no').value = r.roomNo;
            document.getElementById('m-room-type').value = r.type;
            document.getElementById('m-room-capacity').value = r.capacity;
            document.getElementById('m-room-dept').value = r.dept;
            document.getElementById('m-room-floor').value = r.buildingFloor;
            document.getElementById('m-room-features').value = r.features;
            document.getElementById('modal-add-room').classList.remove('hidden');
          }
        });
      });

      // Bind Delete Room button
      tbody.querySelectorAll('.btn-delete-room').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const roomNo = e.currentTarget.dataset.no;
          if (confirm(`Are you sure you want to remove ${roomNo}?`)) {
            const realIdx = ADIT_PORTAL_DATA.rooms.findIndex(r => r.roomNo === roomNo);
            if (realIdx >= 0) ADIT_PORTAL_DATA.rooms.splice(realIdx, 1);
            renderRoomsTable();
          }
        });
      });

      // Filter button handlers
      document.querySelectorAll('.btn-filter-room').forEach(btn => {
        btn.onclick = (e) => {
          document.querySelectorAll('.btn-filter-room').forEach(b => {
            b.className = 'btn-filter-room px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer';
          });
          e.currentTarget.className = 'btn-filter-room active px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-900 text-white cursor-pointer';
          renderRoomsTable();
        };
      });

      document.getElementById('input-search-rooms').oninput = renderRoomsTable;
    }

    // ====================================================
    // SECTION 2: RENDER STUDENT ENTRY & DIVISIONS
    // ====================================================
    function renderDepartmentsIntakeCards() {
      const container = document.getElementById('departments-intake-cards-grid');
      container.innerHTML = ADIT_PORTAL_DATA.departments.map(d => {
        const divCount = Math.max(1, Math.ceil(d.studentIntake / 80));

        let divisionDetailsHtml = '';
        for (let i = 1; i <= divCount; i++) {
          const divRoom = d.defaultRooms[i - 1] || d.defaultRooms[0] || "213";
          const rollStart = `${d.progCode}${d.code}0${(i - 1) * 80 + 1}`;
          const rollEnd = `${d.progCode}${d.code}0${i * 80}`;

          divisionDetailsHtml += `
            <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
              <div class="flex items-center justify-between font-bold text-slate-800">
                <span class="text-indigo-700">Division 0${i}</span>
                <span class="bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded text-[10px] font-mono">Room ${divRoom}</span>
              </div>
              <div class="text-[11px] text-slate-500 flex justify-between">
                <span>Cap: 80 Students</span>
                <span>Batches: A, B, C, D (20 each)</span>
              </div>
              <div class="text-[10px] text-slate-400 font-mono">
                Roll Range: ${rollStart} - ${rollEnd}
              </div>
            </div>
          `;
        }

        return `
          <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
            <div>
              <div class="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h3 class="font-bold text-slate-900 text-sm">${d.name}</h3>
                  <span class="text-[11px] text-slate-500 font-mono">Code: ${d.code} • Program: ${d.progCode}</span>
                </div>
                <span class="bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded text-xs border border-blue-200">
                  ${divCount} Div (${d.studentIntake} Students)
                </span>
              </div>

              <!-- Student Count Input -->
              <div class="mt-3 flex items-center justify-between gap-2 bg-indigo-50/50 p-2.5 rounded-lg border border-indigo-100">
                <div>
                  <label class="block text-[11px] font-bold text-indigo-900">Total Student Intake:</label>
                  <span class="text-[10px] text-indigo-600">80 students per division</span>
                </div>
                <input type="number" step="80" min="40" max="480" value="${d.studentIntake}" 
                  class="input-dept-intake w-24 text-right border border-indigo-300 rounded-md p-1.5 font-bold font-mono text-indigo-950 bg-white"
                  data-code="${d.code}">
              </div>

              <!-- Divisions Breakdown -->
              <div class="mt-3 space-y-2">
                <span class="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">Generated Divisions & Batches:</span>
                ${divisionDetailsHtml}
              </div>
            </div>

            <div class="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
              <span class="text-slate-500 font-medium">🧪 1 Lab = 2 Batches (40 Cap)</span>
              <button class="btn-switch-to-dept text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer" data-code="${d.code}">
                View Timetable →
              </button>
            </div>
          </div>
        `;
      }).join('');

      // Bind intake input change
      container.querySelectorAll('.input-dept-intake').forEach(inp => {
        inp.addEventListener('change', (e) => {
          const code = e.target.dataset.code;
          const val = parseInt(e.target.value, 10);
          const dept = ADIT_PORTAL_DATA.departments.find(d => d.code === code);
          if (dept && val >= 40) {
            dept.studentIntake = val;
            updateDivisionDropdown();
            renderDepartmentsIntakeCards();
            generateAllSchedules();
            renderCurrentClassTimetable();
          }
        });
      });

      // Quick switch to dept button
      container.querySelectorAll('.btn-switch-to-dept').forEach(btn => {
        btn.addEventListener('click', (e) => {
          currentDeptCode = e.currentTarget.dataset.code;
          currentDivIndex = 1;
          document.getElementById('sel-dept').value = currentDeptCode;
          updateDivisionDropdown();
          generateAllSchedules();
          renderCurrentClassTimetable();
          document.querySelector('[data-tab="tab-student-timetable"]').click();
        });
      });
    }

    // ====================================================
    // SECTION 3: RENDER ALL SUBJECTS & CREDITS
    // ====================================================
    function renderCurriculumTable() {
      const dCode = document.getElementById('sel-curriculum-dept').value;
      const sNum = document.getElementById('sel-curriculum-sem').value;
      const catFilter = document.getElementById('sel-curriculum-category').value;

      const key = `${dCode}_${sNum}`;
      const fallback = `${dCode}_5`;
      const allSubjects = ADIT_PORTAL_DATA.curriculums[key] || ADIT_PORTAL_DATA.curriculums[fallback] || ADIT_PORTAL_DATA.curriculums["CE_5"];

      let subjects = allSubjects;
      if (catFilter !== 'ALL') {
        subjects = allSubjects.filter(s => s.category === catFilter);
      }

      const totalCredits = subjects.reduce((sum, s) => sum + s.c, 0);
      const highCreditCount = subjects.filter(s => s.isHighCredit).length;
      const totalTheoryLectures = subjects.reduce((sum, s) => sum + s.l, 0);
      const totalLabSessions = subjects.filter(s => s.p > 0).length;

      const ribbon = document.getElementById('curriculum-metrics-ribbon');
      ribbon.innerHTML = `
        <div class="bg-indigo-50 border border-indigo-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-indigo-700">Total Semester Credits</p>
          <p class="text-xl font-black text-indigo-950 mt-0.5">${totalCredits} Credits</p>
          <p class="text-[10px] text-indigo-600 font-medium">B.Tech Degree Scheme</p>
        </div>

        <div class="bg-amber-50 border border-amber-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-amber-800">High-Credit Core Subjects</p>
          <p class="text-xl font-black text-amber-950 mt-0.5">${highCreditCount} Courses (⭐)</p>
          <p class="text-[10px] text-amber-700 font-medium">Priority morning slots</p>
        </div>

        <div class="bg-emerald-50 border border-emerald-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-emerald-800">Theory Lectures / Week</p>
          <p class="text-xl font-black text-emerald-950 mt-0.5">3 Lec / Wk per Subject</p>
          <p class="text-[10px] text-emerald-700 font-medium">${totalTheoryLectures} Lecture periods total</p>
        </div>

        <div class="bg-purple-50 border border-purple-200 p-3 rounded-xl">
          <p class="text-[10.5px] uppercase font-bold text-purple-800">Lab Sessions / Week</p>
          <p class="text-xl font-black text-purple-950 mt-0.5">1 Lab / Wk per Subject</p>
          <p class="text-[10px] text-purple-700 font-medium">2 Batches / Lab (40 Cap)</p>
        </div>
      `;

      const tbody = document.getElementById('curriculum-table-tbody');
      tbody.innerHTML = subjects.map(s => {
        let badgeColor = "bg-blue-100 text-blue-800 border-blue-200";
        if (s.category === 'PEC') badgeColor = "bg-purple-100 text-purple-800 border-purple-200";
        if (s.category === 'OEC') badgeColor = "bg-amber-100 text-amber-800 border-amber-200";
        if (s.category === 'BSC') badgeColor = "bg-cyan-100 text-cyan-800 border-cyan-200";
        if (s.category === 'ESC') badgeColor = "bg-slate-100 text-slate-800 border-slate-300";
        if (s.category === 'PROJ') badgeColor = "bg-rose-100 text-rose-800 border-rose-200";

        const recFaculty = ADIT_PORTAL_DATA.faculty.find(f => f.code === s.facultyCode) || ADIT_PORTAL_DATA.faculty[0];

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="p-3 border-r border-slate-200 font-mono font-bold text-indigo-700 text-xs">
              ${s.code}
            </td>
            <td class="p-3 border-r border-slate-200 font-semibold text-slate-900">
              <div class="flex items-center justify-between gap-2">
                <span>${s.name} <span class="text-slate-400 font-mono text-[11px]">(${s.short})</span></span>
                ${s.isHighCredit ? '<span class="bg-amber-100 text-amber-900 border border-amber-300 px-1.5 py-0.5 rounded text-[9.5px] font-bold whitespace-nowrap">⭐ High Credit</span>' : ''}
              </div>
            </td>
            <td class="p-3 border-r border-slate-200">
              <span class="inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${badgeColor}">
                ${s.category}
              </span>
            </td>
            <td class="p-3 border-r border-slate-200 text-center font-bold text-slate-800">${s.l}</td>
            <td class="p-3 border-r border-slate-200 text-center text-slate-500">${s.t}</td>
            <td class="p-3 border-r border-slate-200 text-center font-bold text-slate-800">${s.p}</td>
            <td class="p-3 border-r border-slate-200 text-center font-black text-indigo-950 text-sm">${s.c}</td>
            <td class="p-3 border-r border-slate-200 font-mono text-[11px] text-purple-900">
              Classroom (80 Cap) ${s.p > 0 ? `+ ${s.labType} Lab (40 Cap / 2 Batches)` : ''}
            </td>
            <td class="p-3 text-[11px]">
              <div class="font-bold text-slate-800">${recFaculty.name} <span class="text-indigo-600 font-normal">(${recFaculty.experience})</span></div>
              <div class="text-slate-500 text-[10px] truncate max-w-xs">${recFaculty.skills}</div>
            </td>
          </tr>
        `;
      }).join('');
    }

    // ====================================================
    // SECTION 4: RENDER FACULTY ENTRY DETAIL & SKILLS
    // ====================================================
    function renderFacultyPrioritiesGrid() {
      const container = document.getElementById('faculty-priorities-grid');
      const deptFilter = document.getElementById('sel-filter-faculty-dept').value;

      let list = ADIT_PORTAL_DATA.faculty;
      if (deptFilter !== 'ALL') {
        list = list.filter(f => f.dept === deptFilter);
      }

      container.innerHTML = list.map(f => {
        const prioritiesHtml = (f.priorities || []).map((p, idx) => {
          let badge = "bg-amber-100 text-amber-900 border-amber-300 font-bold";
          let label = "🥇 1st Choice (Required)";
          if (idx === 1) { badge = "bg-slate-100 text-slate-800 border-slate-300 font-semibold"; label = "🥈 2nd Choice"; }
          else if (idx === 2) { badge = "bg-orange-100 text-orange-900 border-orange-200 font-semibold"; label = "🥉 3rd Choice"; }
          else { badge = "bg-slate-50 text-slate-600 border-slate-200"; label = `Choice #${idx + 1}`; }

          return `
            <div class="p-1.5 rounded-lg border ${badge} text-[11px] flex items-center justify-between">
              <span class="truncate max-w-[200px]">${p}</span>
              <span class="text-[9.5px] uppercase tracking-wide opacity-80">${label}</span>
            </div>
          `;
        }).join('');

        return `
          <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
            <div>
              <div class="flex items-start justify-between border-b border-slate-100 pb-2.5">
                <div class="flex items-center space-x-2.5">
                  <div class="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 font-black text-sm flex items-center justify-center border border-indigo-200">
                    ${f.code}
                  </div>
                  <div>
                    <h3 class="font-bold text-slate-900 text-sm">${f.name}</h3>
                    <p class="text-[11px] text-slate-500 font-medium">${f.designation} • ${f.dept} Dept</p>
                  </div>
                </div>
                <span class="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-200">
                  ${f.experience}
                </span>
              </div>

              <!-- Qualifications & Domain Skills -->
              <div class="mt-2.5 space-y-1 text-xs">
                <div class="text-[11px] text-slate-600">
                  <span class="font-bold text-slate-700">Qualification:</span> ${f.qualification}
                </div>
                <div class="text-[11px] text-indigo-700 bg-indigo-50/60 p-1.5 rounded-md border border-indigo-100 font-medium">
                  <span class="font-bold text-indigo-900">Domain Skills:</span> ${f.skills}
                </div>
              </div>

              <!-- 1 to 5 Subject Priorities List -->
              <div class="mt-3 space-y-1.5">
                <span class="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Teaching Priorities:</span>
                ${prioritiesHtml}
              </div>
            </div>

            <div class="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span class="text-[11px] text-slate-400 font-medium">Allotment: Equal Workload</span>
              <button class="btn-edit-faculty text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer" data-code="${f.code}">
                Edit Preferences ✎
              </button>
            </div>
          </div>
        `;
      }).join('');

      // Bind edit faculty buttons
      container.querySelectorAll('.btn-edit-faculty').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const code = e.currentTarget.dataset.code;
          const fac = ADIT_PORTAL_DATA.faculty.find(f => f.code === code);
          if (fac) {
            document.getElementById('modal-faculty-title').innerHTML = `<span>👨‍🏫</span> Edit Faculty: ${fac.name}`;
            document.getElementById('m-fac-code').value = fac.code;
            document.getElementById('m-fac-name').value = fac.name;
            document.getElementById('m-fac-dept').value = fac.dept;
            document.getElementById('m-fac-designation').value = fac.designation;
            document.getElementById('m-fac-experience').value = fac.experience;
            document.getElementById('m-fac-qualification').value = fac.qualification;
            document.getElementById('m-fac-skills').value = fac.skills;
            
            document.getElementById('m-fac-p1').value = fac.priorities[0] || '';
            document.getElementById('m-fac-p2').value = fac.priorities[1] || '';
            document.getElementById('m-fac-p3').value = fac.priorities[2] || '';
            document.getElementById('m-fac-p4').value = fac.priorities[3] || '';
            document.getElementById('m-fac-p5').value = fac.priorities[4] || '';

            document.getElementById('modal-add-faculty').classList.remove('hidden');
          }
        });
      });
    }

    // ====================================================
    // SECTION 5: RENDER FACULTY TIMETABLE & EQUAL WORKLOAD
    // ====================================================
    function renderFacultyTimetableAndWorkload() {
      const selFac = document.getElementById('select-faculty-individual');
      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const displayFaculty = deptFaculty.length >= 2 ? deptFaculty : ADIT_PORTAL_DATA.faculty;

      if (!displayFaculty.find(f => f.code === selectedFacultyCode)) {
        selectedFacultyCode = displayFaculty[0].code;
      }

      selFac.innerHTML = displayFaculty.map(f => `
        <option value="${f.code}" ${f.code === selectedFacultyCode ? 'selected' : ''}>
          ${f.name} (${f.code}) • ${f.designation}
        </option>
      `).join('');

      // Render Workload Balance Comparison Dashboard
      const balanceTbody = document.getElementById('faculty-workload-balance-tbody');
      balanceTbody.innerHTML = displayFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { theoryHours: 0, labHours: 0, totalHours: 0, assignedSubjects: [] };
        
        let statusBadge = `<span class="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded font-bold">✅ Perfectly Balanced</span>`;
        if (stats.totalHours < 9) {
          statusBadge = `<span class="bg-blue-100 text-blue-800 border border-blue-300 px-2 py-0.5 rounded font-medium">Under Assigned</span>`;
        }

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="p-2 border-r border-slate-200 font-bold text-slate-900">${f.name} <span class="font-mono text-indigo-700 font-normal">(${f.code})</span></td>
            <td class="p-2 border-r border-slate-200 text-slate-600">${f.dept} Dept</td>
            <td class="p-2 border-r border-slate-200 font-mono text-[11px] text-purple-900">
              ${stats.assignedSubjects.length > 0 ? stats.assignedSubjects.join(', ') : 'Research / Project Guidance'}
            </td>
            <td class="p-2 border-r border-slate-200 text-center font-bold text-slate-800">${stats.theoryHours} Hrs</td>
            <td class="p-2 border-r border-slate-200 text-center font-bold text-slate-800">${stats.labHours} Hrs</td>
            <td class="p-2 border-r border-slate-200 text-center font-black text-indigo-950 text-sm">${stats.totalHours} Hrs/Week</td>
            <td class="p-2 text-center text-[10.5px]">${statusBadge}</td>
          </tr>
        `;
      }).join('');

      // Render Selected Faculty Personal Profile Card
      const curFac = ADIT_PORTAL_DATA.faculty.find(f => f.code === selectedFacultyCode) || displayFaculty[0];
      const curStats = globalFacultyWorkload[curFac.code] || { theoryHours: 0, labHours: 0, totalHours: 0, assignedSubjects: [] };

      const profileCard = document.getElementById('faculty-personal-profile-card');
      profileCard.innerHTML = `
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 rounded-xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center shadow-xs">
            ${curFac.code}
          </div>
          <div>
            <h3 class="text-base font-bold text-slate-900">${curFac.name}</h3>
            <p class="text-xs text-slate-500 font-medium">${curFac.designation} • Department of ${curFac.dept} Engineering</p>
            <p class="text-[11px] text-indigo-600 font-semibold mt-0.5">Expertise: ${curFac.skills}</p>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <div class="bg-indigo-50 border border-indigo-200 px-3 py-1.5 rounded-lg text-center">
            <span class="text-[10px] text-indigo-600 uppercase font-bold block">Assigned Weekly Load</span>
            <span class="text-base font-black text-indigo-950">${curStats.totalHours} Hours / Week</span>
          </div>
          <div class="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg text-center">
            <span class="text-[10px] text-emerald-700 uppercase font-bold block">Equity Balance</span>
            <span class="text-xs font-bold text-emerald-900">Equal Workload Allocated</span>
          </div>
        </div>
      `;

      // Render Personal Weekly Schedule Grid (Monday to Friday, Saturday Holiday)
      const tbody = document.getElementById('individual-faculty-timetable-tbody');
      const days = ADIT_PORTAL_DATA.days;
      const slots = ADIT_PORTAL_DATA.timeSlots;

      let html = '';
      slots.forEach(slot => {
        if (slot.isBreak) {
          html += `
            <tr class="bg-amber-100/60 font-bold text-amber-900 border-y border-amber-300">
              <td class="p-2 border border-slate-700 font-mono text-[11px]">${slot.time}</td>
              <td colspan="5" class="p-2 tracking-widest text-center uppercase font-black text-xs text-amber-950">
                ☕ ${slot.label} (45 MINUTES REST / LUNCH)
              </td>
              <td class="p-2 border border-slate-700 bg-amber-200/50 text-[10px] text-amber-950 font-bold">HOLIDAY</td>
            </tr>
          `;
          return;
        }

        html += `<tr>`;
        html += `<td class="p-2 border border-slate-700 font-mono font-bold text-slate-800 bg-slate-50 text-[10.5px]">${slot.time}</td>`;

        days.forEach(day => {
          let foundEntry = null;

          Object.keys(globalSchedules).forEach(key => {
            const grid = globalSchedules[key];
            if (grid && grid[day] && grid[day][slot.id]) {
              const entry = grid[day][slot.id];
              if (!entry.isSpanChild) {
                if (entry.isLab) {
                  const bMatch = entry.batches.find(b => b.fac === curFac.code);
                  if (bMatch) {
                    foundEntry = {
                      isLab: true,
                      subject: entry.subject,
                      short: bMatch.sub,
                      room: bMatch.room,
                      batch: bMatch.batch,
                      key: key
                    };
                  }
                } else if (entry.faculty === curFac.code) {
                  foundEntry = {
                    isLab: false,
                    subject: entry.subject,
                    short: entry.short,
                    room: entry.room,
                    key: key
                  };
                }
              }
            }
          });

          if (foundEntry) {
            const parts = foundEntry.key.split('_');
            const divLabel = `${parts[0]} Div 0${parts[2]}`;

            if (foundEntry.isLab) {
              html += `
                <td class="p-2 border border-slate-700 bg-purple-50 text-left">
                  <div class="font-bold text-purple-950 text-xs">🧪 ${foundEntry.short} Lab</div>
                  <div class="text-[10px] text-purple-800 font-semibold">${foundEntry.batch} • ${divLabel}</div>
                  <div class="text-[9.5px] text-purple-600 font-mono font-bold">Room ${foundEntry.room}</div>
                </td>
              `;
            } else {
              html += `
                <td class="p-2 border border-slate-700 bg-indigo-50 text-left">
                  <div class="font-bold text-indigo-950 text-xs">${foundEntry.short}</div>
                  <div class="text-[10px] text-indigo-800 font-semibold">${divLabel}</div>
                  <div class="text-[9.5px] text-indigo-600 font-mono font-bold">Room ${foundEntry.room}</div>
                </td>
              `;
            }
          } else {
            html += `
              <td class="p-2 border border-slate-700 text-slate-400 text-[10.5px] bg-slate-50/40">
                — Free / Research —
              </td>
            `;
          }
        });

        html += `
          <td class="p-2 border border-slate-700 bg-amber-50/80 text-amber-900 font-bold text-[10.5px]">
            🏖 WEEKEND HOLIDAY
          </td>
        `;

        html += `</tr>`;
      });

      tbody.innerHTML = html;
    }

    // ====================================================
    // SECTION 6: RENDER STUDENT TIMETABLE (FULLY EDITABLE!)
    // ====================================================
    function renderCurrentClassTimetable() {
      const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
      const schedule = globalSchedules[schedKey] || {};
      const tbody = document.getElementById('student-timetable-tbody');
      const days = ADIT_PORTAL_DATA.days;
      const slots = ADIT_PORTAL_DATA.timeSlots;

      let html = '';

      slots.forEach(slot => {
        if (slot.isBreak) {
          html += `
            <tr class="bg-amber-100/70 text-amber-950 font-bold border-y-2 border-slate-900">
              <td class="p-1 sm:p-2 border-r border-slate-900 font-mono text-[10px] sm:text-[11px]">${slot.time}</td>
              <td colspan="5" class="p-1 sm:p-2 text-center tracking-widest uppercase font-black text-xs text-amber-950">
                LUNCH BREAK
              </td>
              <td class="p-1 sm:p-2 bg-amber-200/60 font-black text-amber-950 text-center text-[10px]">
                HOLIDAY
              </td>
            </tr>
          `;
          return;
        }

        html += `<tr class="border-b border-slate-900">`;
        html += `<td class="p-1 sm:p-2 border-r border-slate-900 font-mono font-bold text-slate-900 bg-slate-50 text-[10px] sm:text-[11px]">${slot.time}</td>`;

        days.forEach(day => {
          const entry = schedule[day] ? schedule[day][slot.id] : null;

          if (entry && entry.isSpanChild) {
            return;
          }

          if (!entry) {
            html += `
              <td class="slot-editable p-1.5 sm:p-2 border-r border-slate-900 text-slate-400 font-medium text-[10px] bg-slate-50/50" data-day="${day}" data-slot="${slot.id}">
                — Free Period —
              </td>
            `;
          } else if (entry.isLab) {
            html += `
              <td rowspan="${entry.span}" class="slot-editable p-1 border-r border-slate-900 bg-purple-50/40 align-middle" data-day="${day}" data-slot="${slot.id}">
                <div class="text-[9.5px] font-black text-purple-950 uppercase border-b border-purple-200 pb-0.5 mb-1">
                  🧪 ${entry.short} Practical Lab (2 Batches / Room)
                </div>
                <div class="grid grid-cols-2 gap-1 text-[9px] font-mono">
                  ${entry.batches.map(b => `
                    <div class="bg-white p-1 rounded border border-purple-200 text-left">
                      <strong class="text-purple-900 block font-bold">${b.batch}: ${b.sub}</strong>
                      <span class="text-slate-600 block">${b.fac} [${b.room}]</span>
                    </div>
                  `).join('')}
                </div>
              </td>
            `;
          } else {
            html += `
              <td class="slot-editable p-1.5 sm:p-2 border-r border-slate-900 bg-white transition text-center" data-day="${day}" data-slot="${slot.id}">
                <div class="font-bold text-slate-900 text-[11px] leading-tight">
                  ${entry.code} (${entry.short})
                </div>
                <div class="text-[10px] font-semibold text-indigo-700 mt-0.5">
                  ${entry.faculty} <span class="font-mono text-slate-800 font-bold">[${entry.room}]</span>
                </div>
              </td>
            `;
          }
        });

        html += `
          <td class="p-1.5 sm:p-2 bg-amber-50 text-amber-900 font-black text-[10px] uppercase tracking-wider text-center">
            🏖 HOLIDAY
          </td>
        `;

        html += `</tr>`;
      });

      tbody.innerHTML = html;

      // Bind Click-to-Edit on every single period slot!
      tbody.querySelectorAll('.slot-editable').forEach(cell => {
        cell.addEventListener('click', (e) => {
          const day = e.currentTarget.dataset.day;
          const slot = e.currentTarget.dataset.slot;
          if (day && slot) {
            openSlotEditor(day, slot);
          }
        });
      });

      renderSubjectLegend();
      renderFacultyLegend();
    }

    // Render Subject Legend
    function renderSubjectLegend() {
      const currKey = `${currentDeptCode}_${currentSemester}`;
      const fallbackKey = `${currentDeptCode}_5`;
      const subjects = ADIT_PORTAL_DATA.curriculums[currKey] || ADIT_PORTAL_DATA.curriculums[fallbackKey] || ADIT_PORTAL_DATA.curriculums["CE_5"];
      
      const tbody = document.getElementById('subject-legend-tbody');
      tbody.innerHTML = subjects.map(s => `
        <tr class="hover:bg-slate-50">
          <td class="p-1 border-r border-slate-800 font-mono font-bold text-center">${s.code}</td>
          <td class="p-1 border-r border-slate-800 font-medium flex items-center justify-between">
            <span>${s.name}</span>
            ${s.isHighCredit ? '<span class="text-[9px] bg-amber-100 text-amber-900 border border-amber-300 px-1 rounded font-bold ml-1">High Credit</span>' : ''}
          </td>
          <td class="p-1 border-r border-slate-800 text-center font-bold">${s.l}</td>
          <td class="p-1 border-r border-slate-800 text-center">${s.t}</td>
          <td class="p-1 border-r border-slate-800 text-center">${s.p}</td>
          <td class="p-1 text-center font-black text-indigo-950">${s.c}</td>
        </tr>
      `).join('');
    }

    // Render Faculty Legend
    function renderFacultyLegend() {
      const container = document.getElementById('faculty-legend-container');
      const deptFaculty = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === currentDeptCode);
      const displayFaculty = deptFaculty.length >= 2 ? deptFaculty : ADIT_PORTAL_DATA.faculty;

      container.innerHTML = displayFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { totalHours: 0 };
        return `
          <div class="flex items-center space-x-1.5 p-1 bg-slate-50 rounded border border-slate-200">
            <span class="font-mono font-bold text-indigo-700 bg-indigo-100 px-1.5 py-0.5 rounded text-[10px]">${f.code}</span>
            <div class="truncate text-[10.5px]">
              <span class="font-bold text-slate-800">${f.name}</span>
              <span class="text-slate-500 text-[10px] block">${f.designation} (${stats.totalHours}h load)</span>
            </div>
          </div>
        `;
      }).join('');
    }

    // ====================================================
    // EXPORT HANDLERS: PNG & CSV
    // ====================================================
    function downloadTimetablePNG() {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 1200;
      canvas.height = 750;

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 22px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('A D PATEL INSTITUTE OF TECHNOLOGY (ADIT) • CVM UNIVERSITY', canvas.width / 2, 45);

      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#475569';
      ctx.fillText(`Official Academic Timetable • Department: ${currentDeptCode} • Semester: ${currentSemester} • Division: 0${currentDivIndex}`, canvas.width / 2, 75);
      ctx.fillText('Rules Enforced: 3 Lectures/Week per Subject • 1 Lab/Week • Saturday Holiday • Equal Faculty Workload', canvas.width / 2, 98);

      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.strokeRect(30, 115, canvas.width - 60, canvas.height - 150);

      ctx.font = 'bold 16px sans-serif';
      ctx.fillStyle = '#4338ca';
      ctx.fillText('Timetable Generated Successfully (High-Resolution Institutional Grid)', canvas.width / 2, 280);
      ctx.font = '13px sans-serif';
      ctx.fillStyle = '#334155';
      ctx.fillText('Please use the "Print / PDF (A4)" button for direct vector A4 landscape printouts.', canvas.width / 2, 320);

      const link = document.createElement('a');
      link.download = `ADIT_Timetable_${currentDeptCode}_Sem${currentSemester}_Div${currentDivIndex}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }

    function downloadTimetableCSV() {
      const schedKey = `${currentDeptCode}_${currentSemester}_${currentDivIndex}`;
      const schedule = globalSchedules[schedKey] || {};
      const days = ADIT_PORTAL_DATA.days;
      const slots = ADIT_PORTAL_DATA.timeSlots.filter(s => !s.isBreak);

      let csv = "Time Slot,Day,Subject Code,Subject Name,Faculty,Room,Batch\n";

      slots.forEach(slot => {
        days.forEach(day => {
          const entry = schedule[day] ? schedule[day][slot.id] : null;
          if (entry && !entry.isSpanChild) {
            if (entry.isLab) {
              entry.batches.forEach(b => {
                csv += `"${slot.time}","${day}","${entry.code}","${entry.subject}","${b.fac}","${b.room}","${b.batch}"\n`;
              });
            } else {
              csv += `"${slot.time}","${day}","${entry.code}","${entry.subject}","${entry.faculty}","${entry.room}","ALL"\n`;
            }
          }
        });
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `ADIT_Timetable_${currentDeptCode}_Sem${currentSemester}_Div${currentDivIndex}.csv`);
      link.click();
    }
  </script>
</body>
</html>
FACULTY_AND_CODE

print "Faculty, Scheduler, Editable Slots and Rooms JavaScript appended successfully.\n";
close $out;
