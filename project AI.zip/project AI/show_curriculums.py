import re

with open("index.html", "r", encoding="utf-8") as f:
    text = f.read()

curr_keys = ["CE", "IT", "CSD", "AIDS", "ME", "CL", "EE", "CH"]
for dept in curr_keys:
    print(f"\n==================== {dept} CURRICULUM ====================")
    for sem in range(1, 9):
        k = f"{dept}_{sem}"
        m = re.search(rf"['\"]{k}['\"]\s*:\s*\[(.*?)\n\s*\]", text, re.DOTALL)
        if m:
            subs = re.findall(r"\{\s*code:\s*['\"]([^'\"]+)['\"].*?name:\s*['\"]([^'\"]+)['\"].*?short:\s*['\"]([^'\"]+)['\"].*?facultyCode:\s*['\"]([^'\"]+)['\"]", m.group(1), re.DOTALL)
            sub_strs = [f"{s[2]}->{s[3]}" for s in subs]
            print(f"  Sem {sem} ({len(subs)}): {', '.join(sub_strs)}")
