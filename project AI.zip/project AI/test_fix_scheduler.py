import subprocess
import re

with open("test_bundle.js", "r", encoding="utf-8") as f:
    code = f.read()

# Fix 1: Update IT_5 subjects
code = code.replace('{ code: "202044503", name: "Artificial Intelligence (PE1)", short: "AI", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "KJP" }',
                    '{ code: "202044503", name: "Artificial Intelligence (PE1)", short: "AI", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "DJP" }')

code = code.replace('{ code: "202045605", name: "Advanced Java Programming (PE1)", short: "AJP", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "KJP" }',
                    '{ code: "202045605", name: "Advanced Java Programming (PE1)", short: "AJP", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "PRB" }')

code = code.replace('{ code: "202045607", name: "Cyber Security (PE1)", short: "CS", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "SJM" }',
                    '{ code: "202045607", name: "Cyber Security (PE1)", short: "CS", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "HVP" }')

code = code.replace('{ code: "202045698", name: "Open Elective (Project Management)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }',
                    '{ code: "202045698", name: "Open Elective (Project Management)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "KRP" }')

# Fix 2: In generateAllSchedules, sort nonHodPool by totalHours ascending
code = code.replace(
    'const nonHodPool = activeFacultyPool.filter(f => !isHeadOfDepartment(f));',
    'const nonHodPool = activeFacultyPool.filter(f => !isHeadOfDepartment(f)).sort((a, b) => globalFacultyWorkload[a.code].totalHours - globalFacultyWorkload[b.code].totalHours);'
)

# Test run
probe = """
generateAllSchedules();
var keys = Object.keys(globalFacultyWorkload);
print("=== AFTER SMART EQUAL BALANCING ===");
var depts = {};
for (var i = 0; i < keys.length; i++) {
  var k = keys[i];
  var w = globalFacultyWorkload[k];
  if (!depts[w.dept]) depts[w.dept] = [];
  depts[w.dept].push(w);
}

var dKeys = Object.keys(depts);
for (var d = 0; d < dKeys.length; d++) {
  var dept = dKeys[d];
  print("\\n--- Department " + dept + " ---");
  var list = depts[dept];
  for (var j = 0; j < list.length; j++) {
    var f = list[j];
    print(f.name + " (" + keys.find(k => globalFacultyWorkload[k] === f) + "): Total=" + f.totalHours + "h (Th=" + f.theoryHours + "h, Lab=" + f.labHours + "h) Subs: " + f.assignedSubjects.join(", "));
  }
}
"""

with open("test_probe.js", "w", encoding="utf-8") as f:
    f.write(code + "\n" + probe)

res = subprocess.run(["/System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc", "test_probe.js"], capture_output=True, text=True)
print(res.stdout)
if res.stderr:
    print("ERR:", res.stderr)
