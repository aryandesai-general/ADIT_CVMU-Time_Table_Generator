use strict;
use warnings;

print "Curriculum script ready\n";
