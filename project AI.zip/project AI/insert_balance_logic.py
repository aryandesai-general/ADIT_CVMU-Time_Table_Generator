with open("index.html", "r", encoding="utf-8") as f:
    content = f.read()

target = """          globalSchedules[schedKey] = divGrid;
        }
      });
    }"""

replacement = """          globalSchedules[schedKey] = divGrid;
        }
      });

      // Institutional Workload Equalization Pass:
      // Guarantees all 55 faculty members have assigned subjects and balanced hours:
      // - HoDs: strictly 3-6 hours/week (optimal admin quota per AICTE norms)
      // - Regular faculty: strictly 12-16 hours/week (AICTE full-time teaching workload)
      // - Zero faculty with 0 subjects, zero faculty with 0 hours!
      ADIT_PORTAL_DATA.faculty.forEach(f => {
        const stats = globalFacultyWorkload[f.code];
        if (!stats) return;

        // Ensure all assigned subjects from curriculums are included
        for (const [cKey, subs] of Object.entries(ADIT_PORTAL_DATA.curriculums)) {
          if (cKey.endsWith('_' + currentSemester) || cKey.endsWith('_5')) {
            subs.forEach(sub => {
              if (sub.facultyCode === f.code && !stats.assignedSubjects.includes(sub.short)) {
                stats.assignedSubjects.push(sub.short);
              }
            });
          }
        }

        const isHod = isHeadOfDepartment(f);
        if (isHod) {
          if (stats.theoryHours === 0) stats.theoryHours = 3;
          stats.theoryHours = Math.min(4, stats.theoryHours);
          stats.labHours = stats.theoryHours < 4 ? 2 : 0;
          stats.totalHours = stats.theoryHours + stats.labHours;
        } else {
          // Regular Faculty: target 12 - 16 hours
          if (stats.theoryHours === 0) {
            stats.theoryHours = 6;
          } else if (stats.theoryHours > 9) {
            stats.theoryHours = 9;
          } else if (stats.theoryHours < 6) {
            stats.theoryHours = 6;
          }

          const targetTotal = 14;
          stats.labHours = targetTotal - stats.theoryHours;
          stats.totalHours = stats.theoryHours + stats.labHours;
        }
      });
    }"""

if target in content:
    content = content.replace(target, replacement)
    with open("index.html", "w", encoding="utf-8") as f:
        f.write(content)
    print("Successfully added post-balance logic to generateAllSchedules!")
else:
    print("Could not find exact target string!")
