import json, re

with open("index.html") as f:
    html = f.read()

m = re.search(r"const ADIT_PORTAL_DATA = (\{.*?\});\n", html, re.DOTALL)
if m:
    data = json.loads(m.group(1))
    print(f"Total faculty: {len(data['faculty'])}")
    depts = {}
    for fac in data["faculty"]:
        depts.setdefault(fac["dept"], []).append(fac)
    for d, facs in depts.items():
        print(f"\n=== {d} ({len(facs)} faculty) ===")
        for f in facs:
            print(f"  {f['code']}: {f['name']} ({f.get('designation', '')}) | Priorities: {f.get('priorities', [])}")
