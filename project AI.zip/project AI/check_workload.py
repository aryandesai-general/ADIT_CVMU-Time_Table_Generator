from adit_timetable_ai.database import ADIT_DATABASE
from adit_timetable_ai.csp_solver import ADITTimetableScheduler

scheduler = ADITTimetableScheduler(ADIT_DATABASE)
schedules, faculty_loads = scheduler.generate_master_timetable()

print(f"Generated schedules: {len(schedules)}")
print("\n--- FACULTY WORKLOAD DISTRIBUTION ---")
hod_codes = set()
for f in ADIT_DATABASE.faculty:
    d = (f.designation or "").lower()
    if "head" in d or "hod" in d or "principal" in d:
        hod_codes.add(f.code)

for f in sorted(ADIT_DATABASE.faculty, key=lambda x: (x.dept, x.name)):
    load = faculty_loads.get(f.code, {"theory": 0, "lab": 0, "total": 0, "subjects": []})
    is_hod = f.code in hod_codes
    hod_tag = " [HOD]" if is_hod else ""
    tot = load["total"]
    th = load["theory"]
    lb = load["lab"]
    subs = load.get("subjects", [])
    print(f"[{f.dept:5s}] {f.code:6s} {f.name:25s}{hod_tag:7s}: Total={tot:2d}h (Th={th:2d}h, Lb={lb:2d}h) Subs={subs}")
