"""
ADIT AI Timetable Maker & Multi-Department Scheduling Package.
Automated academic scheduling with constraint satisfaction, equitable workload leveling,
and inter-departmental faculty resource sharing.
"""

__version__ = "2.0.0"
__author__ = "Desai Aryan M."
__enrollment__ = "12402080601009"
__institution__ = "A D Patel Institute of Technology (ADIT) | The CVM University"

from .config import DAYS, PERIODS, DEPARTMENTS, SEMESTERS
from .models import Faculty, Course, Room, PeriodEntry, Timetable, FacultyWorkload
from .database import get_all_departments, get_department_faculty, get_curriculum, get_rooms
from .csp_solver import TimetableSolver
from .server import start_server

__all__ = [
    "DAYS",
    "PERIODS",
    "DEPARTMENTS",
    "SEMESTERS",
    "Faculty",
    "Course",
    "Room",
    "PeriodEntry",
    "Timetable",
    "FacultyWorkload",
    "get_all_departments",
    "get_department_faculty",
    "get_curriculum",
    "get_rooms",
    "TimetableSolver",
    "start_server",
]
