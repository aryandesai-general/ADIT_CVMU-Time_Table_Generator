"""
Configuration module for ADIT AI Timetable Maker System.
Defines institutional constants, time slots, sharing rules, and capacity limits.
"""

# Academic Cycle: Monday to Friday (Saturday & Sunday are strict holidays)
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
ALL_DAYS_WITH_HOLIDAY = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

# Standard 6-period daily schedule with lunch and tea breaks
PERIODS = [
    {"slot": 1, "time": "10:30 - 11:30 AM", "type": "LECTURE"},
    {"slot": 2, "time": "11:30 - 12:30 PM", "type": "LECTURE"},
    {"slot": "LUNCH", "time": "12:30 - 01:15 PM", "type": "RECESS"},
    {"slot": 3, "time": "01:15 - 02:15 PM", "type": "LECTURE_OR_LAB"},
    {"slot": 4, "time": "02:15 - 03:15 PM", "type": "LECTURE_OR_LAB"},
    {"slot": 5, "time": "03:30 - 04:30 PM", "type": "LECTURE_OR_LAB"},
    {"slot": 6, "time": "04:30 - 05:30 PM", "type": "LECTURE_OR_LAB"},
]

# Teaching period slot numbers (excluding lunch)
ACTIVE_SLOT_INDICES = [1, 2, 3, 4, 5, 6]

# Institutional Capacity Rules (Nominal 80, Valid up to 90 students per class)
CLASSROOM_CAPACITY = 80          # Nominal capacity per division
CLASSROOM_MAX_CAPACITY = 90      # Valid extended capacity limit per division
LAB_CAPACITY = 45                # Department dedicated (2 batches)
BATCH_CAPACITY = 22              # 4 batches per division (~20-22 students)

# Academic Course Constraints
LECTURES_PER_THEORY_COURSE = 3  # Exactly 3 lectures per week per theory course
LABS_PER_PRACTICAL_COURSE = 1   # Exactly 1 lab per week per practical course (2-hour block)

# Inter-Departmental Faculty Sharing Map
# IT shares with AI&DS, CE shares with CSD
FACULTY_SHARING_MAP = {
    "IT": "AIDS",
    "AIDS": "IT",
    "CE": "CSD",
    "CSD": "CE",
}

# Faculty Teaching Load Bounds (Hours per week)
TARGET_WORKLOAD_MIN = 12
TARGET_WORKLOAD_MAX = 15

# Head of Department (HOD) Administrative Teaching Relief:
# HODs carry institutional, accreditation, and department administration, so their teaching workload
# is capped at 6 - 8 hours/week (strictly less than regular faculty who teach 12 - 16 hours/week).
HOD_WORKLOAD_MIN = 3
HOD_WORKLOAD_MAX = 8

# Supported Engineering Departments
DEPARTMENTS = ["CE", "IT", "CSD", "AIDS", "ME", "CL", "EE", "CH"]

# Supported Semesters
SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8]
DEFAULT_SEMESTER = 5
