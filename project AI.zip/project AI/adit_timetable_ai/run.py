#!/usr/bin/env python3
"""
Simple runner script to launch the ADIT AI Timetable Web App & REST API.
Usage:
    python3 run.py           # Launches web app at http://localhost:8000
    python3 run.py --test    # Runs verification tests
    python3 run.py --generate --dept CE --sem 5
"""

import sys
import os

# Ensure package root is in Python module search path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from adit_timetable_ai.main import main

if __name__ == "__main__":
    main()
