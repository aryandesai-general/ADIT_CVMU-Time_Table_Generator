"""
Data models and structure definitions for the ADIT AI Timetable Generator.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any


@dataclass
class Faculty:
    code: str
    name: str
    dept: str
    designation: str
    experience: str
    qualification: str
    skills: str
    priorities: List[str] = field(default_factory=list)
    photo: str = ""
    localPhoto: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Course:
    code: str
    name: str
    short: str
    l: int
    t: int
    p: int
    c: int
    category: str
    faculty_code: str
    lab_type: str = "Computer"
    is_high_credit: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Room:
    no: str
    name: str
    type: str  # "Classroom", "Computer Lab", "Core Lab", etc.
    capacity: int
    dept: str
    is_classroom: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PeriodEntry:
    day: str
    slot: int
    time: str
    activity: str  # "THEORY", "LAB", "FREE", "LIBRARY"
    subject_code: str
    subject_name: str
    faculty_code: str
    faculty_name: str
    room_no: str
    is_shared_faculty: bool = False
    shared_from_dept: Optional[str] = None
    lab_batches: List[str] = field(default_factory=list)
    lab_room_2: Optional[str] = None
    is_elective: bool = False
    elective_options: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Timetable:
    dept: str
    semester: int
    division: int
    room_no: str
    grid: Dict[str, Dict[int, PeriodEntry]]  # Day -> Slot -> PeriodEntry

    def to_dict(self) -> Dict[str, Any]:
        res = {
            "dept": self.dept,
            "semester": self.semester,
            "division": self.division,
            "room_no": self.room_no,
            "grid": {}
        }
        for day, slots in self.grid.items():
            res["grid"][day] = {str(s): entry.to_dict() for s, entry in slots.items()}
        return res


@dataclass
class FacultyWorkload:
    code: str
    name: str
    dept: str
    designation: str
    theory_hours: int = 0
    lab_hours: int = 0
    total_hours: int = 0
    assigned_subjects: List[str] = field(default_factory=list)
    status: str = "Balanced"  # "Perfect", "Balanced", "Under Assigned", "Over Assigned"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
