#!/usr/bin/env python3
import re
import sys

with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update top header: Add ADIT logo at the end of the college name, and remove the web info below it
old_header_brand = """      <div class="flex items-center space-x-3">
        <div class="w-9 h-9 rounded-lg bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center p-1">
          <img id="header-cvm-logo" src="assets/cvm_logo.jpg" alt="CVM" class="max-h-7 object-contain">
        </div>
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-sm sm:text-base font-bold tracking-tight text-white">A D PATEL INSTITUTE OF TECHNOLOGY (ADIT)</h1>
            <span class="bg-blue-500/20 text-blue-300 text-[10px] font-semibold px-2 py-0.5 rounded border border-blue-400/30">CVM University</span>
          </div>
          <p class="text-[11px] text-slate-400">Official Academic Scheduling Portal • Capacity: 80–90/Class • 20–23/Batch • 2 Batches/Lab • 3 Lec/Wk • Sat Holiday</p>
        </div>
      </div>"""

new_header_brand = """      <div class="flex items-center space-x-3">
        <div class="w-9 h-9 rounded-lg bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center p-1">
          <img id="header-cvm-logo" src="assets/cvm_logo.jpg" alt="CVM" class="max-h-7 object-contain">
        </div>
        <div class="flex items-center gap-2.5 flex-wrap">
          <h1 class="text-sm sm:text-base font-extrabold tracking-tight text-white flex items-center gap-2.5">
            <span>A D PATEL INSTITUTE OF TECHNOLOGY (ADIT)</span>
            <img id="header-adit-logo" src="assets/adit_logo.webp" alt="ADIT" class="h-8 w-auto object-contain rounded bg-white p-0.5 shadow-xs border border-white/20">
          </h1>
          <span class="bg-blue-500/20 text-blue-300 text-[10px] font-semibold px-2 py-0.5 rounded border border-blue-400/30">CVM University</span>
        </div>
      </div>"""

if old_header_brand in text:
    text = text.replace(old_header_brand, new_header_brand)
    print("✓ Updated top header: Added ADIT logo at end of college name and removed web info below it!")
else:
    print("Warning: old_header_brand not found")

# 2. Update initApp to ensure header-adit-logo gets the logo image
old_logo_init = """      if (window.ADIT_LOGOS) {
        if (window.ADIT_LOGOS.cvm) {
          const cvmEl = document.getElementById('logo-cvm-left');
          const headCvmEl = document.getElementById('header-cvm-logo');
          if (cvmEl) cvmEl.src = window.ADIT_LOGOS.cvm;
          if (headCvmEl) headCvmEl.src = window.ADIT_LOGOS.cvm;
        }
        if (window.ADIT_LOGOS.adit) {
          const aditEl = document.getElementById('logo-adit-right');
          if (aditEl) aditEl.src = window.ADIT_LOGOS.adit;
        }
      }"""

new_logo_init = """      const cvmSrc = window.CVM_LOGO || (window.ADIT_LOGOS && window.ADIT_LOGOS.cvm);
      if (cvmSrc) {
        const cvmEl = document.getElementById('logo-cvm-left');
        const headCvmEl = document.getElementById('header-cvm-logo');
        if (cvmEl) cvmEl.src = cvmSrc;
        if (headCvmEl) headCvmEl.src = cvmSrc;
      }
      const aditSrc = window.ADIT_LOGO || (window.ADIT_LOGOS && window.ADIT_LOGOS.adit);
      if (aditSrc) {
        const aditEl = document.getElementById('logo-adit-right');
        const headAditEl = document.getElementById('header-adit-logo');
        if (aditEl) aditEl.src = aditSrc;
        if (headAditEl) headAditEl.src = aditSrc;
      }"""

if old_logo_init in text:
    text = text.replace(old_logo_init, new_logo_init)
    print("✓ Updated logo initialization for header-adit-logo!")
else:
    print("Warning: old_logo_init not found")

# 3. Remove all 7 duplicate faculty entries
# The 7 duplicates:
# 1. DKS_CSD (Dr. Dheeraj Kumar Singh, already in CE as DKS)
# 2. CBJ_CSD (Prof. Chinmay Joshi, already in CE as CBJ)
# 3. AJK_CSD (Prof. Axit Kachhia, already in CE as AJK)
# 4. DJP_AI (Dr. Dinesh Prajapati, already in IT as DJP)
# 5. SNG_AI (Dr. Shital Gondaliya, already in IT as SNG)
# 6. TRR_AI (Prof. Tejas Rana, already in CE as TRR)
# 7. BWP_CH (Dr. Biswadeep Pal, already in CL as BWP)

to_remove = ['DKS_CSD', 'CBJ_CSD', 'AJK_CSD', 'DJP_AI', 'SNG_AI', 'TRR_AI', 'BWP_CH']

removed_count = 0
for code in to_remove:
    # Pattern to match the faculty object including preceding/trailing comma
    pattern = re.compile(r',\s*\{\s*code:\s*\"' + code + r'\"[\s\S]*?priorities:\s*\[[^\]]*\]\s*\}')
    text, n = pattern.subn('', text)
    if n > 0:
        removed_count += n
        print(f"✓ Removed duplicate faculty entry: {code}")
    else:
        # Try without leading comma
        pattern2 = re.compile(r'\{\s*code:\s*\"' + code + r'\"[\s\S]*?priorities:\s*\[[^\]]*\]\s*\}\s*,?')
        text, n2 = pattern2.subn('', text)
        if n2 > 0:
            removed_count += n2
            print(f"✓ Removed duplicate faculty entry: {code}")
        else:
            print(f"Warning: could not find duplicate code {code}")

print(f"Total duplicates removed: {removed_count}")

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print("SUCCESS: index.html updated successfully!")
