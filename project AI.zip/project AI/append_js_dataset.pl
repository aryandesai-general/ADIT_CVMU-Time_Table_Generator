use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

print $out <<'JS_START';

  <!-- ==================================================== -->
  <!-- JAVASCRIPT MASTER SYSTEM LOGIC                       -->
  <!-- ==================================================== -->
  <script>
    // Master ADIT Institutional Dataset (adit.ac.in)
    const ADIT_PORTAL_DATA = {
      // 1. Campus Facilities: Classrooms (80 Cap) & Specialized Labs (40 Cap / 2 Batches)
      rooms: [
        // Classrooms (Capacity 80 students = 1 full division)
        { roomNo: "213", type: "Classroom", capacity: 80, dept: "CE", buildingFloor: "Main Bldg - 2nd Floor", features: "Smart Projector, Audio System, AC" },
        { roomNo: "214", type: "Classroom", capacity: 80, dept: "CE", buildingFloor: "Main Bldg - 2nd Floor", features: "Smart Board, High-Lumen Projector" },
        { roomNo: "314", type: "Classroom", capacity: 80, dept: "CE", buildingFloor: "Main Bldg - 3rd Floor", features: "Tiered Seating, Smart Display" },
        { roomNo: "209", type: "Classroom", capacity: 80, dept: "IT", buildingFloor: "IT Block - 2nd Floor", features: "Interactive Whiteboard, AC" },
        { roomNo: "210", type: "Classroom", capacity: 80, dept: "IT", buildingFloor: "IT Block - 2nd Floor", features: "Digital Podium, Dual Displays" },
        { roomNo: "320", type: "Classroom", capacity: 80, dept: "CSD", buildingFloor: "Design Wing - 3rd Floor", features: "Design Studio Setup, 4K Display" },
        { roomNo: "218", type: "Classroom", capacity: 80, dept: "AIDS", buildingFloor: "AI Wing - 2nd Floor", features: "Smart Interactive Screen, High-Speed LAN" },
        { roomNo: "101", type: "Classroom", capacity: 80, dept: "ME", buildingFloor: "Mech Block - 1st Floor", features: "Acoustic Panels, Projection Screen" },
        { roomNo: "105", type: "Classroom", capacity: 80, dept: "CH", buildingFloor: "Chem Block - 1st Floor", features: "Smart Display, Ventilation" },
        { roomNo: "201", type: "Classroom", capacity: 80, dept: "EE", buildingFloor: "EE Block - 2nd Floor", features: "Digital Projector, AC" },
        { roomNo: "301", type: "Classroom", capacity: 80, dept: "CL", buildingFloor: "Civil Block - 3rd Floor", features: "Drafting Tables, Overhead Display" },
        { roomNo: "215", type: "Classroom", capacity: 80, dept: "Shared", buildingFloor: "Main Bldg - 2nd Floor", features: "Multi-purpose Lecture Hall" },
        { roomNo: "312", type: "Classroom", capacity: 80, dept: "Shared", buildingFloor: "Main Bldg - 3rd Floor", features: "Audio-Visual Seminar Setup" },
        { roomNo: "313", type: "Classroom", capacity: 80, dept: "Shared", buildingFloor: "Main Bldg - 3rd Floor", features: "High Capacity Lecture Theatre" },

        // Specialized Laboratories (Capacity 40 students = 2 batches)
        { roomNo: "CE-3 Lab", type: "Computer-Lab", capacity: 40, dept: "CE", buildingFloor: "Main Bldg - 2nd Floor", features: "40 Intel Core i7 Systems, Ubuntu/Win Dual Boot" },
        { roomNo: "CE-4 Lab", type: "Computer-Lab", capacity: 40, dept: "CE", buildingFloor: "Main Bldg - 2nd Floor", features: "40 Systems, Cisco Networking Racks" },
        { roomNo: "CE-5 Lab", type: "Computer-Lab", capacity: 40, dept: "CE", buildingFloor: "Main Bldg - 3rd Floor", features: "40 Systems, Algorithm Simulation Suite" },
        { roomNo: "CE-6 Lab", type: "Computer-Lab", capacity: 40, dept: "CE", buildingFloor: "Main Bldg - 3rd Floor", features: "40 Systems, Full Stack Web Dev Environment" },
        { roomNo: "IT-3 Lab", type: "Computer-Lab", capacity: 40, dept: "IT", buildingFloor: "IT Block - 2nd Floor", features: "40 Dell OptiPlex Systems, Oracle DBMS" },
        { roomNo: "IT-4 Lab", type: "Computer-Lab", capacity: 40, dept: "IT", buildingFloor: "IT Block - 2nd Floor", features: "40 Systems, Python & Data Science Rigs" },
        { roomNo: "IT-5 Lab", type: "Computer-Lab", capacity: 40, dept: "IT", buildingFloor: "IT Block - 3rd Floor", features: "40 Systems, Cloud & DevOps Simulation" },
        { roomNo: "IT-6 Lab", type: "Computer-Lab", capacity: 40, dept: "IT", buildingFloor: "IT Block - 3rd Floor", features: "40 Systems, Cyber Security & Forensics" },
        { roomNo: "Lab 331-A", type: "Computer-Lab", capacity: 40, dept: "IT", buildingFloor: "IT Block - 3rd Floor", features: "40 High-End Workstations, ML Frameworks" },
        { roomNo: "AI-1 Lab", type: "Computer-Lab", capacity: 40, dept: "AIDS", buildingFloor: "AI Wing - 2nd Floor", features: "NVIDIA GPU Workstations, Deep Learning Suite" },
        { roomNo: "AI-2 Lab", type: "Computer-Lab", capacity: 40, dept: "AIDS", buildingFloor: "AI Wing - 2nd Floor", features: "High Performance Compute Nodes, Big Data Spark" },
        { roomNo: "CAD-CAM Lab", type: "Core-Lab", capacity: 40, dept: "ME", buildingFloor: "Mech Block - Ground Floor", features: "AutoCAD, SolidWorks, CNC Simulators" },
        { roomNo: "Thermo Lab", type: "Core-Lab", capacity: 40, dept: "ME", buildingFloor: "Mech Block - Ground Floor", features: "Steam Turbine, Heat Exchanger Test Rigs" },
        { roomNo: "Reaction Lab", type: "Core-Lab", capacity: 40, dept: "CH", buildingFloor: "Chem Block - Ground Floor", features: "Batch & CSTR Reactors, Distillation Units" },
        { roomNo: "Mass Transfer Lab", type: "Core-Lab", capacity: 40, dept: "CH", buildingFloor: "Chem Block - 1st Floor", features: "Absorption Towers, Liquid Extraction Rigs" },
        { roomNo: "Machines Lab", type: "Core-Lab", capacity: 40, dept: "EE", buildingFloor: "EE Block - Ground Floor", features: "AC/DC Motor-Generator Sets, Transformers" },
        { roomNo: "Power System Lab", type: "Core-Lab", capacity: 40, dept: "EE", buildingFloor: "EE Block - 1st Floor", features: "Transmission Line Simulators, Relays" },
        { roomNo: "Structure Lab", type: "Core-Lab", capacity: 40, dept: "CL", buildingFloor: "Civil Block - Ground Floor", features: "Universal Testing Machine (UTM), Compression Rig" },
        { roomNo: "Geotech Lab", type: "Core-Lab", capacity: 40, dept: "CL", buildingFloor: "Civil Block - Ground Floor", features: "Direct Shear Apparatus, Triaxial Test Setup" },
        { roomNo: "Mech Workshop", type: "Workshop", capacity: 80, dept: "ME", buildingFloor: "Workshop Annex - Ground Floor", features: "Lathe Machines, Welding, Carpentry, Fitting" },
        { roomNo: "Physics Lab", type: "Core-Lab", capacity: 40, dept: "Shared", buildingFloor: "Science Block - 1st Floor", features: "Optics Spectrometers, Laser & Hall Effect" },
        { roomNo: "Chemistry Lab", type: "Core-Lab", capacity: 40, dept: "Shared", buildingFloor: "Science Block - 1st Floor", features: "Fume Hoods, Analytical Instruments" }
      ],

      // 2. All Departments of ADIT College with Program Codes & Student Intakes
      departments: [
        {
          code: "CE",
          name: "Computer Engineering",
          progCode: "04",
          facCode: "02",
          studentIntake: 240, // 3 divisions of 80 students!
          defaultRooms: ["213", "214", "314"],
          labPrefix: "CE",
          labs: ["CE-3 Lab", "CE-4 Lab", "CE-5 Lab", "CE-6 Lab"]
        },
        {
          code: "IT",
          name: "Information Technology",
          progCode: "08",
          facCode: "0208",
          studentIntake: 160, // 2 divisions of 80 students!
          defaultRooms: ["209", "210"],
          labPrefix: "IT",
          labs: ["IT-3 Lab", "IT-4 Lab", "IT-5 Lab", "IT-6 Lab", "Lab 331-A"]
        },
        {
          code: "CSD",
          name: "Computer Science & Design",
          progCode: "13",
          facCode: "02",
          studentIntake: 80, // 1 division of 80 students!
          defaultRooms: ["320"],
          labPrefix: "CE",
          labs: ["CE-4 Lab", "CE-5 Lab", "CE-6 Lab"]
        },
        {
          code: "AIDS",
          name: "Artificial Intelligence & Data Science",
          progCode: "16",
          facCode: "02",
          studentIntake: 80, // 1 division of 80 students!
          defaultRooms: ["218"],
          labPrefix: "AI",
          labs: ["AI-1 Lab", "AI-2 Lab", "IT-3 Lab"]
        },
        {
          code: "ME",
          name: "Mechanical Engineering",
          progCode: "02",
          facCode: "02",
          studentIntake: 80,
          defaultRooms: ["101"],
          labPrefix: "ME",
          labs: ["Thermo Lab", "CAD-CAM Lab", "Mech Workshop"]
        },
        {
          code: "CL",
          name: "Civil Engineering",
          progCode: "06",
          facCode: "02",
          studentIntake: 80,
          defaultRooms: ["301"],
          labPrefix: "CL",
          labs: ["Structure Lab", "Geotech Lab"]
        },
        {
          code: "EE",
          name: "Electrical Engineering",
          progCode: "09",
          facCode: "02",
          studentIntake: 80,
          defaultRooms: ["201"],
          labPrefix: "EE",
          labs: ["Machines Lab", "Power System Lab"]
        },
        {
          code: "CH",
          name: "Chemical Engineering",
          progCode: "05",
          facCode: "02",
          studentIntake: 80,
          defaultRooms: ["105"],
          labPrefix: "CH",
          labs: ["Reaction Lab", "Mass Transfer Lab"]
        }
      ],

      // 3. Time Slots (9:05am to 5:00pm) with 45-minute LUNCH BREAK (12:40 to 1:25pm)
      timeSlots: [
        { time: "9:05 to 9:55am", id: "T1", isBreak: false },
        { time: "10:00 to 10:50am", id: "T2", isBreak: false },
        { time: "10:55 to 11:45am", id: "T3", isBreak: false },
        { time: "11:50 to 12:40pm", id: "T4", isBreak: false },
        { time: "12:40 to 1:25pm", id: "LUNCH", isBreak: true, label: "LUNCH BREAK" },
        { time: "1:25 to 2:15pm", id: "T5", isBreak: false },
        { time: "2:20 to 3:10pm", id: "T6", isBreak: false },
        { time: "3:15 to 4:05pm", id: "T7", isBreak: false },
        { time: "4:10 to 5:00pm", id: "T8", isBreak: false }
      ],

      // Timetable days: Monday to Friday (Saturday Holiday)
      days: ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY"],
JS_START

# Read and append curriculums block from update_curriculum.pl
my $source = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/update_curriculum.pl";
open my $src_fh, '<:utf8', $source or die "Cannot open $source: $!";
my $src_content = do { local $/; <$src_fh> };
close $src_fh;

if ($src_content =~ /(curriculums:\s*\{[\s\S]*?\n\s*\},)/) {
    my $curr_block = $1;
    print $out "\n      $curr_block\n";
    print "Curriculums block appended.\n";
} else {
    die "Could not extract curriculums";
}

close $out;
