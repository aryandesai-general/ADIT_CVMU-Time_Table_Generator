#!/usr/bin/env python3
import re
import json

html_path = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html"
with open(html_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

recording = False
js_lines = []
for line in lines:
    if "const ADIT_PORTAL_DATA =" in line:
        recording = True
        js_lines.append(line.split("const ADIT_PORTAL_DATA =", 1)[1])
        continue
    if recording:
        if line.strip() == "};":
            js_lines.append("}\n")
            recording = False
            break
        js_lines.append(line)

raw_text = "".join(js_lines)

# Strip single line comments: // ...
def strip_comments(text):
    # Regex to strip // comments but not inside strings
    out = []
    for line in text.splitlines():
        in_str = False
        str_char = None
        cleaned = []
        i = 0
        while i < len(line):
            ch = line[i]
            if not in_str:
                if ch in ('"', "'"):
                    in_str = True
                    str_char = ch
                    cleaned.append(ch)
                elif ch == '/' and i + 1 < len(line) and line[i+1] == '/':
                    break # rest of line is comment
                else:
                    cleaned.append(ch)
            else:
                if ch == '\\':
                    cleaned.append(ch)
                    if i + 1 < len(line):
                        i += 1
                        cleaned.append(line[i])
                elif ch == str_char:
                    in_str = False
                    cleaned.append(ch)
                else:
                    cleaned.append(ch)
            i += 1
        out.append("".join(cleaned))
    return "\n".join(out)

cleaned_text = strip_comments(raw_text)

# Quote unquoted keys: e.g.   rooms: [ -> "rooms": [
# A key is word characters followed by optional spaces and a colon
def quote_keys(text):
    # Replace unquoted keys with quoted keys
    # Pattern: (?<=[{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:
    return re.sub(r'([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:', r'\1"\2":', text)

json_like = quote_keys(cleaned_text)

# Also fix trailing commas before } or ]
json_like = re.sub(r',\s*([}\]])', r'\1', json_like)

# Replace JS booleans / null with Python
py_text = json_like
py_text = re.sub(r'\btrue\b', 'True', py_text)
py_text = re.sub(r'\bfalse\b', 'False', py_text)
py_text = re.sub(r'\bnull\b', 'None', py_text)

# Verify if py_text evaluates as python dict
try:
    data = eval(py_text)
    print("Successfully parsed ADIT_PORTAL_DATA! Keys:", list(data.keys()))
    print("Rooms count:", len(data.get("rooms", [])))
    print("Depts count:", len(data.get("departments", [])))
    print("Faculty count:", len(data.get("faculty", [])))
except Exception as e:
    print("Eval error:", e)
    # Print near error line if possible
    sys.exit(1)

# Write out clean database.py
db_path = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai/database.py"
with open(db_path, "w", encoding="utf-8") as f:
    f.write('"""\nADIT Academic Database Module\nContains normalized faculty, curriculum, room, and department data from adit.ac.in.\n"""\n\n')
    f.write(f"ADIT_PORTAL_DATA = {repr(data)}\n\n")
    f.write('''def get_all_departments():
    """Return list of all 8 engineering departments."""
    return ADIT_PORTAL_DATA["departments"]


def get_rooms():
    """Return all classrooms (common) and discipline-dedicated laboratories."""
    return ADIT_PORTAL_DATA["rooms"]


def get_all_faculty():
    """Return list of all faculty members."""
    return ADIT_PORTAL_DATA["faculty"]


def get_department_faculty(dept_code: str):
    """
    Return faculty for a department, applying inter-departmental sharing:
    - Information Technology (IT) shares faculty pool with AI & DS (AIDS)
    - Computer Engineering (CE) shares faculty pool with CS & Design (CSD)
    """
    if dept_code in ("IT", "AIDS"):
        return [f for f in ADIT_PORTAL_DATA["faculty"] if f["dept"] in ("IT", "AIDS")]
    elif dept_code in ("CE", "CSD"):
        return [f for f in ADIT_PORTAL_DATA["faculty"] if f["dept"] in ("CE", "CSD")]
    else:
        dept_faculty = [f for f in ADIT_PORTAL_DATA["faculty"] if f["dept"] == dept_code]
        return dept_faculty if len(dept_faculty) >= 2 else ADIT_PORTAL_DATA["faculty"]


def get_curriculum(dept_code: str, sem: int = 5):
    """Return curriculum course list for a given department and semester."""
    key = f"{dept_code}_{sem}"
    fallback = f"{dept_code}_5"
    return (
        ADIT_PORTAL_DATA["curriculums"].get(key)
        or ADIT_PORTAL_DATA["curriculums"].get(fallback)
        or ADIT_PORTAL_DATA["curriculums"]["CE_5"]
    )
''')

print("Updated adit_timetable_ai/database.py successfully!")
