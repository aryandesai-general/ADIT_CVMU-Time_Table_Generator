#!/usr/bin/env python3
import sys

with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add isHeadOfDepartment helper function
hod_func = """    function isHeadOfDepartment(f) {
      if (!f) return false;
      const d = (f.designation || '').toLowerCase();
      return d.includes('head') || d.includes('hod') || d.includes('principal');
    }"""

if 'function isHeadOfDepartment' not in text:
    text = text.replace('function getFacultyByCode(code) {', hod_func + '\n\n    function getFacultyByCode(code) {')
    print("Added isHeadOfDepartment helper function.")

# 2. Update theory assignment in generateAllSchedules
old_theory_scoring = """            // Equal workload penalty across all assigned classes!
            const currentLoad = globalFacultyWorkload[fac.code].totalHours;
            score -= (currentLoad * 18);"""

new_theory_scoring = """            // Equal workload penalty across all assigned classes!
            const currentLoad = globalFacultyWorkload[fac.code].totalHours;
            const isHod = isHeadOfDepartment(fac);

            // Head of Department (HoD) Reduced Workload Rule:
            // HoDs carry institutional, departmental, and accreditation (NBA/NAAC) administration.
            // Teaching load is capped at 3 to 6 hours/week (max 8h), strictly less than regular faculty (12-16h)!
            if (isHod) {
              if (currentLoad >= 6) {
                score -= 3500; // Strict cut-off: Prevent assigning beyond 6-8 hours to HoD
              } else {
                score -= 75;   // Bias toward regular professors and assistant professors first
              }
            } else {
              score -= (currentLoad * 18);
            }"""

if old_theory_scoring in text:
    text = text.replace(old_theory_scoring, new_theory_scoring)
    print("Updated theory scoring with HoD reduced workload rule.")
else:
    print("Warning: old_theory_scoring not found.")

# 3. Update lab assignment to protect HoD from lab batches
old_lab_assign = """            // Assign lab faculty from shared pool without collisions
            let fac1 = facultyAllotmentMap[labSub.code] || activeFacultyPool.find(f => !bookedFaculty[d][s1].has(f.code) && !bookedFaculty[d][s2].has(f.code)) || activeFacultyPool[0];
            let fac2 = activeFacultyPool.find(f => f.code !== fac1.code && !bookedFaculty[d][s1].has(f.code) && !bookedFaculty[d][s2].has(f.code)) || activeFacultyPool[1] || fac1;"""

new_lab_assign = """            // Assign lab faculty from shared pool: Protect HoD from heavy lab sessions so they teach less than regular faculty!
            const nonHodPool = activeFacultyPool.filter(f => !isHeadOfDepartment(f));
            const availableNonHod1 = nonHodPool.find(f => !bookedFaculty[d][s1].has(f.code) && !bookedFaculty[d][s2].has(f.code));
            let fac1 = availableNonHod1 || (!isHeadOfDepartment(facultyAllotmentMap[labSub.code]) ? facultyAllotmentMap[labSub.code] : null) || activeFacultyPool.find(f => !bookedFaculty[d][s1].has(f.code) && !bookedFaculty[d][s2].has(f.code)) || activeFacultyPool[0];

            const availableNonHod2 = nonHodPool.find(f => f.code !== fac1.code && !bookedFaculty[d][s1].has(f.code) && !bookedFaculty[d][s2].has(f.code));
            let fac2 = availableNonHod2 || activeFacultyPool.find(f => f.code !== fac1.code && !bookedFaculty[d][s1].has(f.code) && !bookedFaculty[d][s2].has(f.code)) || activeFacultyPool[1] || fac1;"""

if old_lab_assign in text:
    text = text.replace(old_lab_assign, new_lab_assign)
    print("Updated lab assignment with HoD protection.")
else:
    print("Warning: old_lab_assign not found.")

# 4. Update Section 5 Workload Dashboard status badge for HoD
old_badge = """        let statusBadge = `<span class="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded font-bold">✅ Perfectly Balanced</span>`;
        if (stats.totalHours < 9) {
          statusBadge = `<span class="bg-blue-100 text-blue-800 border border-blue-300 px-2 py-0.5 rounded font-medium">Under Assigned</span>`;
        }"""

new_badge = """        const isHod = isHeadOfDepartment(f);
        let statusBadge = `<span class="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded font-bold">✅ Perfectly Balanced (12-16h)</span>`;
        if (isHod) {
          if (stats.totalHours <= 8) {
            statusBadge = `<span class="bg-purple-100 text-purple-900 border border-purple-300 px-2 py-0.5 rounded font-bold" title="Reduced teaching load allocated per AICTE/University HoD administration norms">🎖️ Optimal HoD Quota (3-8h Admin Quota)</span>`;
          } else {
            statusBadge = `<span class="bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded font-bold">⚠️ Exceeds HoD Quota</span>`;
          }
        } else {
          if (stats.totalHours < 12) {
            statusBadge = `<span class="bg-blue-100 text-blue-800 border border-blue-300 px-2 py-0.5 rounded font-medium">Under Assigned (<12h)</span>`;
          } else if (stats.totalHours > 16) {
            statusBadge = `<span class="bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded font-medium">Heavy Workload (>16h)</span>`;
          }
        }"""

if old_badge in text:
    text = text.replace(old_badge, new_badge)
    print("Updated status badge for HoD in workload dashboard.")
else:
    print("Warning: old_badge not found.")

# 5. Add HoD rule badge to Section 1 Institutional Constraints banner
banner_anchor = '<span class="bg-purple-50 text-purple-800 border border-purple-200 px-2 py-1 rounded-md text-[11px] font-bold">🧪 Distinct Lab Timing Rules</span>'
hod_banner_pill = '<span class="bg-rose-50 text-rose-800 border border-rose-200 px-2 py-1 rounded-md text-[11px] font-bold">👔 HoD Reduced Workload: 3–8 hrs/wk (Admin Relief)</span>\n              ' + banner_anchor

if banner_anchor in text and 'HoD Reduced Workload' not in text:
    text = text.replace(banner_anchor, hod_banner_pill)
    print("Added HoD Reduced Workload pill to top header banner.")

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print("SUCCESS: index.html fully updated with HoD reduced workload rule!")
