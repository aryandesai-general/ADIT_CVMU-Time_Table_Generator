"""
Script to test equal distribution of subjects and workload for all 55 faculty members.
"""
import json

from adit_timetable_ai.database import ADIT_PORTAL_DATA

faculty_list = ADIT_PORTAL_DATA['faculty']
print(f"Total faculty in DB: {len(faculty_list)}")

# Subject mappings for semester 5 to guarantee 100% faculty coverage:
CE_5_SUBJECTS = [
    {"code": "202045601", "name": "Design and Analysis of Algorithms", "short": "DAA", "category": "PCC", "l": 4, "t": 0, "p": 2, "c": 5, "isHighCredit": True, "labType": "CE", "facultyCode": "DKS"},
    {"code": "202044501", "name": "Computer Networks", "short": "CN", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "PKT"},
    {"code": "202045603", "name": "Python for Data Science", "short": "PDS", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "TRR"},
    {"code": "202044505", "name": "Web Development", "short": "WD", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "KSP"},
    {"code": "202045606", "name": "Computer Graphics - PE1", "short": "CG", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "JVP_CE"},
    {"code": "202045605", "name": "Advanced Java Programming - PE1", "short": "AJP", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "AW"},
    {"code": "202045610", "name": "Distributed Computing & Cloud - PE1", "short": "DC", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "MB"},
    {"code": "202045611", "name": "Software Testing & QA - PE1", "short": "STQA", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "AJK"},
    {"code": "202045612", "name": "Cyber Security Principles - PE1", "short": "CS", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "SJM"},
    {"code": "202045613", "name": "Advanced Algorithm Lab & Analysis", "short": "ALGO", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "PT"},
    {"code": "202045614", "name": "Python & Web Architecture", "short": "PWP", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "AKK"},
    {"code": "202045615", "name": "Database Management & Systems", "short": "DBMS", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "IT"},
    {"code": "202045616", "name": "Computer Graphics & Multimedia Design", "short": "CGD", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "CBJ"},
    {"code": "202045699", "name": "Open Elective (Disaster Management & Remote Sensing)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "DM"}
]

IT_5_SUBJECTS = [
    {"code": "202045601", "name": "Design and Analysis of Algorithms", "short": "DAA", "category": "PCC", "l": 4, "t": 0, "p": 2, "c": 5, "isHighCredit": True, "labType": "IT", "facultyCode": "MAP"},
    {"code": "202045602", "name": "Software Engineering", "short": "SE", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "ANP"},
    {"code": "202044504", "name": "Programming with Python", "short": "PWP", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "HMP"},
    {"code": "202044505", "name": "Web Development", "short": "WD", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "SNG"},
    {"code": "202044503", "name": "Artificial Intelligence (PE1)", "short": "AI", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "IT", "facultyCode": "DJP"},
    {"code": "202045605", "name": "Advanced Java Programming (PE1)", "short": "AJP", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "IT", "facultyCode": "PRB"},
    {"code": "202045607", "name": "Cyber Security (PE1)", "short": "CS", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "IT", "facultyCode": "HVP"},
    {"code": "202045623", "name": "Natural Language Processing (PE1)", "short": "NLP", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "IT", "facultyCode": "KJP"},
    {"code": "202045624", "name": "Java Programming & Technologies", "short": "JAVA", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "JKP"},
    {"code": "202045625", "name": "Full Stack Application Development", "short": "FSAD", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "AJR"},
    {"code": "202045626", "name": "Object Oriented Programming with C++", "short": "OOP", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "KVP"},
    {"code": "202045627", "name": "Software Project Management & Agile", "short": "SPM", "category": "PCC", "l": 3, "t": 0, "p": 0, "c": 3, "isHighCredit": False, "labType": "Classroom", "facultyCode": "NMM"},
    {"code": "202045628", "name": "Cloud Computing & DevOps Architecture", "short": "CC", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "IT", "facultyCode": "KRP"},
    {"code": "202045698", "name": "Open Elective (Professional Ethics & Technical Practice)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "PMG"}
]

CSD_5_SUBJECTS = [
    {"code": "202045601", "name": "Design and Analysis of Algorithms", "short": "DAA", "category": "PCC", "l": 4, "t": 0, "p": 2, "c": 5, "isHighCredit": True, "labType": "CE", "facultyCode": "MAP"},
    {"code": "202044507", "name": "Computer Architecture & Design", "short": "CAD", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "VVN_CSD"},
    {"code": "202045611", "name": "Computer Graphics & UI/UX Design", "short": "CGD", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "BKM"},
    {"code": "202045612", "name": "Python and Web Programming", "short": "PWP", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "CE", "facultyCode": "AKK"},
    {"code": "202045605", "name": "Advance Java Programming - PE1", "short": "AJP", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "AW"},
    {"code": "202045607", "name": "Cyber Security - PE1", "short": "CS", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CE", "facultyCode": "SJM"},
    {"code": "202045699", "name": "Open Elective (Applied Mathematics & Optimization)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "DM"}
]

AIDS_5_SUBJECTS = [
    {"code": "202045601", "name": "Design and Analysis of Algorithms", "short": "DAA", "category": "PCC", "l": 4, "t": 0, "p": 2, "c": 5, "isHighCredit": True, "labType": "AI", "facultyCode": "MAP"},
    {"code": "202045620", "name": "Machine Learning Concepts & Algorithms", "short": "ML", "category": "PCC", "l": 4, "t": 0, "p": 2, "c": 5, "isHighCredit": True, "labType": "AI", "facultyCode": "SNG"},
    {"code": "202045621", "name": "Deep Learning Foundations (PyTorch/TF)", "short": "DL", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "AI", "facultyCode": "PKG"},
    {"code": "202045622", "name": "Big Data Engineering & Spark", "short": "BDE", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "AI", "facultyCode": "MAP"},
    {"code": "202045623", "name": "Natural Language Processing (PE1)", "short": "NLP", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "AI", "facultyCode": "KJP"},
    {"code": "202045699", "name": "Open Elective (Physics of AI & Quantum Tech)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "SKP"}
]

ME_5_SUBJECTS = [
    {"code": "202015501", "name": "Design of Machine Elements (DME)", "short": "DME", "category": "PCC", "l": 4, "t": 1, "p": 0, "c": 5, "isHighCredit": True, "labType": "CAD", "facultyCode": "VNS"},
    {"code": "202015502", "name": "Dynamics of Machinery (DOM)", "short": "DOM", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Mechanical", "facultyCode": "HBJ"},
    {"code": "202015503", "name": "Heat and Mass Transfer (HMT)", "short": "HMT", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Mechanical", "facultyCode": "YDP"},
    {"code": "202015504", "name": "Internal Combustion Engines (ICE)", "short": "ICE", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Mechanical", "facultyCode": "MIS"},
    {"code": "202015505", "name": "Operations Research (OR)", "short": "OR", "category": "PCC", "l": 3, "t": 1, "p": 0, "c": 4, "isHighCredit": True, "labType": "Classroom", "facultyCode": "MVM"},
    {"code": "202015506", "name": "CAD/CAM & FEA - PE1", "short": "CAD", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "CAD", "facultyCode": "AYJ"},
    {"code": "202015507", "name": "Production Automation & Robotics - PE1", "short": "PAR", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "Mechanical", "facultyCode": "RRS"},
    {"code": "202015508", "name": "Automobile Engineering & EV Tech - PE1", "short": "AUT", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "Mechanical", "facultyCode": "BJS"},
    {"code": "202015599", "name": "Open Elective (Industrial Safety & Ethics)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "PMG"}
]

CL_5_SUBJECTS = [
    {"code": "202055501", "name": "Structural Analysis - II (SA-2)", "short": "SA-2", "category": "PCC", "l": 4, "t": 1, "p": 0, "c": 5, "isHighCredit": True, "labType": "Civil", "facultyCode": "RJB"},
    {"code": "202055502", "name": "Design of Reinforced Concrete Structures (DRCS)", "short": "DRCS", "category": "PCC", "l": 3, "t": 1, "p": 0, "c": 4, "isHighCredit": True, "labType": "CAD", "facultyCode": "DKB"},
    {"code": "202055503", "name": "Geotechnical Engineering - II (Foundations)", "short": "GE-2", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Civil", "facultyCode": "PBV"},
    {"code": "202055504", "name": "Highway & Transportation Engineering", "short": "HTE", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Civil", "facultyCode": "DMY"},
    {"code": "202055505", "name": "Water Resources & Hydrology - PE1", "short": "WRE", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "Civil", "facultyCode": "ASS"},
    {"code": "202055506", "name": "Environmental Engineering - I - PE1", "short": "EE-1", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "Civil", "facultyCode": "CBH"},
    {"code": "202055507", "name": "Concrete Technology & Estimation - PE1", "short": "CT", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "Civil", "facultyCode": "BWP"},
    {"code": "202055599", "name": "Open Elective (GIS & Remote Sensing)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "DM"}
]

EE_5_SUBJECTS = [
    {"code": "202035501", "name": "Power Electronics & Converter Drives", "short": "PE", "category": "PCC", "l": 4, "t": 0, "p": 2, "c": 5, "isHighCredit": True, "labType": "EE", "facultyCode": "KMS"},
    {"code": "202035502", "name": "Power Systems - II (Analysis & Faults)", "short": "PS-2", "category": "PCC", "l": 3, "t": 1, "p": 0, "c": 4, "isHighCredit": True, "labType": "EE", "facultyCode": "KMC"},
    {"code": "202035503", "name": "Microcontrollers & Embedded Systems", "short": "MCES", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "EE", "facultyCode": "VSS"},
    {"code": "202035504", "name": "Electrical Machine Design", "short": "EMD", "category": "PCC", "l": 3, "t": 1, "p": 0, "c": 4, "isHighCredit": True, "labType": "CAD", "facultyCode": "MNJ"},
    {"code": "202035505", "name": "Control Systems Engineering & Automation - PE1", "short": "CS", "category": "PEC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": False, "labType": "EE", "facultyCode": "PRM"},
    {"code": "202035599", "name": "Open Elective (Renewable Energy Integration)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "SKP"}
]

CH_5_SUBJECTS = [
    {"code": "202025501", "name": "Mass Transfer Operations - II (MTO-2)", "short": "MTO-2", "category": "PCC", "l": 4, "t": 1, "p": 0, "c": 5, "isHighCredit": True, "labType": "Chemistry", "facultyCode": "HSP"},
    {"code": "202025502", "name": "Chemical Reaction Engineering - II (CRE-2)", "short": "CRE-2", "category": "PCC", "l": 3, "t": 1, "p": 0, "c": 4, "isHighCredit": True, "labType": "Chemistry", "facultyCode": "HSP"},
    {"code": "202025503", "name": "Instrumentation & Process Control", "short": "IPC", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Chemistry", "facultyCode": "RMS"},
    {"code": "202025504", "name": "Chemical Technology (Inorganic & Organic)", "short": "CT", "category": "PCC", "l": 3, "t": 0, "p": 2, "c": 4, "isHighCredit": True, "labType": "Chemistry", "facultyCode": "RMS"},
    {"code": "202025505", "name": "Transport Phenomena & Modeling - PE1", "short": "TP", "category": "PEC", "l": 3, "t": 1, "p": 0, "c": 4, "isHighCredit": False, "labType": "Classroom", "facultyCode": "KSN"},
    {"code": "202025599", "name": "Open Elective (Industrial Safety & HAZOP)", "short": "OE", "category": "OEC", "l": 2, "t": 0, "p": 0, "c": 2, "isHighCredit": False, "labType": "Classroom", "facultyCode": "PMG"}
]

all_curriculums = {
    "CE_5": CE_5_SUBJECTS,
    "IT_5": IT_5_SUBJECTS,
    "CSD_5": CSD_5_SUBJECTS,
    "AIDS_5": AIDS_5_SUBJECTS,
    "ME_5": ME_5_SUBJECTS,
    "CL_5": CL_5_SUBJECTS,
    "EE_5": EE_5_SUBJECTS,
    "CH_5": CH_5_SUBJECTS
}

assigned_faculty_set = set()
for c_key, subs in all_curriculums.items():
    for s in subs:
        if s.get('facultyCode'):
            assigned_faculty_set.add(s['facultyCode'])

print(f"Total faculty with direct subject allotments in Sem 5: {len(assigned_faculty_set)} out of {len(faculty_list)}")
missing_faculty = [f['code'] for f in faculty_list if f['code'] not in assigned_faculty_set]
print(f"Missing faculty: {missing_faculty}")
