import re

with open("index.html", "r", encoding="utf-8") as f:
    text = f.read()

# Let us verify that index.html runs cleanly in jsc
import subprocess
scripts = re.findall(r"<script>(.*?)</script>", text, re.DOTALL)
mock = """
var window = this;
var document = {
  addEventListener: function() {},
  getElementById: function() { return { innerHTML: "", appendChild: function(){}, textContent: "", value: "CE", querySelectorAll: function(){ return []; }, addEventListener: function(){} }; },
  querySelector: function() { return { click: function(){}, addEventListener: function(){} }; },
  querySelectorAll: function() { return []; }
};
"""
full_js = mock + "\n" + scripts[0] + "\n" + scripts[1]
with open("test_bundle.js", "w", encoding="utf-8") as f:
    f.write(full_js)

res = subprocess.run(["/System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc", "test_bundle.js"], capture_output=True, text=True)
print("JSC Return code:", res.returncode)
if res.returncode != 0:
    print("STDOUT:", res.stdout)
    print("STDERR:", res.stderr)
else:
    print("JavaScriptCore syntax check: PERFECT!")
