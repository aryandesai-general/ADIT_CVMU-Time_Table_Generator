use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

print $out <<'MODALS_V2';

  <!-- ==================================================== -->
  <!-- MODAL: ADD / EDIT ROOM (FULLY EDITABLE!)             -->
  <!-- ==================================================== -->
  <div id="modal-add-room" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 z-50 hidden">
    <div class="bg-white rounded-2xl border border-slate-300 shadow-2xl max-w-md w-full p-5 space-y-4">
      <div class="flex items-center justify-between border-b border-slate-200 pb-2.5">
        <h3 id="modal-room-title" class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
          <span>🏛</span> Add / Configure Campus Facility
        </h3>
        <button id="btn-close-room-modal" class="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">&times;</button>
      </div>

      <input type="hidden" id="m-room-edit-index" value="-1">

      <div class="space-y-3 text-xs">
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Room No / Identifier *</label>
          <input type="text" id="m-room-no" placeholder="e.g. 215 or CE-7 Lab" class="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold">
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Facility Type *</label>
            <select id="m-room-type" class="w-full border border-slate-300 rounded-lg p-2 bg-white">
              <option value="Classroom">Classroom (80 Cap)</option>
              <option value="Computer-Lab">Computer Lab (40 Cap)</option>
              <option value="Core-Lab">Core Engg Lab (40 Cap)</option>
              <option value="Workshop">Workshop / Studio</option>
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Student Capacity *</label>
            <input type="number" id="m-room-capacity" value="80" class="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Department</label>
            <select id="m-room-dept" class="w-full border border-slate-300 rounded-lg p-2 bg-white">
              <option value="CE">Computer Engg</option>
              <option value="IT">Information Tech</option>
              <option value="CSD">CS & Design</option>
              <option value="AIDS">AI & Data Science</option>
              <option value="ME">Mechanical Engg</option>
              <option value="CL">Civil Engg</option>
              <option value="EE">Electrical Engg</option>
              <option value="CH">Chemical Engg</option>
              <option value="Shared">Shared / Central</option>
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Building & Floor</label>
            <input type="text" id="m-room-floor" placeholder="e.g. Main 2nd Floor" class="w-full border border-slate-300 rounded-lg p-2">
          </div>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Equipped Features</label>
          <input type="text" id="m-room-features" placeholder="e.g. Smart Projector, High-Speed LAN, AC" class="w-full border border-slate-300 rounded-lg p-2">
        </div>
      </div>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
        <button id="btn-cancel-room-modal" class="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer">Cancel</button>
        <button id="btn-save-room" class="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs cursor-pointer">Save Facility</button>
      </div>
    </div>
  </div>

  <!-- ==================================================== -->
  <!-- MODAL: ADD / EDIT FACULTY                            -->
  <!-- ==================================================== -->
  <div id="modal-add-faculty" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 z-50 hidden">
    <div class="bg-white rounded-2xl border border-slate-300 shadow-2xl max-w-lg w-full p-5 space-y-4 max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between border-b border-slate-200 pb-2.5">
        <h3 id="modal-faculty-title" class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
          <span>👨‍🏫</span> Configure Faculty Profile & Preferences
        </h3>
        <button id="btn-close-faculty-modal" class="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">&times;</button>
      </div>

      <div class="space-y-3 text-xs">
        <div class="grid grid-cols-3 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Faculty Code *</label>
            <input type="text" id="m-fac-code" placeholder="e.g. MAP" class="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold">
          </div>
          <div class="col-span-2">
            <label class="block font-semibold text-slate-700 mb-1">Full Name with Title *</label>
            <input type="text" id="m-fac-name" placeholder="e.g. Dr. Malay Bhatt" class="w-full border border-slate-300 rounded-lg p-2 font-bold">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Department *</label>
            <select id="m-fac-dept" class="w-full border border-slate-300 rounded-lg p-2 bg-white">
              <!-- Populated via JS -->
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Designation</label>
            <input type="text" id="m-fac-designation" placeholder="e.g. Associate Professor" class="w-full border border-slate-300 rounded-lg p-2">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Experience (Years)</label>
            <input type="text" id="m-fac-experience" placeholder="e.g. 16 Years" class="w-full border border-slate-300 rounded-lg p-2">
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Highest Qualification</label>
            <input type="text" id="m-fac-qualification" placeholder="e.g. Ph.D., M.E., B.E." class="w-full border border-slate-300 rounded-lg p-2">
          </div>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Domain Skills / Field Expertise</label>
          <input type="text" id="m-fac-skills" placeholder="e.g. Algorithms, Data Science, Machine Learning" class="w-full border border-slate-300 rounded-lg p-2">
        </div>

        <!-- 1 to 5 Subject Priorities -->
        <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-bold text-slate-800">Subject Teaching Preferences (Priority 1 to 5)</span>
            <span class="text-[10px] text-indigo-700 font-semibold bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">Only Priority 1 is Mandatory</span>
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-amber-900 mb-0.5">🥇 Priority 1 (Required) *</label>
            <input type="text" id="m-fac-p1" placeholder="e.g. Design and Analysis of Algorithms" class="w-full border border-amber-300 bg-amber-50/50 rounded-lg p-1.5 font-medium">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">🥈 Priority 2 (Optional)</label>
            <input type="text" id="m-fac-p2" placeholder="e.g. Computer Networks" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">🥉 Priority 3 (Optional)</label>
            <input type="text" id="m-fac-p3" placeholder="e.g. Python for Data Science" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">Priority 4 (Optional)</label>
            <input type="text" id="m-fac-p4" placeholder="e.g. Web Development" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">Priority 5 (Optional)</label>
            <input type="text" id="m-fac-p5" placeholder="e.g. Distributed Computing" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>
        </div>
      </div>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
        <button id="btn-cancel-faculty-modal" class="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer">Cancel</button>
        <button id="btn-save-faculty" class="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs cursor-pointer">Save Faculty</button>
      </div>
    </div>
  </div>

  <!-- ==================================================== -->
  <!-- MODAL: TIMETABLE SLOT LIVE EDITOR                    -->
  <!-- ==================================================== -->
  <div id="modal-edit-slot" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 z-50 hidden">
    <div class="bg-white rounded-2xl border border-slate-300 shadow-2xl max-w-lg w-full p-5 space-y-4 max-h-[92vh] overflow-y-auto">
      <div class="flex items-center justify-between border-b border-slate-200 pb-2.5">
        <div>
          <h3 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
            <span>✎</span> Edit Timetable Period Slot
          </h3>
          <p id="m-slot-timing-label" class="text-[11px] font-medium text-indigo-600 mt-0.5">
            WEDNESDAY • 10:00 to 10:50am • Division 01
          </p>
        </div>
        <button id="btn-close-slot-modal" class="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">&times;</button>
      </div>

      <input type="hidden" id="m-slot-day">
      <input type="hidden" id="m-slot-id">

      <div class="space-y-3 text-xs">
        <!-- Slot Classification Selector -->
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Period Activity Type</label>
          <select id="m-slot-type" class="w-full border border-slate-300 rounded-lg p-2 font-bold bg-white focus:ring-1 focus:ring-indigo-500">
            <option value="lecture">📖 Theory Lecture (Classroom)</option>
            <option value="lab">🧪 Practical Lab (2 Batches / Room)</option>
            <option value="free">☕ Free Period</option>
            <option value="library">📚 Library / Self Study</option>
            <option value="oe">🌐 Open Elective (OE)</option>
          </select>
        </div>

        <!-- Theory Lecture Controls -->
        <div id="slot-editor-theory-panel" class="space-y-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Subject / Course</label>
            <select id="m-slot-subject" class="w-full border border-slate-300 rounded-lg p-2 bg-white font-medium">
              <!-- Populated via JS -->
            </select>
          </div>

          <div class="grid grid-cols-2 gap-2">
            <div>
              <label class="block font-semibold text-slate-700 mb-1">Assigned Faculty Member</label>
              <select id="m-slot-faculty" class="w-full border border-slate-300 rounded-lg p-2 bg-white font-medium">
                <!-- Populated via JS -->
              </select>
            </div>
            <div>
              <label class="block font-semibold text-slate-700 mb-1">Allocated Classroom</label>
              <select id="m-slot-room" class="w-full border border-slate-300 rounded-lg p-2 bg-white font-mono font-bold">
                <!-- Populated via JS -->
              </select>
            </div>
          </div>
        </div>

        <!-- Practical Lab Controls -->
        <div id="slot-editor-lab-panel" class="space-y-3 p-3 bg-purple-50/50 border border-purple-200 rounded-xl hidden">
          <div class="flex items-center justify-between border-b border-purple-200 pb-1.5">
            <span class="font-bold text-purple-900">Lab Batch Configuration (2 Batches / Room)</span>
            <span class="text-[10px] text-purple-700 font-medium">40 Cap per Lab</span>
          </div>

          <div>
            <label class="block font-semibold text-slate-700 mb-1">Lab Course</label>
            <select id="m-slot-lab-subject" class="w-full border border-purple-300 rounded-lg p-2 bg-white font-medium">
              <!-- Populated via JS -->
            </select>
          </div>

          <div class="grid grid-cols-2 gap-2">
            <div class="p-2 bg-white rounded-lg border border-purple-200 space-y-1.5">
              <strong class="text-purple-950 font-bold block text-[11px]">Lab 1 (Batches A & B)</strong>
              <div>
                <label class="text-[10px] text-slate-500 block">Faculty 1:</label>
                <select id="m-slot-lab-fac1" class="w-full border border-slate-300 rounded p-1 text-[11px] bg-white"></select>
              </div>
              <div>
                <label class="text-[10px] text-slate-500 block">Room:</label>
                <select id="m-slot-lab-room1" class="w-full border border-slate-300 rounded p-1 text-[11px] font-mono bg-white"></select>
              </div>
            </div>

            <div class="p-2 bg-white rounded-lg border border-purple-200 space-y-1.5">
              <strong class="text-purple-950 font-bold block text-[11px]">Lab 2 (Batches C & D)</strong>
              <div>
                <label class="text-[10px] text-slate-500 block">Faculty 2:</label>
                <select id="m-slot-lab-fac2" class="w-full border border-slate-300 rounded p-1 text-[11px] bg-white"></select>
              </div>
              <div>
                <label class="text-[10px] text-slate-500 block">Room:</label>
                <select id="m-slot-lab-room2" class="w-full border border-slate-300 rounded p-1 text-[11px] font-mono bg-white"></select>
              </div>
            </div>
          </div>
        </div>

        <!-- Live Conflict Detection Status Banner -->
        <div id="m-slot-conflict-banner" class="p-2.5 rounded-lg border border-emerald-300 bg-emerald-50 text-emerald-800 text-[11px] flex items-center gap-2">
          <span>✅</span>
          <span>Zero conflicts detected for this assignment.</span>
        </div>
      </div>

      <div class="flex items-center justify-between pt-2 border-t border-slate-200">
        <button id="btn-slot-mark-free" class="px-3 py-1.5 rounded-lg border border-rose-300 text-rose-700 hover:bg-rose-50 text-xs font-semibold cursor-pointer">
          Mark Slot as Free
        </button>

        <div class="flex items-center gap-2">
          <button id="btn-cancel-slot-modal" class="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer">Cancel</button>
          <button id="btn-save-slot" class="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs cursor-pointer">Apply Changes</button>
        </div>
      </div>
    </div>
  </div>
MODALS_V2

print "Modals v2 written successfully.\n";
close $out;
