use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

print $out <<'MODALS_HTML';

  <!-- ==================================================== -->
  <!-- MODAL: ADD / EDIT ROOM                               -->
  <!-- ==================================================== -->
  <div id="modal-add-room" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 z-50 hidden">
    <div class="bg-white rounded-2xl border border-slate-300 shadow-2xl max-w-md w-full p-5 space-y-4">
      <div class="flex items-center justify-between border-b border-slate-200 pb-2.5">
        <h3 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
          <span>🏛</span> Add / Configure Campus Facility
        </h3>
        <button id="btn-close-room-modal" class="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">&times;</button>
      </div>

      <div class="space-y-3 text-xs">
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Room No / Identifier *</label>
          <input type="text" id="m-room-no" placeholder="e.g. 215 or CE-7" class="w-full border border-slate-300 rounded-lg p-2 font-mono">
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Facility Type *</label>
            <select id="m-room-type" class="w-full border border-slate-300 rounded-lg p-2 bg-white">
              <option value="Classroom">Classroom (80 Cap)</option>
              <option value="Computer-Lab">Computer Lab (40 Cap)</option>
              <option value="Core-Lab">Core Engg Lab (40 Cap)</option>
              <option value="Workshop">Workshop / Studio</option>
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Student Capacity *</label>
            <input type="number" id="m-room-capacity" value="80" class="w-full border border-slate-300 rounded-lg p-2 font-mono">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Department</label>
            <select id="m-room-dept" class="w-full border border-slate-300 rounded-lg p-2 bg-white">
              <option value="CE">Computer Engg</option>
              <option value="IT">Information Tech</option>
              <option value="CSD">CS & Design</option>
              <option value="AIDS">AI & Data Science</option>
              <option value="ME">Mechanical Engg</option>
              <option value="CH">Chemical Engg</option>
              <option value="EE">Electrical Engg</option>
              <option value="CL">Civil Engg</option>
              <option value="Shared">Shared / Central</option>
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Building & Floor</label>
            <input type="text" id="m-room-floor" placeholder="e.g. Main 2nd Floor" class="w-full border border-slate-300 rounded-lg p-2">
          </div>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Equipped Features</label>
          <input type="text" id="m-room-features" placeholder="e.g. Smart Projector, High-Speed LAN, AC" class="w-full border border-slate-300 rounded-lg p-2">
        </div>
      </div>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
        <button id="btn-cancel-room-modal" class="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer">Cancel</button>
        <button id="btn-save-room" class="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs cursor-pointer">Save Facility</button>
      </div>
    </div>
  </div>

  <!-- ==================================================== -->
  <!-- MODAL: ADD / EDIT FACULTY PREFERENCES                -->
  <!-- ==================================================== -->
  <div id="modal-add-faculty" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 z-50 hidden">
    <div class="bg-white rounded-2xl border border-slate-300 shadow-2xl max-w-lg w-full p-5 space-y-4 max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between border-b border-slate-200 pb-2.5">
        <h3 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
          <span>👨‍🏫</span> Configure Faculty Profile & Preferences
        </h3>
        <button id="btn-close-faculty-modal" class="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">&times;</button>
      </div>

      <div class="space-y-3 text-xs">
        <div class="grid grid-cols-3 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Faculty Code *</label>
            <input type="text" id="m-fac-code" placeholder="e.g. MAP" class="w-full border border-slate-300 rounded-lg p-2 font-mono">
          </div>
          <div class="col-span-2">
            <label class="block font-semibold text-slate-700 mb-1">Full Name with Title *</label>
            <input type="text" id="m-fac-name" placeholder="e.g. Dr. Malay Bhatt" class="w-full border border-slate-300 rounded-lg p-2 font-bold">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Department *</label>
            <select id="m-fac-dept" class="w-full border border-slate-300 rounded-lg p-2 bg-white">
              <!-- Populated via JS -->
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Designation</label>
            <input type="text" id="m-fac-designation" placeholder="e.g. Professor & Head" class="w-full border border-slate-300 rounded-lg p-2">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Experience (Years)</label>
            <input type="text" id="m-fac-experience" placeholder="e.g. 18 Years" class="w-full border border-slate-300 rounded-lg p-2">
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Highest Qualification</label>
            <input type="text" id="m-fac-qualification" placeholder="e.g. Ph.D., M.E., B.E." class="w-full border border-slate-300 rounded-lg p-2">
          </div>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Domain Skills / Field Expertise</label>
          <input type="text" id="m-fac-skills" placeholder="e.g. Algorithms, Computer Networks, Machine Learning" class="w-full border border-slate-300 rounded-lg p-2">
        </div>

        <!-- 1 to 5 Subject Priorities -->
        <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-bold text-slate-800">Subject Teaching Preferences (Priority 1 to 5)</span>
            <span class="text-[10px] text-indigo-700 font-semibold bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">Only Priority 1 is Mandatory</span>
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-amber-900 mb-0.5">🥇 Priority 1 (Required) *</label>
            <input type="text" id="m-fac-p1" placeholder="e.g. Design and Analysis of Algorithms" class="w-full border border-amber-300 bg-amber-50/50 rounded-lg p-1.5 font-medium">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">🥈 Priority 2 (Optional)</label>
            <input type="text" id="m-fac-p2" placeholder="e.g. Computer Networks" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">🥉 Priority 3 (Optional)</label>
            <input type="text" id="m-fac-p3" placeholder="e.g. Python for Data Science" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">Priority 4 (Optional)</label>
            <input type="text" id="m-fac-p4" placeholder="e.g. Web Development" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-700 mb-0.5">Priority 5 (Optional)</label>
            <input type="text" id="m-fac-p5" placeholder="e.g. Distributed Computing" class="w-full border border-slate-300 rounded-lg p-1.5">
          </div>
        </div>
      </div>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
        <button id="btn-cancel-faculty-modal" class="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer">Cancel</button>
        <button id="btn-save-faculty" class="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs cursor-pointer">Save Faculty</button>
      </div>
    </div>
  </div>
MODALS_HTML

print "Modals HTML written.\n";
close $out;
