from adit_timetable_ai.database import ADIT_PORTAL_DATA

print(f"Total faculty: {len(ADIT_PORTAL_DATA['faculty'])}")
depts = {}
for fac in ADIT_PORTAL_DATA['faculty']:
    depts.setdefault(fac['dept'], []).append(fac)

for d, facs in depts.items():
    print(f"\n=== Department: {d} ({len(facs)} faculty) ===")
    for f in facs:
        priors = f.get('priorities', [])
        p_str = ", ".join(priors[:3]) if priors else "None"
        print(f"  [{f['code']}] {f['name']} ({f.get('designation', '')}) - {p_str}")
