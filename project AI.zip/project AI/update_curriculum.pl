use strict;
use warnings;

my $html_file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $fh, '<', $html_file or die "Cannot open $html_file: $!";
my $content = do { local $/; <$fh> };
close $fh;

# Generate the complete curriculums dictionary
my $curriculums_js = q{      curriculums: {
        // ==========================================
        // COMPUTER ENGINEERING (CE) - SEM 1 TO 8
        // ==========================================
        "CE_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000103", name: "Programming for Problem Solving (PPS - C)", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" },
          { code: "202000104", name: "Basic Electrical Engineering (BEE)", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000105", name: "Engineering Graphics & Design (EGD)", short: "EGD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" },
          { code: "202000106", name: "Environmental Science & Constitution", short: "ES", category: "Audit", l: 2, t: 0, p: 0, c: 0, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "CE_2": [
          { code: "202000201", name: "Mathematics - II (Advanced Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000203", name: "Basic Electronics & Digital Systems", short: "BEDS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "CBJ" },
          { code: "202000204", name: "Workshop & Manufacturing Practices", short: "WS", category: "ESC", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" },
          { code: "202000205", name: "English for Technical Communication", short: "ETC", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "CE_3": [
          { code: "202043301", name: "Data Structures & Algorithms (DSA)", short: "DSA", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202043302", name: "Database Management Systems (DBMS)", short: "DBMS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "PKT" },
          { code: "202043303", name: "Digital Logic & Computer Design (DLD)", short: "DLD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "CBJ" },
          { code: "202043304", name: "Discrete Mathematics (DM)", short: "DM", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202043305", name: "Object Oriented Programming with C++", short: "OOPC", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" }
        ],
        "CE_4": [
          { code: "202044401", name: "Operating Systems (OS)", short: "OS", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202044402", name: "Computer Organization & Architecture (COA)", short: "COA", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "CE", facultyCode: "VVN" },
          { code: "202044403", name: "Object Oriented Programming with Java", short: "JAVA", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "AW" },
          { code: "202044404", name: "Theory of Computation & Automata (FLAT)", short: "TOC", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "MB" },
          { code: "202044405", name: "Probability, Statistics & Numerical Analysis", short: "PSNA", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "CE_5": [
          { code: "202045601", name: "Design and Analysis of Algorithms - Professional Core", short: "DAA", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202044501", name: "Computer Networks - Professional Core", short: "CN", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "PKT" },
          { code: "202045603", name: "Python for Data Science - Professional Core", short: "PDS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "TRR" },
          { code: "202044505", name: "Web Development - Professional Core", short: "WD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" },
          { code: "202045606", name: "Computer Graphics - PE1", short: "CG", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "INT" },
          { code: "202045605", name: "Advanced Java Programming - PE1", short: "AJP", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "AW" },
          { code: "202045610", name: "Distributed Computing - PE1", short: "DC", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "PSB" },
          { code: "202045699", name: "Open Elective (Disaster Management / Environment)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "CE_6": [
          { code: "202046601", name: "Compiler Design", short: "CD", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "CE", facultyCode: "MB" },
          { code: "202046602", name: "Machine Learning & AI", short: "ML", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202046603", name: "Full Stack Web Technologies (MERN)", short: "FSW", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" },
          { code: "202046604", name: "Software Testing & Quality Assurance", short: "STQA", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "PKT" },
          { code: "202046605", name: "Mobile Application Development (Flutter/Android)", short: "MAD", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "AW" },
          { code: "202046606", name: "Mini Project & Technical Seminar", short: "MP", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "CE", facultyCode: "CBJ" }
        ],
        "CE_7": [
          { code: "202047701", name: "Cloud Computing & DevOps Architecture", short: "CC", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "MB" },
          { code: "202047702", name: "Cyber Security & Digital Forensics", short: "CSF", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202047703", name: "Blockchain & Smart Contracts", short: "BC", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "PKT" },
          { code: "202047704", name: "Internet of Things (IoT) Systems", short: "IOT", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "VVN" },
          { code: "202047705", name: "Major Project - Phase I", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "CE", facultyCode: "MB" }
        ],
        "CE_8": [
          { code: "202048801", name: "Industry Internship / Major Capstone Project - Phase II", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "MB" },
          { code: "202048802", name: "Comprehensive Seminar & Technical Viva", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "DKS" },
          { code: "202048803", name: "Professional Practice, IP Rights & Ethics", short: "ETHICS", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // INFORMATION TECHNOLOGY (IT) - SEM 1 TO 8
        // ==========================================
        "IT_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000103", name: "Programming for Problem Solving (PPS)", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "AJR" },
          { code: "202000104", name: "Basic Electrical Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000105", name: "Engineering Graphics & Design", short: "EGD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" },
          { code: "202000106", name: "Environmental Science & Constitution", short: "ES", category: "Audit", l: 2, t: 0, p: 0, c: 0, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "IT_2": [
          { code: "202000201", name: "Mathematics - II (Vector Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000203", name: "Basic Electronics Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "KJP" },
          { code: "202000204", name: "Workshop Practices", short: "WS", category: "ESC", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" },
          { code: "202000205", name: "English for Technical Communication", short: "ETC", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "IT_3": [
          { code: "202043301", name: "Data Structures", short: "DS", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "IT", facultyCode: "MAP" },
          { code: "202043302", name: "Database Management Systems", short: "DBMS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "SNG" },
          { code: "202043305", name: "Object Oriented Programming with C++", short: "OOP", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "AJR" },
          { code: "202043307", name: "Digital Electronics & Computer Organization", short: "DECO", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "KJP" },
          { code: "202043304", name: "Discrete Mathematics", short: "DM", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "IT_4": [
          { code: "202044401", name: "Operating Systems", short: "OS", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "IT", facultyCode: "MAP" },
          { code: "202044402", name: "Computer Networks", short: "CN", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "HVP" },
          { code: "202044403", name: "Java Programming & Technologies", short: "JAVA", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "AJR" },
          { code: "202044405", name: "Probability & Numerical Techniques", short: "PNT", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202044406", name: "Principles of Software Engineering", short: "SE", category: "PCC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "Classroom", facultyCode: "NMM" }
        ],
        "IT_5": [
          { code: "202045601", name: "Design and Analysis of Algorithms", short: "DAA", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "IT", facultyCode: "MAP" },
          { code: "202045602", name: "Software Engineering", short: "SE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "AJR" },
          { code: "202044504", name: "Programming with Python", short: "PWP", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "NMM" },
          { code: "202044505", name: "Web Development", short: "WD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "SNG" },
          { code: "202044503", name: "Artificial Intelligence (PE1)", short: "AI", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "KJP" },
          { code: "202045605", name: "Advanced Java Programming (PE1)", short: "AJP", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "KJP" },
          { code: "202045607", name: "Cyber Security (PE1)", short: "CS", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "HVP" },
          { code: "202045698", name: "Open Elective (Project Management)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "IT_6": [
          { code: "202046602", name: "Machine Learning & Analytics", short: "MLA", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "SNG" },
          { code: "202046607", name: "Cloud Computing & Virtualization", short: "CCV", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "MAP" },
          { code: "202046608", name: "Full Stack Application Development", short: "FSAD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "AJR" },
          { code: "202046609", name: "Information & Network Security", short: "INS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "HVP" },
          { code: "202046610", name: "Software Project Management (PE2)", short: "SPM", category: "PEC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "Classroom", facultyCode: "NMM" },
          { code: "202046606", name: "Mini Project & Technical Seminar", short: "MP", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "IT", facultyCode: "KJP" }
        ],
        "IT_7": [
          { code: "202047701", name: "DevOps & Cloud Native Architecture", short: "DEV", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "IT", facultyCode: "MAP" },
          { code: "202047702", name: "Cyber Security & Ethical Hacking", short: "EH", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "IT", facultyCode: "HVP" },
          { code: "202047709", name: "Big Data Technologies & Analytics", short: "BDA", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "SNG" },
          { code: "202047710", name: "Mobile Computing & Wireless Tech", short: "MCWT", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "IT", facultyCode: "AJR" },
          { code: "202047705", name: "Major Project - Phase I", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "IT", facultyCode: "SNG" }
        ],
        "IT_8": [
          { code: "202048801", name: "Industry Internship / Major Capstone Project - Phase II", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "SNG" },
          { code: "202048802", name: "Technical Seminar & Comprehensive Viva", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "MAP" },
          { code: "202048803", name: "Intellectual Property Rights & Cyber Laws", short: "IPR", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // COMPUTER SCIENCE & DESIGN (CSD) - SEM 1 TO 8
        // ==========================================
        "CSD_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000103", name: "Programming for Problem Solving", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202000107", name: "Visual Arts & Design Thinking", short: "VADT", category: "ESC", l: 2, t: 0, p: 4, c: 4, isHighCredit: true, labType: "Design", facultyCode: "CBJ" },
          { code: "202000104", name: "Basic Electrical Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" }
        ],
        "CSD_2": [
          { code: "202000201", name: "Mathematics - II (Advanced Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000203", name: "Basic Electronics Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "VVN" },
          { code: "202000208", name: "Design Workshop & Prototyping", short: "DWP", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "Design", facultyCode: "CBJ" },
          { code: "202000205", name: "English for Technical Communication", short: "ETC", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "CSD_3": [
          { code: "202043301", name: "Data Structures & Design Algorithms", short: "DSA", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202043302", name: "Database Management Systems", short: "DBMS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "AKK" },
          { code: "202043308", name: "Fundamentals of UI/UX Design", short: "UIUX", category: "PCC", l: 2, t: 0, p: 4, c: 4, isHighCredit: true, labType: "Design", facultyCode: "CBJ" },
          { code: "202043303", name: "Digital Logic & System Design", short: "DLSD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "VVN" },
          { code: "202043304", name: "Discrete Mathematical Structures", short: "DMS", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "CSD_4": [
          { code: "202044401", name: "Operating Systems Principles", short: "OSP", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202044407", name: "Interactive Computer Graphics", short: "ICG", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Design", facultyCode: "CBJ" },
          { code: "202044403", name: "Object Oriented Design with Java", short: "OODJ", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "AW" },
          { code: "202044408", name: "Design Research Methods & Usability Testing", short: "DRM", category: "PCC", l: 2, t: 0, p: 4, c: 4, isHighCredit: true, labType: "Design", facultyCode: "VVN" },
          { code: "202044405", name: "Probability & Applied Statistics", short: "PAS", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "CSD_5": [
          { code: "202045601", name: "Design and Analysis of Algorithms", short: "DAA", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "CE", facultyCode: "BJM" },
          { code: "202044507", name: "Computer Architecture & Design", short: "CAD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "VVN" },
          { code: "202045611", name: "Computer Graphics & Design", short: "CGD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "CBJ" },
          { code: "202045612", name: "Python and Web Programming", short: "PWP", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "AKK" },
          { code: "202045605", name: "Advance Java Programming - PE1", short: "AJP", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "AW" },
          { code: "202045607", name: "Cyber Security - PE1", short: "CS", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "AJK" },
          { code: "202045699", name: "Open Elective (Sustainable Design)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "CSD_6": [
          { code: "202046611", name: "Interactive UX / AR & VR Systems", short: "ARVR", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Design", facultyCode: "CBJ" },
          { code: "202046612", name: "3D Animation & Game Design", short: "GAME", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Design", facultyCode: "VVN" },
          { code: "202046602", name: "Machine Learning in Design", short: "MLD", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202046613", name: "Mobile UX & Digital Product Engineering", short: "MUX", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Design", facultyCode: "AKK" },
          { code: "202046614", name: "Design Studio Mini Project", short: "STUDIO", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Design", facultyCode: "CBJ" }
        ],
        "CSD_7": [
          { code: "202047706", name: "Spatial Computing & Generative Design", short: "SPATIAL", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "Design", facultyCode: "CBJ" },
          { code: "202047707", name: "Human-AI Interaction Systems", short: "HAII", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "DKS" },
          { code: "202047708", name: "Design Systems & Web Frameworks", short: "DSYS", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "CE", facultyCode: "AKK" },
          { code: "202047705", name: "Major Project - Phase I (Design & Build)", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "Design", facultyCode: "DKS" }
        ],
        "CSD_8": [
          { code: "202048801", name: "Industry Internship / Major Capstone Design Project", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "DKS" },
          { code: "202048802", name: "Design Portfolio & Comprehensive Viva", short: "PORTFOLIO", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "CBJ" },
          { code: "202048803", name: "Design Ethics, Copyrights & Patents", short: "IPR", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // ARTIFICIAL INTELLIGENCE & DATA SCIENCE (AIDS)
        // ==========================================
        "AIDS_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000103", name: "Programming for Problem Solving (Python/C)", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "DKS" },
          { code: "202000104", name: "Basic Electrical Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000105", name: "Engineering Graphics & Design", short: "EGD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" }
        ],
        "AIDS_2": [
          { code: "202000201", name: "Mathematics - II (Multivariate Calculus & Matrices)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000203", name: "Basic Electronics & IoT Sensors", short: "BEIS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "CBJ" },
          { code: "202000204", name: "Python for Scientific Computing", short: "PSC", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "AI", facultyCode: "TRR" },
          { code: "202000205", name: "English for Technical Communication", short: "ETC", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "AIDS_3": [
          { code: "202043301", name: "Data Structures for AI & Analytics", short: "DSA-AI", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "AI", facultyCode: "DKS" },
          { code: "202043309", name: "Mathematical Foundations for Data Science", short: "MFDS", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202043302", name: "Relational & NoSQL Database Systems", short: "RNDS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "SNG" },
          { code: "202043310", name: "Object Oriented Design with Java", short: "OODJ", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "AW" },
          { code: "202043307", name: "Computer Architecture & Linux Systems", short: "CALS", category: "PCC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "AI", facultyCode: "VVN" }
        ],
        "AIDS_4": [
          { code: "202044401", name: "Operating Systems & Concurrency", short: "OSC", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "AI", facultyCode: "DKS" },
          { code: "202044410", name: "Artificial Intelligence Foundations", short: "AIF", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "SNG" },
          { code: "202044411", name: "Applied Probability & Statistical Inference", short: "APSI", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202044412", name: "Data Wrangling & Exploratory Analysis", short: "DWEA", category: "PCC", l: 2, t: 0, p: 4, c: 4, isHighCredit: true, labType: "AI", facultyCode: "TRR" },
          { code: "202044402", name: "Data Communications & Networking", short: "DCN", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "PKT" }
        ],
        "AIDS_5": [
          { code: "202045601", name: "Design and Analysis of Algorithms", short: "DAA", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "AI", facultyCode: "DKS" },
          { code: "202045620", name: "Machine Learning Concepts & Algorithms", short: "ML", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "AI", facultyCode: "SNG" },
          { code: "202045621", name: "Deep Learning Foundations (PyTorch/TF)", short: "DL", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "TRR" },
          { code: "202045622", name: "Big Data Engineering & Spark", short: "BDE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "MAP" },
          { code: "202045623", name: "Natural Language Processing (PE1)", short: "NLP", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "AI", facultyCode: "KJP" },
          { code: "202045699", name: "Open Elective (AI for Social Good)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "AIDS_6": [
          { code: "202046620", name: "Computer Vision & Pattern Recognition", short: "CVPR", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "TRR" },
          { code: "202046621", name: "Generative AI & LLM Systems", short: "GENAI", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "DKS" },
          { code: "202046622", name: "MLOps, Pipeline Engineering & Ethics", short: "MLOPS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "SNG" },
          { code: "202046623", name: "Reinforcement Learning & Game AI", short: "RL", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "AI", facultyCode: "KJP" },
          { code: "202046624", name: "Applied AI Domain Project", short: "AIPROJ", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "AI", facultyCode: "DKS" }
        ],
        "AIDS_7": [
          { code: "202047706", name: "Autonomous Systems & Edge AI", short: "EDGEAI", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "AI", facultyCode: "DKS" },
          { code: "202047707", name: "Cloud AI Infrastructure & High Performance Computing", short: "HPC", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "AI", facultyCode: "MB" },
          { code: "202047708", name: "Time Series Analysis & Forecasting", short: "TSA", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "AI", facultyCode: "SNG" },
          { code: "202047705", name: "Major Project - Phase I (AI System)", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "AI", facultyCode: "DKS" }
        ],
        "AIDS_8": [
          { code: "202048801", name: "Industry Internship / Major Capstone AI Project", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "DKS" },
          { code: "202048802", name: "AI Research Paper & Technical Viva", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "SNG" },
          { code: "202048803", name: "AI Governance, Patents & Ethics", short: "ETHICS", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // MECHANICAL ENGINEERING (ME) - SEM 1 TO 8
        // ==========================================
        "ME_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000108", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000104", name: "Basic Electrical & Electronics", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000109", name: "Engineering Mechanics (Statics & Dynamics)", short: "EM", category: "ESC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "JVP" },
          { code: "202000105", name: "Engineering Graphics & Computer Drafting", short: "EGCD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" }
        ],
        "ME_2": [
          { code: "202000201", name: "Mathematics - II (Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000204", name: "Workshop & Manufacturing Practice", short: "WMP", category: "ESC", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" },
          { code: "202000210", name: "Elements of Mechanical Engineering", short: "EME", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202000205", name: "Technical Communication & Ethics", short: "TCE", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "ME_3": [
          { code: "202013301", name: "Engineering Thermodynamics & Heat", short: "THERMO", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202013302", name: "Strength of Materials", short: "SOM", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202013303", name: "Manufacturing Processes - I (Casting/Welding)", short: "MP-1", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Workshop", facultyCode: "JVP" },
          { code: "202013304", name: "Material Science & Metallurgy", short: "MSM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "INT" },
          { code: "202013305", name: "Engineering Mathematics - III", short: "MATH-3", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "ME_4": [
          { code: "202014401", name: "Fluid Mechanics & Hydraulic Machines", short: "FMHM", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202014402", name: "Kinematics of Machinery (KOM)", short: "KOM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202014403", name: "Applied Thermodynamics & Steam Power", short: "AT", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202014404", name: "Manufacturing Processes - II (Machining)", short: "MP-2", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Workshop", facultyCode: "JVP" },
          { code: "202014405", name: "Mechanical Measurement & Metrology", short: "MMM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "INT" }
        ],
        "ME_5": [
          { code: "202015501", name: "Design of Machine Elements (DME)", short: "DME", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "CAD", facultyCode: "JVP" },
          { code: "202015502", name: "Dynamics of Machinery (DOM)", short: "DOM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202015503", name: "Heat and Mass Transfer (HMT)", short: "HMT", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202015504", name: "Internal Combustion Engines (ICE)", short: "ICE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202015505", name: "Operations Research (OR)", short: "OR", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202015599", name: "Open Elective (Automotive Mechatronics)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "ME_6": [
          { code: "202016601", name: "Computer Aided Design & Manufacturing (CAD/CAM)", short: "CAD/CAM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CAD", facultyCode: "JVP" },
          { code: "202016602", name: "Refrigeration and Air Conditioning (RAC)", short: "RAC", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202016603", name: "Production Automation & Robotics", short: "PAR", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202016604", name: "Power Plant Engineering", short: "PPE", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "INT" },
          { code: "202016606", name: "Mechanical Mini Project", short: "MP", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" }
        ],
        "ME_7": [
          { code: "202017701", name: "Automobile Engineering & EV Tech", short: "EV", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" },
          { code: "202017702", name: "Finite Element Method (FEM) Analysis", short: "FEM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CAD", facultyCode: "JVP" },
          { code: "202017703", name: "Renewable Energy Technologies", short: "RET", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "Mechanical", facultyCode: "INT" },
          { code: "202017705", name: "Major Project - Phase I", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "Mechanical", facultyCode: "JVP" }
        ],
        "ME_8": [
          { code: "202018801", name: "Industry Internship / Major Capstone Project", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "JVP" },
          { code: "202018802", name: "Technical Seminar & Project Viva", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "JVP" },
          { code: "202018803", name: "Industrial Management & Quality Control", short: "IMQC", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // CHEMICAL ENGINEERING (CH) - SEM 1 TO 8
        // ==========================================
        "CH_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000108", name: "Applied Chemistry for Engineers", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000104", name: "Basic Electrical Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000105", name: "Engineering Graphics & Design", short: "EGD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" }
        ],
        "CH_2": [
          { code: "202000201", name: "Mathematics - II (Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000211", name: "Organic & Physical Chemistry", short: "OPC", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000103", name: "Programming for Problem Solving", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" },
          { code: "202000204", name: "Workshop Practices", short: "WS", category: "ESC", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" },
          { code: "202000205", name: "Technical Communication & Ethics", short: "TCE", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "CH_3": [
          { code: "202023301", name: "Chemical Process Calculations (CPC)", short: "CPC", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "Classroom", facultyCode: "INT" },
          { code: "202023302", name: "Fluid Flow Operations (FFO)", short: "FFO", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202023303", name: "Chemical Engineering Thermodynamics - I", short: "CET-1", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "INT" },
          { code: "202023304", name: "Mechanical Operations in Chemical Engg", short: "MO", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202023305", name: "Applied Mathematics in Chemical Engg", short: "AMCE", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "CH_4": [
          { code: "202024401", name: "Heat Transfer Operations (HTO)", short: "HTO", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202024402", name: "Mass Transfer Operations - I (MTO-1)", short: "MTO-1", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202024403", name: "Chemical Reaction Engineering - I (CRE-1)", short: "CRE-1", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202024404", name: "Process Equipment Design - I (PED-1)", short: "PED-1", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CAD", facultyCode: "INT" },
          { code: "202024405", name: "Materials of Construction for Chemical Plants", short: "MCCP", category: "PCC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "CH_5": [
          { code: "202025501", name: "Mass Transfer Operations - II (MTO-2)", short: "MTO-2", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202025502", name: "Chemical Reaction Engineering - II (CRE-2)", short: "CRE-2", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202025503", name: "Instrumentation & Process Control", short: "IPC", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202025504", name: "Chemical Technology (Inorganic & Organic)", short: "CT", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202025599", name: "Open Elective (Industrial Safety & HAZOP)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "CH_6": [
          { code: "202026601", name: "Transport Phenomena", short: "TP", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "INT" },
          { code: "202026602", name: "Process Modeling, Simulation & Aspen", short: "PMSA", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202026603", name: "Industrial Pollution Control & Abatement", short: "IPCA", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202026604", name: "Petroleum Refining & Petrochemicals", short: "PRP", category: "PEC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "Classroom", facultyCode: "INT" },
          { code: "202026606", name: "Chemical Process Mini Project", short: "MP", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Chemistry", facultyCode: "INT" }
        ],
        "CH_7": [
          { code: "202027701", name: "Plant Design & Economics", short: "PDE", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "Classroom", facultyCode: "INT" },
          { code: "202027702", name: "Polymer Science & Technology", short: "PST", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202027703", name: "Biochemical Engineering Principles", short: "BCE", category: "PEC", l: 3, t: 0, p: 2, c: 4, isHighCredit: false, labType: "Chemistry", facultyCode: "INT" },
          { code: "202027705", name: "Major Project - Phase I", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" }
        ],
        "CH_8": [
          { code: "202028801", name: "Industry Internship / Major Capstone Chemical Project", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "INT" },
          { code: "202028802", name: "Process Seminar & Comprehensive Viva", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "INT" },
          { code: "202028803", name: "Chemical Plant Management & Safety Regulations", short: "CPMS", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // ELECTRICAL ENGINEERING (EE) - SEM 1 TO 8
        // ==========================================
        "EE_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000104", name: "Basic Electrical Engineering", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000103", name: "Programming for Problem Solving", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" },
          { code: "202000105", name: "Engineering Graphics & Design", short: "EGD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" }
        ],
        "EE_2": [
          { code: "202000201", name: "Mathematics - II (Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000203", name: "Basic Electronic Devices & Circuits", short: "BEDC", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202000204", name: "Electrical Workshop Practice", short: "EWS", category: "ESC", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" },
          { code: "202000205", name: "Technical Communication Skills", short: "TCS", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "EE_3": [
          { code: "202033301", name: "Electrical Circuit Analysis (ECA)", short: "ECA", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202033302", name: "Electrical Machines - I (Transformers & DC)", short: "EM-1", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202033303", name: "Electromagnetic Fields & Waves", short: "EMF", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "AW" },
          { code: "202033304", name: "Analog Electronics & Op-Amps", short: "AE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "CBJ" },
          { code: "202033305", name: "Engineering Mathematics - III", short: "MATH-3", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "EE_4": [
          { code: "202034401", name: "Power Systems - I (Generation & Transmission)", short: "PS-1", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202034402", name: "Electrical Machines - II (Induction & Sync)", short: "EM-2", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202034403", name: "Control Systems Engineering", short: "CSE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202034404", name: "Digital Electronics & Microprocessors", short: "DEMP", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "CBJ" },
          { code: "202034405", name: "Electrical Measurements & Sensors", short: "EMS", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "INT" }
        ],
        "EE_5": [
          { code: "202035501", name: "Power Electronics & Converter Drives", short: "PE", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202035502", name: "Power Systems - II (Analysis & Faults)", short: "PS-2", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202035503", name: "Microcontrollers & Embedded Systems", short: "MCES", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "CBJ" },
          { code: "202035504", name: "Electrical Machine Design", short: "EMD", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "CAD", facultyCode: "AW" },
          { code: "202035599", name: "Open Elective (Renewable Energy Integration)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "EE_6": [
          { code: "202036601", name: "Switchgear, Protection & Relays", short: "SWP", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202036602", name: "Digital Signal Processing (DSP)", short: "DSP", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "INT" },
          { code: "202036603", name: "Renewable Energy Systems & Smart Grid", short: "RESG", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202036604", name: "Industrial Automation & PLC / SCADA", short: "PLC", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "INT" },
          { code: "202036606", name: "Electrical Mini Project", short: "MP", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "EE", facultyCode: "AW" }
        ],
        "EE_7": [
          { code: "202037701", name: "High Voltage Engineering & Testing", short: "HVE", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202037702", name: "Electric Vehicle Powertrain & Battery Tech", short: "EVT", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" },
          { code: "202037703", name: "Power System Operation & Control", short: "PSOC", category: "PEC", l: 3, t: 1, p: 0, c: 4, isHighCredit: false, labType: "EE", facultyCode: "INT" },
          { code: "202037705", name: "Major Project - Phase I", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" }
        ],
        "EE_8": [
          { code: "202038801", name: "Industry Internship / Major Capstone Electrical Project", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "AW" },
          { code: "202038802", name: "Seminar & Comprehensive Electrical Viva", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "AW" },
          { code: "202038803", name: "Energy Auditing, Conservation & Management", short: "EACM", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],

        // ==========================================
        // CIVIL ENGINEERING (CL) - SEM 1 TO 8
        // ==========================================
        "CL_1": [
          { code: "202000101", name: "Mathematics - I (Calculus & Linear Algebra)", short: "MATH-1", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000102", name: "Engineering Physics", short: "EP", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Physics", facultyCode: "TRR" },
          { code: "202000109", name: "Engineering Mechanics", short: "EM", category: "ESC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202000105", name: "Engineering Graphics & Building Drafting", short: "EGD", category: "ESC", l: 1, t: 0, p: 4, c: 3, isHighCredit: false, labType: "CAD", facultyCode: "VVN" },
          { code: "202000104", name: "Basic Electrical & Electronics", short: "BEE", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "EE", facultyCode: "AW" }
        ],
        "CL_2": [
          { code: "202000201", name: "Mathematics - II (Calculus & ODE)", short: "MATH-2", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" },
          { code: "202000202", name: "Engineering Chemistry", short: "CHEM", category: "BSC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Chemistry", facultyCode: "INT" },
          { code: "202000103", name: "Programming for Problem Solving", short: "PPS", category: "ESC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "CE", facultyCode: "KSP" },
          { code: "202000204", name: "Workshop & Construction Practice", short: "WCP", category: "ESC", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Workshop", facultyCode: "JVP" },
          { code: "202000205", name: "Technical Communication Skills", short: "TCS", category: "HSMC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Language", facultyCode: "INT" }
        ],
        "CL_3": [
          { code: "202053301", name: "Surveying & Geomatics", short: "SURV", category: "PCC", l: 3, t: 0, p: 4, c: 5, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202053302", name: "Mechanics of Solids (MOS)", short: "MOS", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202053303", name: "Fluid Mechanics & Hydraulics", short: "FMH", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202053304", name: "Building Construction & Materials", short: "BCM", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202053305", name: "Engineering Geology", short: "EG", category: "PCC", l: 2, t: 0, p: 2, c: 3, isHighCredit: false, labType: "Civil", facultyCode: "INT" }
        ],
        "CL_4": [
          { code: "202054401", name: "Structural Analysis - I (SA-1)", short: "SA-1", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202054402", name: "Geotechnical Engineering - I (Soil Mechanics)", short: "GE-1", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202054403", name: "Concrete Technology", short: "CT", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202054404", name: "Water Supply & Environmental Engineering", short: "WSEE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202054405", name: "Numerical Methods in Civil Engineering", short: "NMCE", category: "BSC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "Classroom", facultyCode: "DM" }
        ],
        "CL_5": [
          { code: "202055501", name: "Structural Analysis - II (SA-2)", short: "SA-2", category: "PCC", l: 4, t: 1, p: 0, c: 5, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202055502", name: "Design of Reinforced Concrete Structures (DRCS)", short: "DRCS", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "CAD", facultyCode: "INT" },
          { code: "202055503", name: "Geotechnical Engineering - II (Foundations)", short: "GE-2", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202055504", name: "Highway & Transportation Engineering", short: "HTE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202055599", name: "Open Elective (GIS & Remote Sensing)", short: "OE", category: "OEC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ],
        "CL_6": [
          { code: "202056601", name: "Design of Steel Structures (DSS)", short: "DSS", category: "PCC", l: 3, t: 1, p: 0, c: 4, isHighCredit: true, labType: "CAD", facultyCode: "INT" },
          { code: "202056602", name: "Environmental Engineering - II (Wastewater)", short: "EE-2", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202056603", name: "Hydrology & Water Resources Engineering", short: "HWRE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202056604", name: "Construction Project Management & Estimation", short: "CPME", category: "PCC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "Classroom", facultyCode: "INT" },
          { code: "202056606", name: "Civil Engineering Mini Project", short: "MP", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Civil", facultyCode: "INT" }
        ],
        "CL_7": [
          { code: "202057701", name: "Earthquake Resistant Design of Structures", short: "ERDS", category: "PCC", l: 4, t: 0, p: 2, c: 5, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202057702", name: "Bridge & Tunnel Engineering", short: "BTE", category: "PCC", l: 3, t: 0, p: 2, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" },
          { code: "202057703", name: "Urban Infrastructure Planning & Smart Cities", short: "UIP", category: "PEC", l: 3, t: 0, p: 0, c: 3, isHighCredit: false, labType: "Classroom", facultyCode: "INT" },
          { code: "202057705", name: "Major Project - Phase I", short: "PROJ-1", category: "PROJ", l: 0, t: 0, p: 8, c: 4, isHighCredit: true, labType: "Civil", facultyCode: "INT" }
        ],
        "CL_8": [
          { code: "202058801", name: "Industry Internship / Major Capstone Civil Project", short: "CAPSTONE", category: "PROJ", l: 0, t: 0, p: 24, c: 12, isHighCredit: true, labType: "Industry/Lab", facultyCode: "INT" },
          { code: "202058802", name: "Structural Viva & Comprehensive Seminar", short: "VIVA", category: "PROJ", l: 0, t: 0, p: 4, c: 2, isHighCredit: false, labType: "Seminar", facultyCode: "INT" },
          { code: "202058803", name: "Construction Law, Contracts & Valuation", short: "CLCV", category: "HSMC", l: 2, t: 0, p: 0, c: 2, isHighCredit: false, labType: "Classroom", facultyCode: "INT" }
        ]
      },};

# Replace the existing curriculums block in $content
if ($content =~ s/curriculums:\s*\{[\s\S]*?\n\s*\},(\s*\/\/\s*3\.\s*Faculty List)/$curriculums_js\n$1/) {
    print "Successfully replaced curriculums block!\n";
} else {
    die "Could not find curriculums block to replace!";
}

open my $out, '>', $html_file or die "Cannot write to $html_file: $!";
print $out $content;
close $out;
print "Updated index.html with all 8 semesters curriculum data for all departments!\n";
