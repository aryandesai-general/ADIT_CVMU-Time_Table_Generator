use strict;
use warnings;
use utf8;

my $target = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";
open my $out, '>>:utf8', $target or die "Cannot append to $target: $!";

print $out <<'HTML_PART2';

    <!-- ==================================================== -->
    <!-- SECTION 1: ROOM ENTRY SECTION (EDITABLE ROOMS)      -->
    <!-- ==================================================== -->
    <div id="tab-rooms" class="tab-pane active space-y-4">
      <!-- Rooms KPI Overview -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p class="text-[11px] font-medium text-slate-500 uppercase tracking-wide">Theory Classrooms</p>
            <p id="kpi-classrooms-count" class="text-xl font-black text-indigo-600 mt-0.5">14 Rooms</p>
            <p class="text-[10px] text-slate-400">Capacity: 80 Students / Class</p>
          </div>
          <div class="w-10 h-10 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-center text-lg">🏛</div>
        </div>

        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p class="text-[11px] font-medium text-slate-500 uppercase tracking-wide">Specialized Labs</p>
            <p id="kpi-labs-count" class="text-xl font-black text-emerald-600 mt-0.5">18 Labs</p>
            <p class="text-[10px] text-slate-400">Capacity: 40 Students / 2 Batches</p>
          </div>
          <div class="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-lg">🧪</div>
        </div>

        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p class="text-[11px] font-medium text-slate-500 uppercase tracking-wide">Workshops & Studios</p>
            <p id="kpi-workshops-count" class="text-xl font-black text-amber-600 mt-0.5">4 Units</p>
            <p class="text-[10px] text-slate-400">Mechanical, Civil & Central Rigs</p>
          </div>
          <div class="w-10 h-10 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-lg">⚙️</div>
        </div>

        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p class="text-[11px] font-medium text-slate-500 uppercase tracking-wide">Total Student Capacity</p>
            <p id="kpi-total-capacity" class="text-xl font-black text-purple-600 mt-0.5">1,840 Seats</p>
            <p class="text-[10px] text-slate-400">Click "Edit" on any room to customize</p>
          </div>
          <div class="w-10 h-10 rounded-lg bg-purple-50 border border-purple-200 flex items-center justify-center text-lg">📝</div>
        </div>
      </div>

      <!-- Action & Filter Bar -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-2">
          <span class="text-xs font-bold text-slate-700">Filter Rooms:</span>
          <button class="btn-filter-room active px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-900 text-white cursor-pointer" data-type="ALL">All Facilities</button>
          <button class="btn-filter-room px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer" data-type="Classroom">Classrooms (80 Cap)</button>
          <button class="btn-filter-room px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer" data-type="Computer-Lab">Computer Labs</button>
          <button class="btn-filter-room px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer" data-type="Core-Lab">Core Engg Labs</button>
          <button class="btn-filter-room px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer" data-type="Workshop">Workshops</button>
        </div>

        <div class="flex items-center gap-2">
          <input type="text" id="input-search-rooms" placeholder="Search room no or name..." class="border border-slate-300 rounded-lg px-3 py-1.5 text-xs w-48 focus:ring-1 focus:ring-indigo-500">
          <button id="btn-open-add-room-modal" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-3 py-1.5 rounded-lg text-xs shadow-xs transition flex items-center gap-1 cursor-pointer">
            <span>➕</span> Add Room / Lab
          </button>
        </div>
      </div>

      <!-- Rooms Grid / Table with Direct EDIT and DELETE actions -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead class="bg-slate-100 text-slate-800 uppercase font-bold border-b border-slate-300 text-[11px]">
              <tr>
                <th class="p-3 border-r border-slate-200">Room No / Identifier</th>
                <th class="p-3 border-r border-slate-200">Facility Type</th>
                <th class="p-3 border-r border-slate-200">Department / Allocation</th>
                <th class="p-3 border-r border-slate-200 text-center">Student Capacity</th>
                <th class="p-3 border-r border-slate-200">Building & Location</th>
                <th class="p-3 border-r border-slate-200">Key Features</th>
                <th class="p-3 text-center">Actions (Editable)</th>
              </tr>
            </thead>
            <tbody id="rooms-table-tbody" class="divide-y divide-slate-200">
              <!-- Dynamically populated via JS with Edit & Delete buttons -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ==================================================== -->
    <!-- SECTION 2: STUDENT ENTRY SECTION                    -->
    <!-- ==================================================== -->
    <div id="tab-students" class="tab-pane hidden space-y-4">
      <!-- Institutional Capacity Standards Banner -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div class="p-3.5 bg-blue-50 border border-blue-200 rounded-xl">
          <div class="flex items-center gap-2 mb-1">
            <span class="text-lg">🏛</span>
            <strong class="text-blue-950 font-bold text-xs">Standard Class / Division: 80 Students</strong>
          </div>
          <p class="text-blue-800 text-[11px] leading-relaxed">Each division accommodates up to 80 enrolled students in one classroom for theory lectures.</p>
        </div>

        <div class="p-3.5 bg-amber-50 border border-amber-200 rounded-xl">
          <div class="flex items-center gap-2 mb-1">
            <span class="text-lg">👥</span>
            <strong class="text-amber-950 font-bold text-xs">Laboratory Batch: 20 Students</strong>
          </div>
          <p class="text-amber-800 text-[11px] leading-relaxed">An 80-student division is subdivided into 4 discrete practical batches: Batch A, B, C, D (20 students each).</p>
        </div>

        <div class="p-3.5 bg-purple-50 border border-purple-200 rounded-xl">
          <div class="flex items-center gap-2 mb-1">
            <span class="text-lg">🧪</span>
            <strong class="text-purple-950 font-bold text-xs">Full Lab Capacity: 2 Batches (40 Students)</strong>
          </div>
          <p class="text-purple-800 text-[11px] leading-relaxed">A full laboratory holds 2 batches simultaneously (40 students: Batch A & B in Lab 1, Batch C & D in Lab 2).</p>
        </div>
      </div>

      <!-- Department Intake & Division Calculator Cards -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-slate-900">Student Intake & Division Allotment Calculator</h2>
          <p class="text-xs text-slate-500">Edit the total student count for each department to dynamically calculate division counts, lab batches, and classroom allocations.</p>
        </div>
        <div class="text-xs font-semibold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
          Auto Formula: <code class="text-indigo-600 font-mono">Divisions = ceil(Intake / 80)</code>
        </div>
      </div>

      <!-- Department Cards Grid -->
      <div id="departments-intake-cards-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <!-- Injected via JS -->
      </div>
    </div>

    <!-- ==================================================== -->
    <!-- SECTION 3: ALL SUBJECTS & CREDITS                    -->
    <!-- ==================================================== -->
    <div id="tab-subjects" class="tab-pane hidden space-y-4">
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-slate-900">All Subjects, Courses & Credits Directory (adit.ac.in)</h2>
          <p class="text-xs text-slate-500">Course-wise syllabus for all branches with Main Courses, Professional Electives, Open Electives, and Credits.</p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <select id="sel-curriculum-dept" class="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 font-bold bg-white focus:ring-1 focus:ring-indigo-500">
            <!-- Populated via JS -->
          </select>
          <select id="sel-curriculum-sem" class="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 font-bold bg-white focus:ring-1 focus:ring-indigo-500">
            <option value="5">Semester 5 (Odd)</option>
            <option value="1">Semester 1 (Odd)</option>
            <option value="2">Semester 2 (Even)</option>
            <option value="3">Semester 3 (Odd)</option>
            <option value="4">Semester 4 (Even)</option>
            <option value="6">Semester 6 (Even)</option>
            <option value="7">Semester 7 (Odd)</option>
            <option value="8">Semester 8 (Even)</option>
          </select>
          <select id="sel-curriculum-category" class="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 font-bold bg-white">
            <option value="ALL">All Categories</option>
            <option value="PCC">Professional Core (PCC)</option>
            <option value="PEC">Professional Elective (PEC)</option>
            <option value="OEC">Open Elective (OEC)</option>
            <option value="BSC">Basic Science (BSC)</option>
            <option value="ESC">Engineering Science (ESC)</option>
            <option value="PROJ">Project / Internship</option>
          </select>
        </div>
      </div>

      <!-- Quick Semester Navigation Pills -->
      <div class="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between overflow-x-auto gap-2">
        <span class="text-xs font-bold text-slate-600 whitespace-nowrap px-2">Quick Semester:</span>
        <div class="flex items-center space-x-1 text-xs">
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="1">Sem 1</button>
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="2">Sem 2</button>
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="3">Sem 3</button>
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="4">Sem 4</button>
          <button class="sem-pill active px-3 py-1 rounded-lg border border-indigo-600 bg-indigo-600 text-white font-semibold transition cursor-pointer" data-sem="5">Sem 5</button>
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="6">Sem 6</button>
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="7">Sem 7</button>
          <button class="sem-pill px-3 py-1 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 font-semibold transition cursor-pointer" data-sem="8">Sem 8</button>
        </div>
        <div class="text-[11px] text-slate-500 font-medium px-2 whitespace-nowrap">
          ⭐ Highlighted = High-Credit Subject
        </div>
      </div>

      <!-- Semester Metrics Ribbon -->
      <div id="curriculum-metrics-ribbon" class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <!-- Injected via JS -->
      </div>

      <!-- Subjects Table -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead class="bg-slate-100 text-slate-800 uppercase font-bold border-b border-slate-300 text-[11px]">
              <tr>
                <th class="p-3 border-r border-slate-200">Subject Code</th>
                <th class="p-3 border-r border-slate-200">Course Title</th>
                <th class="p-3 border-r border-slate-200">Category</th>
                <th class="p-3 border-r border-slate-200 text-center">L (3/Wk)</th>
                <th class="p-3 border-r border-slate-200 text-center">T</th>
                <th class="p-3 border-r border-slate-200 text-center">P (1 Lab/Wk)</th>
                <th class="p-3 border-r border-slate-200 text-center font-black">Credits</th>
                <th class="p-3 border-r border-slate-200">Facility Required</th>
                <th class="p-3">Domain Skills & Faculty Match</th>
              </tr>
            </thead>
            <tbody id="curriculum-table-tbody" class="divide-y divide-slate-200">
              <!-- Injected via JS -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ==================================================== -->
    <!-- SECTION 4: FACULTY ENTRY DETAIL (ALL DEPARTMENTS)    -->
    <!-- ==================================================== -->
    <div id="tab-faculty" class="tab-pane hidden space-y-4">
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-slate-900">Faculty Directory Department-Wise (adit.ac.in)</h2>
          <p class="text-xs text-slate-500">Real faculty from all departments with designations, qualifications, experience, and 1 to 5 subject priority preferences.</p>
        </div>

        <div class="flex items-center gap-2">
          <select id="sel-filter-faculty-dept" class="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 font-bold bg-white">
            <option value="ALL">All Departments</option>
            <option value="CE">Computer Engineering (13 Faculty)</option>
            <option value="IT">Information Technology (13 Faculty)</option>
            <option value="CSD">Computer Science & Design (5 Faculty)</option>
            <option value="AIDS">AI & Data Science (5 Faculty)</option>
            <option value="ME">Mechanical Engineering (8 Faculty)</option>
            <option value="CL">Civil Engineering (7 Faculty)</option>
            <option value="EE">Electrical Engineering (5 Faculty)</option>
            <option value="CH">Chemical Engineering (4 Faculty)</option>
            <option value="ASH">Applied Sciences & Humanities (3 Faculty)</option>
          </select>

          <button id="btn-open-add-faculty-modal" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-3 py-1.5 rounded-lg text-xs shadow-xs transition flex items-center gap-1 cursor-pointer">
            <span>➕</span> Add / Edit Faculty
          </button>
        </div>
      </div>

      <!-- Priority Rule Banner -->
      <div class="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-xs text-amber-900 flex items-start gap-2.5">
        <span class="text-lg">💡</span>
        <div>
          <strong class="font-bold">Faculty Preference Rule:</strong>
          <p class="mt-0.5 text-amber-800 leading-relaxed">
            Faculty specify subjects they wish to teach in priority order (1st to 5th choice). 
            <strong>Only Priority 1 is mandatory; Priorities 2 through 5 are completely optional.</strong>
            The AI scheduler compares each subject with the faculty's skills and interests, and allocates second/third subjects wisely so that <strong>all faculty members receive equal work</strong>!
          </p>
        </div>
      </div>

      <!-- Faculty Directory Grid -->
      <div id="faculty-priorities-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <!-- Injected via JS -->
      </div>
    </div>

    <!-- ==================================================== -->
    <!-- SECTION 5: FACULTY TIMETABLE & EQUAL WORKLOAD        -->
    <!-- ==================================================== -->
    <div id="tab-faculty-timetable" class="tab-pane hidden space-y-4">
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-slate-900">Faculty Timetable & Wise Equal Workload Allotment</h2>
          <p class="text-xs text-slate-500">Every faculty member receives balanced weekly teaching hours across theory lectures and practical labs without double-booking.</p>
        </div>

        <div class="flex items-center gap-2">
          <label class="text-xs font-bold text-slate-700">Select Faculty Member:</label>
          <select id="select-faculty-individual" class="text-xs border border-slate-300 rounded-lg px-3 py-1.5 font-bold bg-white focus:ring-1 focus:ring-indigo-500">
            <!-- Injected via JS -->
          </select>
        </div>
      </div>

      <!-- Equal Workload Comparison Dashboard -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div class="flex items-center justify-between border-b border-slate-200 pb-2">
          <div>
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-800">Department Faculty Workload Distribution Balance</h3>
            <p class="text-[11px] text-slate-500">Comparing assigned teaching hours to verify equal work distribution across all professors.</p>
          </div>
          <span class="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
            Target Load: 12 - 15 Hours / Week
          </span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead class="bg-slate-100 text-slate-800 uppercase font-bold border-b border-slate-300 text-[10px]">
              <tr>
                <th class="p-2 border-r border-slate-200">Faculty Name</th>
                <th class="p-2 border-r border-slate-200">Department</th>
                <th class="p-2 border-r border-slate-200">Assigned Subjects</th>
                <th class="p-2 border-r border-slate-200 text-center">Theory Hours (3/Subject)</th>
                <th class="p-2 border-r border-slate-200 text-center">Lab Hours (2/Session)</th>
                <th class="p-2 border-r border-slate-200 text-center font-black">Total Weekly Load</th>
                <th class="p-2 text-center">Equity Status</th>
              </tr>
            </thead>
            <tbody id="faculty-workload-balance-tbody" class="divide-y divide-slate-200">
              <!-- Injected via JS -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- Selected Faculty Personal Profile & Timetable -->
      <div id="faculty-personal-profile-card" class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <!-- Injected via JS -->
      </div>

      <!-- Faculty Personal Weekly Timetable Grid -->
      <div class="bg-white p-4 rounded-xl border border-slate-300 shadow-xs overflow-hidden">
        <div class="flex items-center justify-between mb-3 border-b border-slate-200 pb-2">
          <h3 class="text-xs font-bold uppercase text-slate-800">Weekly Schedule Grid (Monday to Friday • Saturday Holiday)</h3>
          <span class="text-xs text-slate-500">Break: 12:40 PM - 1:25 PM</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-center text-xs border-collapse adit-table">
            <thead class="bg-slate-800 text-white font-bold text-[11px]">
              <tr>
                <th class="p-2 border border-slate-700 w-28">Time Slot</th>
                <th class="p-2 border border-slate-700">MONDAY</th>
                <th class="p-2 border border-slate-700">TUESDAY</th>
                <th class="p-2 border border-slate-700">WEDNESDAY</th>
                <th class="p-2 border border-slate-700">THURSDAY</th>
                <th class="p-2 border border-slate-700">FRIDAY</th>
                <th class="p-2 border border-slate-700 bg-slate-900 text-amber-300">SATURDAY</th>
              </tr>
            </thead>
            <tbody id="individual-faculty-timetable-tbody" class="divide-y divide-slate-300 bg-white">
              <!-- Injected via JS -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ==================================================== -->
    <!-- SECTION 6: STUDENT TIMETABLE (FULLY EDITABLE!)       -->
    <!-- ==================================================== -->
    <div id="tab-student-timetable" class="tab-pane hidden space-y-3">
      <!-- Selector & Options Bar -->
      <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
        <div class="flex flex-wrap items-center gap-2.5 text-xs">
          <!-- Department Selector -->
          <div class="flex items-center gap-1.5">
            <label class="font-bold text-slate-700">Department:</label>
            <select id="sel-dept" class="border border-slate-300 rounded-lg px-2 py-1 font-bold text-slate-800 bg-white focus:ring-1 focus:ring-indigo-500">
              <!-- Injected via JS -->
            </select>
          </div>

          <!-- Semester Selector (1 to 8) -->
          <div class="flex items-center gap-1.5">
            <label class="font-bold text-slate-700">Semester:</label>
            <select id="sel-sem" class="border border-slate-300 rounded-lg px-2 py-1 font-bold text-slate-800 bg-white focus:ring-1 focus:ring-indigo-500">
              <option value="5" selected>Sem 5</option>
              <option value="1">Sem 1</option>
              <option value="2">Sem 2</option>
              <option value="3">Sem 3</option>
              <option value="4">Sem 4</option>
              <option value="6">Sem 6</option>
              <option value="7">Sem 7</option>
              <option value="8">Sem 8</option>
            </select>
          </div>

          <!-- Division Selector -->
          <div class="flex items-center gap-1.5">
            <label class="font-bold text-slate-700">Division:</label>
            <select id="sel-div" class="border border-slate-300 rounded-lg px-2 py-1 font-bold text-slate-800 bg-white focus:ring-1 focus:ring-indigo-500">
              <!-- Dynamically populated -->
            </select>
          </div>

          <div class="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-300 text-[11px] font-semibold">
            Allotted Room: <span id="lbl-room-no" class="font-mono text-indigo-700 font-bold">213</span>
          </div>
        </div>

        <div class="text-[11px] text-slate-500 flex items-center gap-2">
          <span class="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-bold">
            ✓ 3 Lec/Wk per Subject
          </span>
          <span class="inline-flex items-center gap-1 text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 font-bold">
            ✓ 1 Lab/Wk per Lab Subject
          </span>
          <span class="inline-flex items-center gap-1 text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-bold">
            🏖 Saturday Holiday
          </span>
        </div>
      </div>

      <!-- REGENERATE TIMETABLE & EDIT CONTROLS PANEL -->
      <div class="bg-indigo-900 text-white p-3 rounded-xl shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
        <div class="flex items-center space-x-2">
          <span class="text-base">⚡</span>
          <div>
            <h4 class="font-bold text-xs text-white">Dynamic AI Timetable Controls & Live Slot Editor</h4>
            <p class="text-[10.5px] text-indigo-200">Click on any period slot below to edit subject, faculty, or room. Use options below to re-balance or randomize.</p>
          </div>
        </div>

        <div class="flex items-center flex-wrap gap-2 text-xs">
          <button id="btn-panel-regenerate" class="bg-indigo-500 hover:bg-indigo-400 text-white font-bold px-3 py-1.5 rounded-lg transition flex items-center gap-1 cursor-pointer">
            <span>🔄</span> Regenerate Timetable
          </button>
          <button id="btn-panel-randomize" class="bg-slate-800 hover:bg-slate-700 text-white font-semibold px-2.5 py-1.5 rounded-lg border border-slate-700 transition flex items-center gap-1 cursor-pointer">
            <span>🎲</span> Randomize Slots
          </button>
          <button id="btn-panel-balance" class="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 cursor-pointer">
            <span>⚖️</span> Auto-Balance Workloads
          </button>
          <span id="badge-variation-info" class="bg-indigo-950 text-indigo-300 font-mono text-[10.5px] px-2.5 py-1 rounded-lg border border-indigo-700">
            Variation #1 • 0 Collisions ✅
          </span>
        </div>
      </div>

      <!-- Official Print Sheet Container -->
      <div id="timetable-print-sheet" class="print-sheet bg-white p-3 sm:p-5 rounded-xl border-2 border-slate-800 shadow-md">
        <!-- University Header Strip with Official Logos -->
        <div class="border-b-2 border-slate-900 pb-2 mb-2 flex items-center justify-between">
          <!-- CVM University Logo -->
          <div class="w-16 h-16 flex items-center justify-center">
            <img id="logo-cvm-left" src="assets/cvm_logo.jpg" alt="CVM University" class="max-h-14 max-w-full object-contain">
          </div>

          <!-- Central Title -->
          <div class="text-center flex-1 px-2">
            <h2 class="text-base sm:text-lg font-black tracking-tight text-slate-900 leading-tight">A D Patel Institute of Technology</h2>
            <h3 class="text-xs sm:text-sm font-semibold text-slate-700">The Charutar Vidya Mandal (CVM) University</h3>
            <p class="text-[11px] font-bold text-slate-800 uppercase tracking-wider mt-0.5">
              Timetable For The Academic Year 2026-2027
            </p>
          </div>

          <!-- ADIT College Logo -->
          <div class="w-16 h-16 flex items-center justify-center">
            <img id="logo-adit-right" src="assets/adit_logo.webp" alt="ADIT" class="max-h-14 max-w-full object-contain">
          </div>
        </div>

        <!-- Academic Metadata Strip -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-1 text-[11px] font-medium border border-slate-800 p-1.5 mb-2 bg-slate-50/70">
          <div><span class="text-slate-500 font-normal">Program:</span> <strong id="disp-program-name" class="font-bold text-slate-900">Computer Engineering</strong></div>
          <div><span class="text-slate-500 font-normal">Semester:</span> <strong id="disp-semester-no" class="font-bold text-slate-900">5</strong></div>
          <div><span class="text-slate-500 font-normal">Faculty Code:</span> <strong id="disp-fac-code" class="font-mono text-slate-900">02</strong> | <span class="text-slate-500 font-normal">Prog Code:</span> <strong id="disp-prog-code" class="font-mono text-slate-900">04</strong></div>
          <div><span class="text-slate-500 font-normal">Div No:</span> <strong id="disp-div-no" class="font-bold text-indigo-800">01</strong> | <span class="text-slate-500 font-normal">Room No:</span> <strong id="disp-room-no" class="font-bold text-indigo-800 font-mono">213</strong></div>
        </div>

        <!-- Timetable Grid Table (Clickable & Editable Cells) -->
        <div class="overflow-x-auto scrollbar-thin">
          <table class="adit-table text-center text-xs border border-slate-900 w-full">
            <thead class="bg-slate-100 text-slate-900 font-bold text-[10px] sm:text-[11px]">
              <tr class="border-b border-slate-900">
                <th class="p-1 sm:p-2 border-r border-slate-900 w-24">Time</th>
                <th class="p-1 sm:p-2 border-r border-slate-900">MONDAY</th>
                <th class="p-1 sm:p-2 border-r border-slate-900">TUESDAY</th>
                <th class="p-1 sm:p-2 border-r border-slate-900">WEDNESDAY</th>
                <th class="p-1 sm:p-2 border-r border-slate-900">THURSDAY</th>
                <th class="p-1 sm:p-2 border-r border-slate-900">FRIDAY</th>
                <th class="p-1 sm:p-2 bg-amber-50 text-amber-900 border-l border-slate-900">SATURDAY</th>
              </tr>
            </thead>
            <tbody id="student-timetable-tbody" class="divide-y divide-slate-800">
              <!-- Dynamically Populated by AI Scheduler Engine with .slot-editable -->
            </tbody>
          </table>
        </div>

        <!-- Timetable Legends (Subject & Faculty Information) -->
        <div class="mt-3 grid grid-cols-1 lg:grid-cols-2 gap-3 text-xs">
          <!-- Subject Code Legend Table -->
          <div class="border border-slate-800 rounded-xs overflow-hidden">
            <div class="bg-slate-100 px-2 py-1 font-bold text-[11px] text-slate-800 border-b border-slate-800 flex justify-between">
              <span>COURSES / SUBJECTS (3 Lectures/Week • 1 Lab/Week)</span>
              <span>L T P C</span>
            </div>
            <table class="w-full text-left text-[10px] border-collapse">
              <tbody id="subject-legend-tbody" class="divide-y divide-slate-300">
                <!-- Injected via JS -->
              </tbody>
            </table>
          </div>

          <!-- Faculty Initials & Names Legend -->
          <div class="border border-slate-800 rounded-xs overflow-hidden">
            <div class="bg-slate-100 px-2 py-1 font-bold text-[11px] text-slate-800 border-b border-slate-800">
              FACULTY ALLOTMENT & TEACHING LOAD
            </div>
            <div id="faculty-legend-container" class="p-2 grid grid-cols-1 sm:grid-cols-2 gap-1 text-[10.5px]">
              <!-- Injected via JS -->
            </div>
          </div>
        </div>

        <!-- Signatures & Approval Footer -->
        <div class="mt-4 pt-3 border-t border-slate-900 grid grid-cols-3 text-center text-xs font-bold text-slate-800">
          <div>
            <p class="text-slate-400 text-[10px] font-normal mb-6">Generated by AI Portal</p>
            <p class="border-t border-slate-400 pt-1 inline-block px-4">Time Table Coordinator</p>
          </div>
          <div>
            <p class="text-slate-400 text-[10px] font-normal mb-6">Verified with Equal Workload</p>
            <p class="border-t border-slate-400 pt-1 inline-block px-4">Head of Department (HoD)</p>
          </div>
          <div>
            <p class="text-slate-400 text-[10px] font-normal mb-6">Academic Council Approved</p>
            <p class="border-t border-slate-400 pt-1 inline-block px-4">Principal / Director (ADIT)</p>
          </div>
        </div>
      </div>
    </div>

  </main>
HTML_PART2

print "Part 2 written successfully.\n";
close $out;
