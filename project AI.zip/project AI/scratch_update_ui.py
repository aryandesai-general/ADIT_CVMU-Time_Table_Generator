#!/usr/bin/env python3
import sys

with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add getFacultyByCode and renderFacultyAvatar right after getDepartmentFaculty
target_helper = """    function getDepartmentFaculty(deptCode) {
      if (deptCode === 'IT' || deptCode === 'AIDS') {
        return ADIT_PORTAL_DATA.faculty.filter(f => f.dept === 'IT' || f.dept === 'AIDS');
      } else if (deptCode === 'CE' || deptCode === 'CSD') {
        return ADIT_PORTAL_DATA.faculty.filter(f => f.dept === 'CE' || f.dept === 'CSD');
      } else {
        const list = ADIT_PORTAL_DATA.faculty.filter(f => f.dept === deptCode);
        return list.length > 0 ? list : ADIT_PORTAL_DATA.faculty;
      }
    }"""

helper_code = """    function getFacultyByCode(code) {
      if (!code) return null;
      return ADIT_PORTAL_DATA.faculty.find(f => f.code === code) || null;
    }

    function renderFacultyAvatar(facOrCode, size = 'sm', showDept = true) {
      const fac = (typeof facOrCode === 'string') ? getFacultyByCode(facOrCode) : facOrCode;
      if (!fac) {
        return `<span class="font-bold text-slate-800 text-[10px]">${facOrCode || '—'}</span>`;
      }
      const photoSrc = fac.photo || (fac.localPhoto ? `assets/faculty_images/${fac.localPhoto}` : '');
      const initials = (fac.name || fac.code).replace(/^(Dr\.|Prof\.|Mr\.|Mrs\.|Ms\.)\s*/, '').split(' ').map(n=>n[0]).join('').slice(0, 2).toUpperCase() || fac.code;
      
      if (size === 'xs') {
        return `
          <div class="inline-flex items-center gap-1 bg-slate-50/95 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 px-1.5 py-0.5 rounded-full transition max-w-full shadow-2xs">
            <img src="${photoSrc}" alt="${fac.name}" class="w-5 h-5 rounded-full object-cover border border-indigo-300 shrink-0" onerror="this.onerror=null; this.src='assets/faculty_images/${fac.localPhoto}'; if(!this.complete||!this.naturalWidth) this.outerHTML='<span class=\\'w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[7.5px] flex items-center justify-center shrink-0\\'>${initials}</span>';">
            <div class="text-left leading-tight truncate">
              <span class="font-bold text-slate-900 text-[8.5px] truncate block max-w-[85px]" title="${fac.name}">${fac.name}</span>
              ${showDept ? `<span class="text-[7px] font-extrabold text-indigo-700 uppercase">[${fac.dept}]</span>` : ''}
            </div>
          </div>
        `;
      } else if (size === 'cell') {
        return `
          <div class="inline-flex items-center gap-1.5 bg-slate-50/95 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 px-2 py-1 rounded-md transition max-w-full shadow-2xs">
            <img src="${photoSrc}" alt="${fac.name}" class="w-6 h-6 rounded-full object-cover border border-indigo-400 shadow-2xs shrink-0" onerror="this.onerror=null; this.src='assets/faculty_images/${fac.localPhoto}'; if(!this.complete||!this.naturalWidth) this.outerHTML='<span class=\\'w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[8.5px] flex items-center justify-center shrink-0\\'>${initials}</span>';">
            <div class="text-left leading-tight truncate">
              <div class="font-black text-slate-900 text-[9.5px] truncate max-w-[100px]" title="${fac.name}">${fac.name}</div>
              <div class="flex items-center gap-1 mt-0.5">
                <span class="bg-indigo-100 text-indigo-800 text-[7.5px] font-black px-1 rounded uppercase tracking-tight">${fac.dept} Dept</span>
              </div>
            </div>
          </div>
        `;
      } else {
        return `
          <div class="flex items-center gap-2">
            <img src="${photoSrc}" alt="${fac.name}" class="w-7 h-7 rounded-full object-cover border border-slate-300 shrink-0" onerror="this.onerror=null; this.src='assets/faculty_images/${fac.localPhoto}'; if(!this.complete||!this.naturalWidth) this.outerHTML='<span class=\\'w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[9px] flex items-center justify-center shrink-0\\'>${initials}</span>';">
            <div class="text-left leading-tight truncate">
              <span class="font-bold text-slate-900 text-xs truncate block">${fac.name}</span>
              ${showDept ? `<span class="text-[8px] font-bold text-indigo-700 uppercase">${fac.dept} Dept</span>` : ''}
            </div>
          </div>
        `;
      }
    }"""

if target_helper in text:
    text = text.replace(target_helper, target_helper + '\n\n' + helper_code)
    print("Added helper functions!")
else:
    print("Error: target_helper not found")
    sys.exit(1)

# 2. Update renderFacultyPrioritiesGrid
old_grid_card_header = """                  <div class="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 font-black text-sm flex items-center justify-center border border-indigo-200">
                    ${f.code}
                  </div>
                  <div>
                    <h3 class="font-bold text-slate-900 text-sm">${f.name}</h3>
                    <div class="flex items-center gap-1.5 mt-0.5 flex-wrap">
                      <p class="text-[11px] text-slate-500 font-medium">${f.designation} • ${f.dept} Dept</p>
                      ${sharedBadge}
                    </div>
                  </div>"""

new_grid_card_header = """                  <div class="relative shrink-0">
                    <img src="${f.photo || ('assets/faculty_images/' + f.localPhoto)}" 
                         alt="${f.name}" 
                         class="w-12 h-12 rounded-full object-cover border-2 border-indigo-400 shadow-sm"
                         onerror="this.onerror=null; this.src='assets/faculty_images/${f.localPhoto}'; if(!this.complete||!this.naturalWidth) this.outerHTML='<div class=\\'w-12 h-12 rounded-full bg-indigo-100 text-indigo-700 font-black text-sm flex items-center justify-center border border-indigo-200\\'>${f.code}</div>';">
                    <span class="absolute -bottom-1 -right-1 bg-slate-900 text-white font-mono text-[8px] px-1 py-0.2 rounded font-bold uppercase shadow-2xs">${f.dept}</span>
                  </div>
                  <div>
                    <h3 class="font-bold text-slate-900 text-sm leading-tight">${f.name}</h3>
                    <div class="flex items-center gap-1.5 mt-0.5 flex-wrap">
                      <span class="bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] px-1.5 py-0.2 rounded font-bold uppercase">${f.dept} Dept</span>
                      <p class="text-[11px] text-slate-500 font-medium">${f.designation}</p>
                      ${sharedBadge}
                    </div>
                  </div>"""

if old_grid_card_header in text:
    text = text.replace(old_grid_card_header, new_grid_card_header)
    print("Updated renderFacultyPrioritiesGrid card header with photo!")
else:
    print("Error: old_grid_card_header not found")
    sys.exit(1)

# 3. Update renderFacultyTimetableAndWorkload (table row and profile card)
old_workload_row = """          <tr class="hover:bg-slate-50 transition">
            <td class="p-2 border-r border-slate-200 font-bold text-slate-900">${f.name} <span class="font-mono text-indigo-700 font-normal">(${f.code})</span></td>"""

new_workload_row = """          <tr class="hover:bg-slate-50 transition">
            <td class="p-2 border-r border-slate-200 font-bold text-slate-900">
              <div class="flex items-center gap-2">
                <img src="${f.photo || ('assets/faculty_images/' + f.localPhoto)}" 
                     alt="${f.name}" 
                     class="w-7 h-7 rounded-full object-cover border border-slate-300 shrink-0" 
                     onerror="this.onerror=null; this.src='assets/faculty_images/${f.localPhoto}';">
                <div>
                  <span class="block text-xs">${f.name}</span>
                  <span class="text-[9.5px] text-slate-500 font-normal">${f.designation}</span>
                </div>
              </div>
            </td>"""

if old_workload_row in text:
    text = text.replace(old_workload_row, new_workload_row)
    print("Updated workload balance table with faculty photo!")
else:
    print("Error: old_workload_row not found")
    sys.exit(1)

old_profile_card = """      const profileCard = document.getElementById('faculty-personal-profile-card');
      profileCard.innerHTML = `
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 rounded-xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center shadow-xs">
            ${curFac.code}
          </div>
          <div>
            <h3 class="text-base font-bold text-slate-900">${curFac.name}</h3>
            <p class="text-xs text-slate-500 font-medium">${curFac.designation} • Department of ${curFac.dept} Engineering</p>
            <p class="text-[11px] text-indigo-600 font-semibold mt-0.5">Expertise: ${curFac.skills}</p>
          </div>
        </div>"""

new_profile_card = """      const curPhoto = curFac.photo || (curFac.localPhoto ? `assets/faculty_images/${curFac.localPhoto}` : '');
      const curInitials = (curFac.name || curFac.code).replace(/^(Dr\.|Prof\.|Mr\.|Mrs\.|Ms\.)\s*/, '').split(' ').map(n=>n[0]).join('').slice(0, 2).toUpperCase() || curFac.code;

      const profileCard = document.getElementById('faculty-personal-profile-card');
      profileCard.innerHTML = `
        <div class="flex items-center space-x-3.5">
          <div class="relative shrink-0">
            <img src="${curPhoto}" 
                 alt="${curFac.name}" 
                 class="w-14 h-14 rounded-xl object-cover border-2 border-indigo-400 shadow-sm" 
                 onerror="this.onerror=null; this.src='assets/faculty_images/${curFac.localPhoto}'; if(!this.complete||!this.naturalWidth) this.outerHTML='<div class=\\'w-14 h-14 rounded-xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center shadow-xs\\'>${curInitials}</div>';">
            <span class="absolute -bottom-1 -right-1 bg-slate-900 text-white font-mono text-[9px] px-1.5 py-0.5 rounded font-black uppercase shadow-2xs">${curFac.dept}</span>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-base font-black text-slate-900">${curFac.name}</h3>
              <span class="bg-indigo-100 text-indigo-800 text-[10px] font-extrabold px-1.5 py-0.5 rounded uppercase">${curFac.dept} Dept</span>
            </div>
            <p class="text-xs text-slate-500 font-medium">${curFac.designation} • Department of ${curFac.dept} Engineering</p>
            <p class="text-[11px] text-indigo-600 font-semibold mt-0.5">Expertise: ${curFac.skills}</p>
          </div>
        </div>"""

if old_profile_card in text:
    text = text.replace(old_profile_card, new_profile_card)
    print("Updated personal profile card with faculty photo!")
else:
    print("Error: old_profile_card not found")
    sys.exit(1)

# 4. Update renderCurrentClassTimetable
old_timetable_cells = """          } else if (entry.isLab) {
            html += `
              <td rowspan="${entry.span}" class="slot-editable p-1 border-r border-slate-900 bg-purple-50/40 align-middle" data-day="${day}" data-slot="${slot.id}">
                <div class="text-[9.5px] font-black text-purple-950 uppercase border-b border-purple-200 pb-0.5 mb-1">
                  🧪 ${entry.short} Practical Lab (2 Batches / Room)
                </div>
                <div class="grid grid-cols-2 gap-1 text-[9px] font-mono">
                  ${entry.batches.map(b => `
                    <div class="bg-white p-1 rounded border border-purple-200 text-left">
                      <strong class="text-purple-900 block font-bold">${b.batch}: ${b.sub}</strong>
                      <span class="text-slate-600 block">${b.fac} [${b.room}]</span>
                    </div>
                  `).join('')}
                </div>
              </td>
            `;
          } else if (entry.isElective && entry.options) {
            html += `
              <td class="slot-editable p-1 border-r border-slate-900 bg-indigo-50/60 hover:bg-indigo-100/70 transition text-center" data-day="${day}" data-slot="${slot.id}" title="Parallel Elective Options (Same Time, Different Rooms)">
                <div class="inline-flex items-center gap-1 font-black text-indigo-950 text-[9px] bg-indigo-200/90 px-1.5 py-0.5 rounded border border-indigo-300 uppercase tracking-tight mb-1">
                  <span>⚡</span> ${entry.basket || 'ELECTIVE'} (PARALLEL OPTIONS)
                </div>
                <div class="space-y-1 text-left text-[9px]">
                  ${entry.options.map(opt => `
                    <div class="bg-white p-1 rounded border border-indigo-200 shadow-2xs flex items-center justify-between gap-1">
                      <div class="truncate">
                        <span class="font-bold text-slate-900">${opt.short}</span>
                        <span class="text-[8px] text-slate-500 font-mono">(${opt.code})</span>
                      </div>
                      <div class="text-right whitespace-nowrap pl-1">
                        <span class="text-indigo-700 font-bold">${opt.fac}</span>
                        <span class="font-mono text-slate-800 font-bold bg-slate-100 px-1 rounded border border-slate-300 text-[8px]">${opt.room}</span>
                      </div>
                    </div>
                  `).join('')}
                </div>
                <div class="text-[7.5px] text-indigo-600 font-bold text-center mt-0.5">Separate Rooms • Same Time</div>
              </td>
            `;
          } else {
            html += `
              <td class="slot-editable p-1.5 sm:p-2 border-r border-slate-900 bg-white transition text-center" data-day="${day}" data-slot="${slot.id}">
                <div class="font-bold text-slate-900 text-[11px] leading-tight">
                  ${entry.code} (${entry.short})
                </div>
                <div class="text-[10px] font-semibold text-indigo-700 mt-0.5">
                  ${entry.faculty} <span class="font-mono text-slate-800 font-bold">[${entry.room}]</span>
                </div>
              </td>
            `;
          }"""

new_timetable_cells = """          } else if (entry.isLab) {
            html += `
              <td rowspan="${entry.span}" class="slot-editable p-1 border-r border-slate-900 bg-purple-50/40 align-middle" data-day="${day}" data-slot="${slot.id}">
                <div class="text-[9.5px] font-black text-purple-950 uppercase border-b border-purple-200 pb-0.5 mb-1">
                  🧪 ${entry.short} Practical Lab (2 Batches / Room)
                </div>
                <div class="grid grid-cols-2 gap-1 text-[9px] font-mono">
                  ${entry.batches.map(b => `
                    <div class="bg-white p-1 rounded border border-purple-200 text-left shadow-2xs">
                      <strong class="text-purple-900 block font-bold text-[8.5px] truncate mb-0.5">${b.batch}: ${b.sub}</strong>
                      <div class="flex items-center justify-between gap-1">
                        ${renderFacultyAvatar(b.fac, 'xs', true)}
                        <span class="font-mono text-purple-950 font-bold text-[8px] bg-purple-100 px-1 rounded shrink-0">[${b.room}]</span>
                      </div>
                    </div>
                  `).join('')}
                </div>
              </td>
            `;
          } else if (entry.isElective && entry.options) {
            html += `
              <td class="slot-editable p-1 border-r border-slate-900 bg-indigo-50/60 hover:bg-indigo-100/70 transition text-center" data-day="${day}" data-slot="${slot.id}" title="Parallel Elective Options (Same Time, Different Rooms)">
                <div class="inline-flex items-center gap-1 font-black text-indigo-950 text-[9px] bg-indigo-200/90 px-1.5 py-0.5 rounded border border-indigo-300 uppercase tracking-tight mb-1">
                  <span>⚡</span> ${entry.basket || 'ELECTIVE'} (PARALLEL OPTIONS)
                </div>
                <div class="space-y-1 text-left text-[9px]">
                  ${entry.options.map(opt => `
                    <div class="bg-white p-1 rounded border border-indigo-200 shadow-2xs flex items-center justify-between gap-1">
                      <div class="truncate">
                        <span class="font-bold text-slate-900 text-[8.5px]">${opt.short}</span>
                        <span class="text-[7.5px] text-slate-500 font-mono">(${opt.code})</span>
                      </div>
                      <div class="flex items-center gap-1 text-right whitespace-nowrap pl-1 shrink-0">
                        ${renderFacultyAvatar(opt.fac, 'xs', true)}
                        <span class="font-mono text-slate-800 font-bold bg-slate-100 px-1 rounded border border-slate-300 text-[7.5px]">${opt.room}</span>
                      </div>
                    </div>
                  `).join('')}
                </div>
                <div class="text-[7.5px] text-indigo-600 font-bold text-center mt-0.5">Separate Rooms • Same Time</div>
              </td>
            `;
          } else {
            html += `
              <td class="slot-editable p-1.5 sm:p-2 border-r border-slate-900 bg-white transition text-center hover:bg-slate-50" data-day="${day}" data-slot="${slot.id}">
                <div class="font-black text-slate-900 text-[10.5px] sm:text-[11px] leading-tight mb-1">
                  ${entry.code} (${entry.short})
                </div>
                <div class="flex flex-col items-center justify-center gap-1">
                  ${renderFacultyAvatar(entry.faculty, 'cell', true)}
                  <span class="font-mono text-slate-700 font-extrabold bg-slate-100 px-1.5 py-0.2 rounded border border-slate-300 text-[8.5px]">[${entry.room}]</span>
                </div>
              </td>
            `;
          }"""

if old_timetable_cells in text:
    text = text.replace(old_timetable_cells, new_timetable_cells)
    print("Updated timetable cells with faculty photos & departments!")
else:
    print("Error: old_timetable_cells not found")
    sys.exit(1)

# 5. Update renderFacultyLegend
old_faculty_legend = """      container.innerHTML = displayFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { totalHours: 0 };
        const sharedLabel = f.dept !== currentDeptCode ? ` <span class="text-purple-600 font-bold">[Shared ${f.dept}]</span>` : '';
        return `
          <div class="flex items-center space-x-1.5 p-1 bg-slate-50 rounded border border-slate-200">
            <span class="font-mono font-bold text-indigo-700 bg-indigo-100 px-1.5 py-0.5 rounded text-[10px]">${f.code}</span>
            <div class="truncate text-[10.5px]">
              <span class="font-bold text-slate-800">${f.name}</span>${sharedLabel}
              <span class="text-slate-500 text-[10px] block">${f.designation} (${stats.totalHours}h load)</span>
            </div>
          </div>
        `;
      }).join('');"""

new_faculty_legend = """      container.innerHTML = displayFaculty.map(f => {
        const stats = globalFacultyWorkload[f.code] || { totalHours: 0 };
        const sharedLabel = f.dept !== currentDeptCode ? ` <span class="text-purple-600 font-bold">[Shared ${f.dept}]</span>` : '';
        const photoSrc = f.photo || (f.localPhoto ? `assets/faculty_images/${f.localPhoto}` : '');
        const initials = (f.name || f.code).replace(/^(Dr\.|Prof\.|Mr\.|Mrs\.|Ms\.)\s*/, '').split(' ').map(n=>n[0]).join('').slice(0, 2).toUpperCase() || f.code;
        return `
          <div class="flex items-center space-x-2 p-1.5 bg-white rounded-lg border border-slate-200 shadow-2xs hover:border-indigo-300 transition">
            <img src="${photoSrc}" 
                 alt="${f.name}" 
                 class="w-8 h-8 rounded-full object-cover border border-indigo-300 shrink-0 shadow-2xs" 
                 onerror="this.onerror=null; this.src='assets/faculty_images/${f.localPhoto}'; if(!this.complete||!this.naturalWidth) this.outerHTML='<span class=\\'w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0\\'>${initials}</span>';">
            <div class="truncate text-[10.5px] leading-tight">
              <div class="flex items-center gap-1">
                <span class="font-bold text-slate-800 truncate">${f.name}</span>
                <span class="bg-indigo-100 text-indigo-800 text-[8px] font-black px-1 rounded uppercase">${f.dept}</span>
                ${sharedLabel}
              </div>
              <span class="text-slate-500 text-[10px] block truncate">${f.designation} • <span class="font-semibold text-indigo-700">${stats.totalHours}h load</span></span>
            </div>
          </div>
        `;
      }).join('');"""

if old_faculty_legend in text:
    text = text.replace(old_faculty_legend, new_faculty_legend)
    print("Updated faculty legend with photos & departments!")
else:
    print("Error: old_faculty_legend not found")
    sys.exit(1)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print("SUCCESS: index.html fully updated!")
