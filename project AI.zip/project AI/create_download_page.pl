use strict;
use warnings;
use MIME::Base64;

my $zip_file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/adit_timetable_ai.zip";
open my $fz, "<", $zip_file or die "Cannot open $zip_file: $!";
binmode $fz;
my $zip_bytes = do { local $/; <$fz> };
close $fz;
my $zip_b64 = encode_base64($zip_bytes, "");

my $app_file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/app.py";
open my $fa, "<", $app_file or die "Cannot open $app_file: $!";
my $app_text = do { local $/; <$fa> };
close $fa;
my $app_b64 = encode_base64($app_text, "");

my $out_file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/download.html";
open my $out, ">", $out_file or die "Cannot open $out_file: $!";

print $out <<'HTML_START';
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Download ADIT AI Timetable Code Package</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <style>
    @import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600;700&display=swap");
    body { font-family: "Inter", sans-serif; }
    .font-mono { font-family: "JetBrains Mono", monospace; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex items-center justify-center p-4 sm:p-6">

  <div class="max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
    
    <!-- Header -->
    <div class="text-center space-y-2">
      <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold uppercase tracking-wider">
        <span>⚡ Ready for Instant Download</span>
      </div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">ADIT AI Timetable Project Package</h1>
      <p class="text-xs sm:text-sm text-slate-400">
        Software Engineering Capstone • Author: <strong class="text-amber-300">Desai Aryan M.</strong> (EN. 12402080601009)
      </p>
    </div>

    <!-- Download Options Cards -->
    <div class="space-y-4 pt-2">
      
      <!-- Option 1: Full ZIP Package -->
      <div class="bg-slate-800/80 p-5 rounded-2xl border border-indigo-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 hover:border-indigo-400 transition shadow-lg">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 rounded-xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center text-2xl border border-indigo-500/40">
            📦
          </div>
          <div>
            <h3 class="font-bold text-white text-sm sm:text-base">Complete ZIP Package</h3>
            <p class="text-xs text-slate-400">Contains full modular source code, CSP solver, database, web UI & A2 poster</p>
            <span class="inline-block mt-1 font-mono text-[11px] text-indigo-300 bg-indigo-950/80 px-2 py-0.5 rounded border border-indigo-800">adit_timetable_ai.zip • 385 KB</span>
          </div>
        </div>
        <button onclick="triggerDownloadZip()" class="w-full sm:w-auto px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 cursor-pointer flex-shrink-0">
          <span>⬇️</span> Download ZIP
        </button>
      </div>

      <!-- Option 2: Single Python File -->
      <div class="bg-slate-800/80 p-5 rounded-2xl border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 hover:border-emerald-400 transition shadow-lg">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 rounded-xl bg-emerald-600/30 text-emerald-400 flex items-center justify-center text-2xl border border-emerald-500/40">
            🐍
          </div>
          <div>
            <h3 class="font-bold text-white text-sm sm:text-base">Single Python Script (app.py)</h3>
            <p class="text-xs text-slate-400">All-in-one standalone file (REST API + CSP solver + web server, 0 dependencies)</p>
            <span class="inline-block mt-1 font-mono text-[11px] text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">app.py • 2,178 Lines</span>
          </div>
        </div>
        <button onclick="triggerDownloadAppPy()" class="w-full sm:w-auto px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 cursor-pointer flex-shrink-0">
          <span>⬇️</span> Download app.py
        </button>
      </div>

      <!-- Option 3: A2 Academic Poster -->
      <div class="bg-slate-800/80 p-5 rounded-2xl border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 hover:border-amber-400 transition shadow-lg">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 rounded-xl bg-amber-600/30 text-amber-400 flex items-center justify-center text-2xl border border-amber-500/40">
            📑
          </div>
          <div>
            <h3 class="font-bold text-white text-sm sm:text-base">A2 Engineering Poster (HTML)</h3>
            <p class="text-xs text-slate-400">High-resolution ISO 216: A2 format (594 × 420 mm) with CVM & ADIT logos</p>
            <span class="inline-block mt-1 font-mono text-[11px] text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800">poster.html • ISO A2 Standard</span>
          </div>
        </div>
        <a href="poster.html" target="_blank" class="w-full sm:w-auto px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-amber-600/30 cursor-pointer flex-shrink-0">
          <span>👁️</span> View & Print
        </a>
      </div>

    </div>

    <!-- Quick Run Snippet -->
    <div class="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-2">
      <div class="flex items-center justify-between text-slate-400 font-bold">
        <span>Terminal Quick Run (After Download):</span>
      </div>
      <div class="bg-black/60 p-2.5 rounded-lg font-mono text-emerald-400 text-xs overflow-x-auto">
        python3 app.py
      </div>
      <p class="text-[11px] text-slate-400">Runs locally on Python 3.8+ using standard library with zero external dependencies.</p>
    </div>

    <div class="text-center pt-2">
      <a href="index.html" class="text-xs text-indigo-400 hover:text-indigo-300 underline font-semibold">
        ← Back to Live Timetable Web App
      </a>
    </div>

  </div>

  <script>
HTML_START

print $out "    const ZIP_B64 = \"$zip_b64\";\n";
print $out "    const APP_B64 = \"$app_b64\";\n";

print $out <<'HTML_END';
    function triggerDownloadZip() {
      const binaryString = atob(ZIP_B64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "adit_timetable_ai.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    function triggerDownloadAppPy() {
      const binaryString = atob(APP_B64);
      const blob = new Blob([binaryString], { type: "text/x-python" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "app.py";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    // Auto-trigger ZIP download on page load
    window.addEventListener("DOMContentLoaded", () => {
      setTimeout(() => {
        triggerDownloadZip();
      }, 300);
    });
  </script>
</body>
</html>
HTML_END

close $out;
print "Generated $out_file successfully\n";
