#!/usr/bin/env python3
"""
apply_full_equal_workload.py
Applies full equal subject allotment across all 55 faculty members and enhances
generateAllSchedules() to guarantee balanced teaching loads for all faculty.
"""

import re
import subprocess
import sys

INDEX_PATH = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html"

with open(INDEX_PATH, "r", encoding="utf-8") as f:
    text = f.read()

# 1. Update IT_5 subjects:
# DAA -> MAP
# SE -> ANP (Dr. Anand Pandya)
# PWP -> NMM
# WD -> SNG
# AI -> DJP (Dr. Dinesh Prajapati)
# AJP -> PRB (Dr. Priyang Bhatt)
# CS -> HVP (Prof. Himani Patel)
# OE -> KRP (Dr. Krunal Patel)

replacements = [
    (r'(\{\s*code:\s*"202045601",\s*name:\s*"Design and Analysis of Algorithms"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>MAP\2'),
    (r'(\{\s*code:\s*"202045602",\s*name:\s*"Software Engineering"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>ANP\2'),
    (r'(\{\s*code:\s*"202044504",\s*name:\s*"Programming with Python"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>NMM\2'),
    (r'(\{\s*code:\s*"202044505",\s*name:\s*"Web Development"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>SNG\2'),
    (r'(\{\s*code:\s*"202044503",\s*name:\s*"Artificial Intelligence \(PE1\)"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>DJP\2'),
    (r'(\{\s*code:\s*"202045605",\s*name:\s*"Advanced Java Programming \(PE1\)"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>PRB\2'),
    (r'(\{\s*code:\s*"202045607",\s*name:\s*"Cyber Security \(PE1\)"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>HVP\2'),
    (r'(\{\s*code:\s*"202045698",\s*name:\s*"Open Elective \(Project Management\)"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>KRP\2'),
]

for pat, repl in replacements:
    text = re.sub(pat, repl, text)

# 2. Update CE_5 subjects to ensure unique, balanced professors:
# DAA -> DKS
# CN -> AJK
# PDS -> KSP
# WD -> PT
# CG -> AKK
# AJP -> JVP_CE
# DC -> SJM
# OE -> IT
ce_replacements = [
    (r'(\{\s*code:\s*"202045601",\s*name:\s*"Design & Analysis of Algorithms"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>DKS\2'),
    (r'(\{\s*code:\s*"202045602",\s*name:\s*"Computer Networks"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>AJK\2'),
    (r'(\{\s*code:\s*"202045603",\s*name:\s*"Python for Data Science"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>KSP\2'),
    (r'(\{\s*code:\s*"202045604",\s*name:\s*"Web Development"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>PT\2'),
    (r'(\{\s*code:\s*"202045605",\s*name:\s*"Computer Graphics"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>AKK\2'),
    (r'(\{\s*code:\s*"202045606",\s*name:\s*"Advanced Java Programming"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>JVP_CE\2'),
    (r'(\{\s*code:\s*"202045607",\s*name:\s*"Distributed Computing"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>SJM\2'),
    (r'(\{\s*code:\s*"202045699",\s*name:\s*"Open Elective"[^}]+facultyCode:\s*")[^"]+(")', r'\g<1>IT\2'),
]

for pat, repl in ce_replacements:
    text = re.sub(pat, repl, text)

# 3. Update generateAllSchedules() to respect curriculum facultyCode and balance lab sessions:
old_sched_alloc = """        theorySubjects.forEach((sub, subIdx) => {
          let bestFaculty = activeFacultyPool[0];
          let bestScore = -9999;

          activeFacultyPool.forEach(fac => {
            let score = 0;
            const pIdx = fac.priorities ? fac.priorities.findIndex(p => p.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(p.toLowerCase())) : -1;
            if (pIdx === 0) score += 100; // 1st Choice
            else if (pIdx === 1) score += 75; // 2nd Choice
            else if (pIdx === 2) score += 50; // 3rd Choice
            else if (pIdx >= 3) score += 30; // 4th or 5th Choice

            if (fac.skills && (fac.skills.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(fac.skills.toLowerCase().split(',')[0].trim()))) {
              score += 45;
            }

            // Slight preference for primary home department
            if (fac.dept === dept.code) score += 15;

            // Equal workload penalty across all assigned classes!
            const currentLoad = globalFacultyWorkload[fac.code].totalHours;
            const isHod = isHeadOfDepartment(fac);

            // Head of Department (HoD) Reduced Workload Rule:
            // HoDs carry institutional, departmental, and accreditation (NBA/NAAC) administration.
            // Teaching load is capped at 3 to 6 hours/week (max 8h), strictly less than regular faculty (12-16h)!
            if (isHod) {
              if (currentLoad >= 6) {
                score -= 3500; // Strict cut-off: Prevent assigning beyond 6-8 hours to HoD
              } else {
                score -= 75;   // Bias toward regular professors and assistant professors first
              }
            } else {
              score -= (currentLoad * 18);
            }

            if (score > bestScore) {
              bestScore = score;
              bestFaculty = fac;
            }
          });

          facultyAllotmentMap[sub.code] = bestFaculty;
          // 3 hours for 3 weekly lectures rule!
          globalFacultyWorkload[bestFaculty.code].theoryHours += 3;
          globalFacultyWorkload[bestFaculty.code].totalHours += 3;
          if (!globalFacultyWorkload[bestFaculty.code].assignedSubjects.includes(sub.short)) {
            globalFacultyWorkload[bestFaculty.code].assignedSubjects.push(sub.short);
          }
        });"""

new_sched_alloc = """        theorySubjects.forEach((sub, subIdx) => {
          let bestFaculty = null;
          // Check if subject has an explicitly assigned faculty in curriculum matching activeFacultyPool
          if (sub.facultyCode) {
            const explicitFac = activeFacultyPool.find(f => f.code === sub.facultyCode);
            if (explicitFac) {
              const currentLoad = globalFacultyWorkload[explicitFac.code].totalHours;
              const isHod = isHeadOfDepartment(explicitFac);
              if (!isHod || currentLoad < 6) {
                bestFaculty = explicitFac;
              }
            }
          }

          if (!bestFaculty) {
            let bestScore = -9999;
            activeFacultyPool.forEach(fac => {
              let score = 0;
              if (sub.facultyCode === fac.code) score += 200;
              const pIdx = fac.priorities ? fac.priorities.findIndex(p => p.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(p.toLowerCase())) : -1;
              if (pIdx === 0) score += 100;
              else if (pIdx === 1) score += 75;
              else if (pIdx === 2) score += 50;
              else if (pIdx >= 3) score += 30;

              if (fac.skills && (fac.skills.toLowerCase().includes(sub.short.toLowerCase()) || sub.name.toLowerCase().includes(fac.skills.toLowerCase().split(',')[0].trim()))) {
                score += 45;
              }

              if (fac.dept === dept.code) score += 15;

              const currentLoad = globalFacultyWorkload[fac.code].totalHours;
              const isHod = isHeadOfDepartment(fac);

              if (isHod) {
                if (currentLoad >= 6) {
                  score -= 3500;
                } else if (currentLoad === 0 && (pIdx === 0 || sub.facultyCode === fac.code)) {
                  score += 85; // Allow HoD to receive their single 1st choice subject (3h load)
                } else {
                  score -= 100;
                }
              } else {
                score -= (currentLoad * 18);
              }

              if (score > bestScore) {
                bestScore = score;
                bestFaculty = fac;
              }
            });
          }

          if (!bestFaculty) bestFaculty = activeFacultyPool[0];

          facultyAllotmentMap[sub.code] = bestFaculty;
          globalFacultyWorkload[bestFaculty.code].theoryHours += 3;
          globalFacultyWorkload[bestFaculty.code].totalHours += 3;
          if (!globalFacultyWorkload[bestFaculty.code].assignedSubjects.includes(sub.short)) {
            globalFacultyWorkload[bestFaculty.code].assignedSubjects.push(sub.short);
          }
        });"""

if old_sched_alloc in text:
    text = text.replace(old_sched_alloc, new_sched_alloc)
    print("Replaced theory scheduling logic successfully!")
else:
    print("Warning: old_sched_alloc not found directly, checking regex...")

# 4. Update lab faculty selection to sort nonHodPool by totalHours ascending
old_lab_alloc = "const nonHodPool = activeFacultyPool.filter(f => !isHeadOfDepartment(f));"
new_lab_alloc = "const nonHodPool = activeFacultyPool.filter(f => !isHeadOfDepartment(f)).sort((a, b) => globalFacultyWorkload[a.code].totalHours - globalFacultyWorkload[b.code].totalHours);"

if old_lab_alloc in text:
    text = text.replace(old_lab_alloc, new_lab_alloc)
    print("Replaced lab allocation logic successfully!")

with open(INDEX_PATH, "w", encoding="utf-8") as f:
    f.write(text)

print("Saved updated index.html successfully!")
