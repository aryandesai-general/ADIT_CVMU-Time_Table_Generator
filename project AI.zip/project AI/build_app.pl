use strict;
use warnings;

my $file = "/Users/aryandesai/.gemini/antigravity/scratch/ai-timetable-maker/index.html";

print "Starting application generation...\n";
